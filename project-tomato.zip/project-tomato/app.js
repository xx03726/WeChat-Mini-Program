const handleError = function(error) {
  console.error('App initialization error:', error);
  // 可以在这里添加上报逻辑
};

App({
  globalData: {
    userId: 'wx416506d33658afab', // 提供临时用户ID
    userInfo: null,
    userSettings: {
      themeId: 'default',
      backgroundId: 'default',
      customBackgroundUrl: '',
      workDuration: 25,
      breakDuration: 5,
      autoStartBreaks: true,
      autoStartPomodoros: false,
      soundEnabled: true,
      vibrationEnabled: true,
      notificationEnabled: true
    },
    tasks: [],
    needRefreshTaskList: false,
    deletedTaskIds: [],
    currentFocusTask: null,  // 用于存储当前要专注的任务
    statisticsNeedRefresh: false  // 新增状态标志，表示统计页面是否需要刷新数据
  },
  
  onLaunch: function() {
    try {
      // 初始化云开发环境
      if (!wx.cloud) {
        console.error('请使用 2.2.3 或以上的基础库以使用云能力');
      } else {
        wx.cloud.init({
          env: 'cloud1-4gcmxtr567e179e8', // 替换为您的环境ID
          traceUser: true
        });
      }
      
      // 临时解决方案：从本地存储加载用户信息而不是云函数
      this.initUserInfoLocal();
    } catch (e) {
      handleError(e);
    }
  },
  
  // 添加本地存储方式的用户信息初始化
  initUserInfoLocal: function() {
    // 尝试从本地存储获取用户ID
    const userId = wx.getStorageSync('userId');
    if (userId) {
      this.globalData.userId = userId;
    } else {
      // 生成临时用户ID并存储
      const tempUserId = 'user_' + Date.now();
      this.globalData.userId = tempUserId;
      wx.setStorageSync('userId', tempUserId);
    }
    
    // 尝试从本地存储获取用户设置
    const userSettings = wx.getStorageSync('userSettings');
    if (userSettings) {
      this.globalData.userSettings = {
        ...this.globalData.userSettings,
        ...userSettings
      };
    } else {
      // 存储默认设置
      wx.setStorageSync('userSettings', this.globalData.userSettings);
    }
    
    // 在initUserInfoLocal方法中添加任务缓存初始化
    if (!wx.getStorageSync('recentTasks')) {
      wx.setStorageSync('recentTasks', []);
    }
    
    console.log('已初始化本地用户信息:', this.globalData.userId);
  },
  
  // 获取主题颜色
  getThemeColor: function() {
    const themes = {
      default: '#FF6B6B',
      blue: '#4DABF7',
      green: '#40C057',
      purple: '#9775FA',
      orange: '#FD7E14'
    };
    
    return themes[this.globalData.userSettings.themeId] || themes.default;
  },
  
  // 保存用户设置到本地存储
  saveUserSettings: function() {
    wx.setStorageSync('userSettings', this.globalData.userSettings);
    console.log('用户设置已保存到本地存储');
  },
  
  // 错误处理
  onError: function(error) {
    handleError(error);
  },
  
  // 任务更新通知
  notifyTaskUpdate: function() {
    this.globalData.needRefreshTaskList = true;
    
    // 触发回调函数
    if (this.taskUpdateCallback && typeof this.taskUpdateCallback === 'function') {
      this.taskUpdateCallback();
    }
  }
}); 