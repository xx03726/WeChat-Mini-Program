Component({
  properties: {
    workDuration: {
      type: Number,
      value: 25 // 默认25分钟
    },
    breakDuration: {
      type: Number,
      value: 5 // 默认5分钟休息
    },
    cycleCount: {
      type: Number,
      value: 4 // 默认4个循环
    },
    bindTaskId: {
      type: String,
      value: '' // 绑定的任务ID
    },
    taskId: {
      type: String,
      value: ''
    },
    taskName: {
      type: String,
      value: '专注'
    }
  },
  
  data: {
    timer: null,
    currentTime: 0, // 当前计时（秒）
    isRunning: false,
    isWorkTime: true, // true为工作时间，false为休息时间
    currentCycle: 1, // 当前循环次数
    progress: 0 // 进度（0-100）
  },
  
  methods: {
    startTimer() {
      if (this.data.isRunning) return;
      
      this.setData({
        isRunning: true
      });
      
      const duration = this.data.isWorkTime ? this.properties.workDuration : this.properties.breakDuration;
      this.setData({
        currentTime: duration * 60,
        timer: setInterval(() => {
          this._updateTimer();
        }, 1000)
      });
      
      // 记录开始时间
      this._recordStart();
    },
    
    pauseTimer() {
      if (!this.data.isRunning) return;
      
      clearInterval(this.data.timer);
      this.setData({
        isRunning: false,
        timer: null
      });
    },
    
    stopTimer() {
      clearInterval(this.data.timer);
      
      const nextState = {
        isRunning: false,
        timer: null,
        currentTime: 0,
        progress: 0
      };
      
      // 如果停止了一个正在进行的计时，记录
      if (this.data.isRunning) {
        this._recordEnd(false); // 标记为未完成
      }
      
      this.setData(nextState);
    },
    
    _updateTimer() {
      if (this.data.currentTime <= 0) {
        this._handleTimeUp();
        return;
      }
      
      const newTime = this.data.currentTime - 1;
      const duration = this.data.isWorkTime ? this.properties.workDuration : this.properties.breakDuration;
      const progress = (1 - newTime / (duration * 60)) * 100;
      
      this.setData({
        currentTime: newTime,
        progress: progress
      });
    },
    
    _handleTimeUp() {
      clearInterval(this.data.timer);
      
      // 播放提示音
      const innerAudioContext = wx.createInnerAudioContext();
      innerAudioContext.src = '/assets/sounds/time-up.mp3';
      innerAudioContext.play();
      
      // 记录结束
      this._recordEnd(true); // 标记为已完成
      
      // 切换工作/休息状态
      if (this.data.isWorkTime) {
        // 工作时间结束，切换到休息时间
        this.setData({
          isWorkTime: false,
          isRunning: false,
          timer: null,
          currentTime: 0,
          progress: 0
        });
      } else {
        // 休息时间结束，增加循环次数或结束所有循环
        if (this.data.currentCycle < this.properties.cycleCount) {
          this.setData({
            currentCycle: this.data.currentCycle + 1,
            isWorkTime: true,
            isRunning: false,
            timer: null,
            currentTime: 0,
            progress: 0
          });
        } else {
          // 所有循环完成
          this.setData({
            currentCycle: 1,
            isWorkTime: true,
            isRunning: false,
            timer: null,
            currentTime: 0,
            progress: 0
          });
          
          // 触发完成事件
          this.triggerEvent('allCyclesCompleted');
        }
      }
      
      // 自动开始下一个计时（可配置）
      // this.startTimer();
    },
    
    // 记录开始时间
    _recordStart() {
      const record = {
        userId: getApp().globalData.userId,
        taskId: this.properties.bindTaskId || '',
        startTime: new Date(),
        type: this.data.isWorkTime ? 'work' : 'break'
      };
      
      // 临时存储当前记录，等结束时再保存完整记录
      this.currentRecord = record;
    },
    
    // 记录结束时间
    _recordEnd(completed) {
      if (!this.currentRecord) return;
      
      const endTime = new Date();
      const duration = (endTime - new Date(this.currentRecord.startTime)) / (1000 * 60); // 转换为分钟
      
      const record = {
        ...this.currentRecord,
        endTime: endTime,
        duration: duration,
        completed: completed
      };
      
      // 调用云函数保存记录
      wx.cloud.callFunction({
        name: 'pomodoroTimer',
        data: {
          action: 'addRecord',
          record: record
        }
      }).then(res => {
        console.log('记录保存成功', res);
      }).catch(err => {
        console.error('记录保存失败', err);
      });
      
      this.currentRecord = null;
    },
    
    // 完成专注
    finishFocus: function() {
      const duration = this.data.duration;
      const minutes = Math.floor(duration / 60);
      
      // 记录专注数据
      wx.cloud.callFunction({
        name: 'userManagement',
        data: {
          action: 'recordFocus',
          focusData: {
            taskId: this.properties.taskId || '',
            taskName: this.properties.taskName || '专注',
            minutes: minutes,
            date: new Date().toISOString(),
            duration: duration
          }
        },
        success: res => {
          wx.showToast({
            title: '专注记录已保存',
            icon: 'success'
          });
          
          // 触发事件通知页面专注已完成
          this.triggerEvent('focusCompleted', {
            taskId: this.properties.taskId,
            minutes: minutes
          });
        },
        fail: err => {
          console.error('保存专注记录失败', err);
        }
      });
    }
  }
}); 