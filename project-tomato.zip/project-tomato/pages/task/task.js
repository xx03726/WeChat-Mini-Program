// pages/task/task.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        taskId: '',
        taskInfo: null,
        currentTask: null,
        newTag: '',
        newSubtask: '',
        tasks: [],
        todayTasks: []
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        if (options.id) {
            this.setData({
                taskId: options.id
            });
            this.loadTask(options.id);
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 设置当前日期和星期
        const now = new Date();
        this.setData({
            currentDate: this.formatDate(now),
            weekDay: this.getWeekDay(now)
        });
        
        // 获取已删除任务ID列表
        const app = getApp();
        const deletedIds = app.globalData.deletedTaskIds || [];
        
        // 如果当前taskId在已删除列表中，则清空并加载任务列表
        if (this.data.taskId && deletedIds.includes(this.data.taskId)) {
            console.log('检测到当前任务已被删除，清空任务ID并加载列表');
            this.setData({
                taskId: '',
                currentTask: null
            });
            this.loadTaskList();
            return;
        }
        
        // 如果有任务ID，则重新加载任务详情
        if (this.data.taskId) {
            this.loadTask(this.data.taskId);
        } else {
            // 没有特定任务ID时，显示任务列表
            this.loadTaskList();
        }
        
        // 监听任务更新事件
        this.watchTaskUpdates();
        
        // 检测是否需要强制刷新任务列表
        if (app.globalData.needRefreshTaskList) {
            console.log('全局状态要求刷新任务列表');
            this.loadTaskList();
            app.globalData.needRefreshTaskList = false;
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },

    // 日期格式化函数
    formatDate(date) {
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const day = date.getDate();
        return `${year}年${month}月${day}日`;
    },

    // 获取星期几
    getWeekDay(date) {
        const weekDays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
        return weekDays[date.getDay()];
    },

    // 加载任务详情
    loadTask: function(taskId) {
        if (!taskId) {
            console.error('任务ID为空');
            wx.showToast({
                title: '无效的任务ID',
                icon: 'none'
            });
            return;
        }
        
        // 检查任务ID是否在已删除列表中
        const app = getApp();
        const deletedIds = app.globalData.deletedTaskIds || [];
        if (deletedIds.includes(taskId)) {
            console.log('尝试加载已删除的任务:', taskId);
            wx.showToast({
                title: '任务已被删除',
                icon: 'none'
            });
            
            // 清空当前任务ID并加载列表
            this.setData({
                taskId: '',
                currentTask: null
            });
            this.loadTaskList();
            return;
        }
        
        console.log('加载任务详情, ID:', taskId);
        wx.showLoading({
            title: '加载中'
        });
        
        const db = wx.cloud.database();
        
        // 在查询前先验证ID格式是否符合数据库规则
        let isValidId = true;
        try {
            // 尝试使用ID创建引用，如果格式不符会抛出异常
            db.collection('tasks').doc(taskId);
        } catch (err) {
            console.error('无效的任务ID格式:', err);
            isValidId = false;
        }
        
        if (!isValidId) {
            wx.hideLoading();
            this.handleTaskLoadError(new Error('无效的任务ID格式'));
            return;
        }
        
        // 使用try/catch结构以确保错误被正确处理
        try {
            db.collection('tasks').doc(taskId).get()
                .then(res => {
                    console.log('获取任务详情成功:', res.data);
                    
                    // 如果有返回数据
                    if (res.data) {
                        this.setData({
                            currentTask: res.data,
                            taskId: taskId
                        });
                        wx.hideLoading();
                    } else {
                        // 文档存在但数据为空
                        throw new Error('任务数据为空');
                    }
                })
                .catch(err => {
                    console.error('加载任务详情失败:', err);
                    this.handleTaskLoadError(err);
                });
        } catch (err) {
            console.error('查询执行异常:', err);
            this.handleTaskLoadError(err);
        }
    },

    // 添加任务加载错误处理方法
    handleTaskLoadError: function(err) {
        wx.hideLoading();
        
        // 根据错误类型显示不同提示
        let errorMsg = '加载失败';
        
        if (err.message && err.message.includes('cannot find document')) {
            errorMsg = '任务不存在或已被删除';
            
            // 从最近任务缓存中查找
            const recentTasks = wx.getStorageSync('recentTasks') || [];
            const cachedTask = recentTasks.find(t => t._id === this.data.taskId || t.id === this.data.taskId);
            
            if (cachedTask) {
                console.log('从缓存加载任务:', cachedTask);
                // 标记为本地缓存数据
                cachedTask.fromCache = true;
                
                this.setData({
                    currentTask: cachedTask,
                    isLocalData: true
                });
                
                wx.showToast({
                    title: '显示本地缓存数据',
                    icon: 'none',
                    duration: 2000
                });
                return;
            }
        }
        
        wx.showToast({
            title: errorMsg,
            icon: 'none',
            duration: 2000
        });
        
        // 返回任务列表
        setTimeout(() => {
            this.backToList();
        }, 1500);
    },

    // 切换任务状态
    toggleTaskStatus: function(e) {
        // 移除 stopPropagation 调用，因为小程序事件对象可能不支持
        // e.stopPropagation(); 
        
        const taskId = e.currentTarget.dataset.id;
        const tasks = [...this.data.tasks];
        const taskIndex = tasks.findIndex(task => task._id === taskId);
        
        if (taskIndex === -1) return;
        
        // 切换完成状态
        const newStatus = !tasks[taskIndex].completed;
        tasks[taskIndex].completed = newStatus;
        
        // 更新界面
        this.setData({
            tasks: tasks
        });
        
        // 同步到数据库
        const db = wx.cloud.database();
        db.collection('tasks').doc(taskId).update({
            data: {
                completed: newStatus
            }
        }).then(res => {
            console.log('任务状态已更新');
            
            // 成功后添加:
            if (newStatus) {
                this.recordTaskCompletion(tasks[taskIndex]);
            } else {
                this.removeTaskCompletion(tasks[taskIndex]);
            }
            
            // 通知统计页面刷新
            getApp().globalData.statisticsNeedRefresh = true;
            
            // 新增：通知前一个页面刷新
            this.updatePreviousPage();
            
            // 新增：通知所有页面任务状态变更
            const app = getApp();
            if (app.notifyTaskUpdate) {
                app.notifyTaskUpdate();
            }
        }).catch(err => {
            console.error('更新任务状态失败:', err);
            // 恢复原状态
            tasks[taskIndex].completed = !newStatus;
            this.setData({
                tasks: tasks
            });
            
            wx.showToast({
                title: '状态更新失败',
                icon: 'none'
            });
        });
    },

    // 添加相同的记录方法
    recordTaskCompletion: function(task) {
        // 与today.js中相同的实现
        // ...
    },

    removeTaskCompletion: function(task) {
        // 与today.js中相同的实现
        // ...
    },

    // 修改updatePreviousPage方法，兼容fetchTodayTasks
    updatePreviousPage() {
        const pages = getCurrentPages();
        if (pages.length > 1) {
            const prevPage = pages[pages.length - 2];
            // 检查前一页面是否有fetchTodayTasks方法
            if (prevPage && typeof prevPage.fetchTodayTasks === 'function') {
                // 调用前一页面的刷新方法
                prevPage.fetchTodayTasks();
            } else if (prevPage && typeof prevPage.loadTasks === 'function') {
                // 兼容loadTasks方法
                prevPage.loadTasks();
            } else if (prevPage && typeof prevPage.onShow === 'function') {
                // 或者尝试调用onShow方法
                prevPage.onShow();
            }
        }
    },

    // 更新优先级
    updatePriority(e) {
        const { important, urgent } = e.currentTarget.dataset;
        const task = this.data.currentTask;
        if (!task) return;
        
        // 如果当前优先级与点击相同，则不做更改
        if (task.priority.important === important && task.priority.urgent === urgent) {
            return;
        }
        
        wx.showLoading({
            title: '更新中...',
        });
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(task._id).update({
            data: {
                'priority.important': important,
                'priority.urgent': urgent
            },
            success: () => {
                task.priority = { important, urgent };
                this.setData({ currentTask: task });
                
                wx.hideLoading();
                wx.showToast({
                    title: '优先级已更新',
                    icon: 'success'
                });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('更新优先级失败', err);
                wx.hideLoading();
                wx.showToast({
                    title: '更新失败',
                    icon: 'none'
                });
            }
        });
    },

    // 标签相关方法
    inputNewTag(e) {
        this.setData({ newTag: e.detail.value });
    },

    addTag() {
        const { newTag, currentTask } = this.data;
        if (!currentTask) return;
        
        const tagValue = newTag.trim();
        if (!tagValue) {
            wx.showToast({
                title: '标签不能为空',
                icon: 'none'
            });
            return;
        }
        
        // 检查标签是否已存在
        if (currentTask.tags.includes(tagValue)) {
            wx.showToast({
                title: '标签已存在',
                icon: 'none'
            });
            return;
        }
        
        wx.showLoading({
            title: '添加中...',
        });
        
        const updatedTags = [...currentTask.tags, tagValue];
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(currentTask._id).update({
            data: {
                tags: updatedTags
            },
            success: () => {
                currentTask.tags = updatedTags;
                this.setData({ 
                    currentTask,
                    newTag: ''
                });
                
                wx.hideLoading();
                wx.showToast({
                    title: '标签已添加',
                    icon: 'success'
                });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('添加标签失败', err);
                wx.hideLoading();
                wx.showToast({
                    title: '添加失败',
                    icon: 'none'
                });
            }
        });
    },

    removeTag(e) {
        const tag = e.currentTarget.dataset.tag;
        const { currentTask } = this.data;
        if (!currentTask) return;
        
        wx.showLoading({
            title: '删除中...',
        });
        
        const updatedTags = currentTask.tags.filter(t => t !== tag);
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(currentTask._id).update({
            data: {
                tags: updatedTags
            },
            success: () => {
                currentTask.tags = updatedTags;
                this.setData({ currentTask });
                
                wx.hideLoading();
                wx.showToast({
                    title: '标签已删除',
                    icon: 'success'
                });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('删除标签失败', err);
                wx.hideLoading();
                wx.showToast({
                    title: '删除失败',
                    icon: 'none'
                });
            }
        });
    },

    // 子任务相关方法
    inputNewSubtask(e) {
        this.setData({ newSubtask: e.detail.value });
    },

    addSubtask() {
        const { newSubtask, currentTask } = this.data;
        if (!currentTask) return;
        
        const subtaskValue = newSubtask.trim();
        if (!subtaskValue) {
            wx.showToast({
                title: '子任务不能为空',
                icon: 'none'
            });
            return;
        }
        
        wx.showLoading({
            title: '添加中...',
        });
        
        const newSubtaskObj = {
            id: Date.now().toString(),
            name: subtaskValue,
            completed: false
        };
        
        const updatedSubtasks = [...currentTask.subtasks, newSubtaskObj];
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(currentTask._id).update({
            data: {
                subtasks: updatedSubtasks
            },
            success: () => {
                currentTask.subtasks = updatedSubtasks;
                this.setData({ 
                    currentTask,
                    newSubtask: ''
                });
                
                wx.hideLoading();
                wx.showToast({
                    title: '子任务已添加',
                    icon: 'success'
                });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('添加子任务失败', err);
                wx.hideLoading();
                wx.showToast({
                    title: '添加失败',
                    icon: 'none'
                });
            }
        });
    },

    toggleSubtask(e) {
        const subtaskId = e.currentTarget.dataset.id;
        const { currentTask } = this.data;
        if (!currentTask) return;
        
        const subtaskIndex = currentTask.subtasks.findIndex(item => item.id === subtaskId);
        if (subtaskIndex === -1) return;
        
        const updatedSubtasks = [...currentTask.subtasks];
        updatedSubtasks[subtaskIndex].completed = !updatedSubtasks[subtaskIndex].completed;
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(currentTask._id).update({
            data: {
                subtasks: updatedSubtasks
            },
            success: () => {
                currentTask.subtasks = updatedSubtasks;
                this.setData({ currentTask });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('更新子任务状态失败', err);
                wx.showToast({
                    title: '更新失败',
                    icon: 'none'
                });
            }
        });
    },

    removeSubtask(e) {
        const subtaskId = e.currentTarget.dataset.id;
        const { currentTask } = this.data;
        if (!currentTask) return;
        
        wx.showLoading({
            title: '删除中...',
        });
        
        const updatedSubtasks = currentTask.subtasks.filter(
            subtask => subtask.id !== subtaskId
        );
        
        const db = wx.cloud.database();
        db.collection('tasks').doc(currentTask._id).update({
            data: {
                subtasks: updatedSubtasks
            },
            success: () => {
                currentTask.subtasks = updatedSubtasks;
                this.setData({ currentTask });
                
                wx.hideLoading();
                wx.showToast({
                    title: '子任务已删除',
                    icon: 'success'
                });
                
                // 更新前一页面
                this.updatePreviousPage();
            },
            fail: err => {
                console.error('删除子任务失败', err);
                wx.hideLoading();
                wx.showToast({
                    title: '删除失败',
                    icon: 'none'
                });
            }
        });
    },

    // 开始专注
    startFocus() {
        const { currentTask } = this.data;
        if (!currentTask) return;
        
        // 显示加载提示增强用户体验
        wx.showLoading({
            title: '加载专注页面...',
            mask: true // 防止用户操作
        });
        
        // 重点：使用switchTab而不是navigateTo
        // 因为pomodoro是tabBar页面，必须用switchTab
        wx.switchTab({
            url: '/pages/pomodoro/pomodoro',
            success: () => {
                // 存储当前任务到缓存，供pomodoro页面获取
                wx.setStorageSync('currentFocusTask', {
                    id: currentTask._id,
                    name: currentTask.name || currentTask.title || '专注任务'
                });
                console.log('成功跳转到专注页面，任务ID:', currentTask._id);
                
                setTimeout(() => {
                    wx.hideLoading();
                }, 500);
            },
            fail: (err) => {
                console.error('跳转到专注页面失败:', err);
                wx.hideLoading();
                
                // 显示错误提示
                wx.showToast({
                    title: '跳转失败',
                    icon: 'none'
                });
            }
        });
    },

    // 删除任务
    deleteTask() {
        if (!this.data.currentTask) return;
        
        const taskId = this.data.currentTask._id;
        
        wx.showModal({
            title: '确认删除',
            content: '确定要删除这个任务吗？删除后无法恢复',
            success: (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '删除中...'
                    });
                    
                    // 获取全局应用实例
                    const app = getApp();
                    
                    // 添加到全局已删除任务ID列表
                    if (!app.globalData.deletedTaskIds) {
                        app.globalData.deletedTaskIds = [];
                    }
                    app.globalData.deletedTaskIds.push(taskId);
                    
                    // 立即清空当前taskId，防止onShow时重新加载
                    this.setData({
                        taskId: '',
                        currentTask: null
                    });
                    
                    // 从数据库中删除任务
                    const db = wx.cloud.database();
                    db.collection('tasks').doc(taskId).remove()
                        .then(res => {
                            console.log('任务删除成功', res);
                            wx.hideLoading();
                            
                            // 更新全局状态，通知其他页面刷新
                            app.globalData.needRefreshTaskList = true;
                            if (app.notifyTaskUpdate) {
                                app.notifyTaskUpdate();
                            }
                            
                            wx.showToast({
                                title: '任务已删除',
                                icon: 'success'
                            });
                            
                            // 导航逻辑
                            setTimeout(() => {
                                const pages = getCurrentPages();
                                if (pages.length > 1) {
                                    // 有上一页，返回上一页
                                    wx.navigateBack({
                                        delta: 1
                                    });
                                } else {
                                    // 已经清空了currentTask和taskId，直接加载任务列表
                                    this.loadTaskList();
                                }
                            }, 800);
                        })
                        .catch(err => {
                            console.error('删除任务失败', err);
                            wx.hideLoading();
                            wx.showToast({
                                title: '删除失败',
                                icon: 'none'
                            });
                            
                            // 删除失败时，恢复任务显示
                            this.setData({
                                taskId: taskId,
                                currentTask: this.data.currentTask
                            });
                        });
                }
            }
        });
    },

    // 返回今日待办
    backToToday() {
        wx.switchTab({
            url: '/pages/today/today'
        });
    },

    // 添加一个新方法来监听任务更新
    watchTaskUpdates() {
        // 获取小程序实例
        const app = getApp();
        
        // 如果app实例有taskUpdateCallback属性，先移除
        if (app.taskUpdateCallback) {
            app.taskUpdateCallback = null;
        }
        
        // 添加更新回调
        app.taskUpdateCallback = () => {
            if (this.data.taskId) {
                this.loadTask(this.data.taskId);
            }
        };
    },

    // 添加通知列表刷新的方法
    notifyListRefresh: function() {
        const app = getApp();
        // 设置一个标志，指示列表页面需要刷新
        app.globalData.needRefreshTaskList = true;
    },

    // 优化任务列表查询方法
    loadTaskList: function() {
        wx.showLoading({ title: '加载中' });
        
        const db = wx.cloud.database();
        const userId = getApp().globalData.userId;
        
        // 优化查询：添加userId条件，使用索引，限制返回数量
        db.collection('tasks')
          .where({
            userId: userId
          })
          .orderBy('createTime', 'desc')
          .limit(100)  // 限制返回数量提高性能
          .get()
          .then(res => {
              console.log('获取任务列表成功:', res.data);
              // 获取已删除任务ID列表
              const app = getApp();
              const deletedIds = app.globalData.deletedTaskIds || [];
              
              // 过滤已删除的任务
              let filteredTasks = res.data;
              if (deletedIds.length > 0) {
                  filteredTasks = res.data.filter(task => 
                      !deletedIds.includes(task._id) && !deletedIds.includes(task.id)
                  );
                  console.log(`过滤掉 ${res.data.length - filteredTasks.length} 个已删除任务`);
              }
              
              this.setData({
                  tasks: filteredTasks,
                  taskId: '',
                  currentTask: null
              });
              wx.hideLoading();
              
              // 如果任务为空，显示友好提示
              if (!filteredTasks || filteredTasks.length === 0) {
                  console.log('没有任务数据');
              }
          })
          .catch(err => {
              console.error('获取任务列表失败:', err);
              wx.hideLoading();
              wx.showToast({
                  title: '加载失败',
                  icon: 'none'
              });
          });
    },

    // 在task.js中添加查看任务详情的方法
    viewTaskDetail: function(e) {
        const taskId = e.currentTarget.dataset.id;
        // 加载选中的任务详情
        this.loadTask(taskId);
    },

    // 添加从详情返回列表的方法
    backToList: function() {
        this.setData({
            currentTask: null,
            taskId: ''
        });
        
        // 刷新任务列表
        this.loadTaskList();
    }
})