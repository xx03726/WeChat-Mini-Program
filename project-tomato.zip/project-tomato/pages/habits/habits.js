Page({
  data: {
    habits: [],
    achievements: [],
    currentHabitId: '' // 当前查看的习惯ID
  },
  
  onLoad() {
    this.fetchHabits();
    this.fetchAchievements();
  },
  
  // 获取习惯列表
  fetchHabits() {
    wx.showLoading({
      title: '加载中',
    });
    
    wx.cloud.callFunction({
      name: 'habitTracker',
      data: {
        action: 'getHabits',
        userId: getApp().globalData.userId
      }
    }).then(res => {
      const habits = res.result.data || [];
      
      // 计算每个习惯的完成进度
      const processedHabits = habits.map(habit => {
        let progress = 0;
        
        if (habit.type === 'duration') {
          // 时长类型的习惯（例如"每天学习3小时"）
          progress = Math.min(100, (habit.currentValue / habit.targetValue) * 100);
        } else if (habit.type === 'count') {
          // 次数类型的习惯（例如"每周跑步3次"）
          progress = Math.min(100, (habit.currentCount / habit.targetCount) * 100);
        }
        
        return {
          ...habit,
          progress: progress.toFixed(0)
        };
      });
      
      this.setData({
        habits: processedHabits
      });
      
      wx.hideLoading();
    }).catch(err => {
      console.error('获取习惯失败', err);
      wx.hideLoading();
      wx.showToast({
        title: '获取习惯失败',
        icon: 'none'
      });
    });
  },
  
  // 获取成就列表
  fetchAchievements() {
    wx.cloud.callFunction({
      name: 'habitTracker',
      data: {
        action: 'getAchievements',
        userId: getApp().globalData.userId
      }
    }).then(res => {
      this.setData({
        achievements: res.result.data || []
      });
    }).catch(err => {
      console.error('获取成就失败', err);
    });
  },
  
  // 创建新习惯
  navigateToCreateHabit() {
    wx.navigateTo({
      url: '/pages/habits/create-habit/create-habit'
    });
  },
  
  // 查看习惯详情
  viewHabitDetail(e) {
    const habitId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/habits/habit-detail/habit-detail?id=${habitId}`
    });
  },
  
  // 手动打卡
  checkInHabit(e) {
    const habitId = e.currentTarget.dataset.id;
    const habitType = e.currentTarget.dataset.type;
    
    wx.showLoading({
      title: '打卡中',
    });
    
    let data = {
      action: 'checkInHabit',
      habitId: habitId,
      userId: getApp().globalData.userId,
      timestamp: new Date()
    };
    
    if (habitType === 'duration') {
      // 如果是时长型习惯，需要输入时长
      wx.hideLoading();
      wx.showModal({
        title: '输入时长',
        content: '请输入完成的时长（分钟）',
        editable: true,
        placeholderText: '例如：30',
        success: (res) => {
          if (res.confirm) {
            const duration = parseInt(res.content) || 0;
            if (duration <= 0) {
              wx.showToast({
                title: '请输入有效时长',
                icon: 'none'
              });
              return;
            }
            
            data.value = duration;
            this._submitCheckIn(data);
          }
        }
      });
    } else {
      // 计数型习惯，直接增加计数
      data.value = 1;
      this._submitCheckIn(data);
    }
  },
  
  // 提交打卡
  _submitCheckIn(data) {
    wx.showLoading({
      title: '打卡中',
    });
    
    wx.cloud.callFunction({
      name: 'habitTracker',
      data: data
    }).then(res => {
      wx.hideLoading();
      
      if (res.result.achievement) {
        // 获得了新成就
        wx.showModal({
          title: '恭喜获得成就',
          content: `你获得了成就：${res.result.achievement.name}`,
          showCancel: false,
          success: () => {
            this.fetchHabits();
            this.fetchAchievements();
          }
        });
      } else {
        wx.showToast({
          title: '打卡成功',
          icon: 'success'
        });
        this.fetchHabits();
      }
    }).catch(err => {
      console.error('打卡失败', err);
      wx.hideLoading();
      wx.showToast({
        title: '打卡失败',
        icon: 'none'
      });
    });
  },
  
  // 删除习惯
  deleteHabit(e) {
    const habitId = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个习惯吗？所有相关记录也将被删除。',
      success: res => {
        if (res.confirm) {
          wx.cloud.callFunction({
            name: 'habitTracker',
            data: {
              action: 'deleteHabit',
              habitId: habitId
            }
          }).then(() => {
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
            this.fetchHabits();
          }).catch(err => {
            console.error('删除习惯失败', err);
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            });
          });
        }
      }
    });
  }
}); 