import * as echarts from '../../components/ec-canvas/echarts';

// 导入API工具
const { statisticsAPI } = require('../../utils/api.js');

// 获取农历日期
const lunar = require('../../utils/lunar.js');

Page({
  data: {
    activeTab: 'daily', // 当前激活的统计周期：daily, weekly, monthly
    totalFocusTime: 0, // 总专注时间（分钟）
    totalCompletedTasks: 0, // 总完成任务数
    averageFocusTime: 0, // 平均每天专注时间
    ecBar: {
      lazyLoad: true, // 延迟加载
      onInit: function(canvas, width, height, dpr) {
        // 图表初始化配置会在实际调用时设置
        const chart = echarts.init(canvas, null, {
          width: width,
          height: height,
          devicePixelRatio: dpr // 像素比
        });
        return chart;
      }
    },
    ecHeatmap: {
      lazyLoad: true, // 延迟加载
      onInit: function(canvas, width, height, dpr) {
        // 图表初始化配置会在实际调用时设置
        const chart = echarts.init(canvas, null, {
          width: width,
          height: height,
          devicePixelRatio: dpr // 像素比
        });
        return chart;
      }
    },
    dateRange: {
      start: '',
      end: ''
    },
    userId: '', // 添加userId到data
    showEcBarChart: true, // 控制是否显示ECharts柱状图
    showEcHeatmap: true, // 控制是否显示ECharts热力图
    totalTasks: 0, // 总任务数
    dateRangeText: '', // 日期范围文本
    isOfflineMode: false, // 标记是否为离线模式
    heatmapData: [], // 热力图数据
    weekdays: ['一', '二', '三', '四', '五', '六', '日'],
    calendarDays: [],
    currentYear: 0,
    currentMonth: 0,
    selectedDate: '',
    lunarInfo: [
      // 简化的农历信息，实际项目可能需要更完整的数据
      { month: 3, day: 8, name: '妇女节' },
      { month: 3, day: 12, name: '植树节' },
      { month: 3, day: 20, name: '春分' },
      { month: 4, day: 5, name: '清明' }
    ],
    // 日历数据
    currentYearMonth: '',
    canGoForward: false,
    // 统计数据
    timeDistributionData: Array(24).fill(0),
    canvasReady: false,
    totalFocusSessions: 0,  // 累计专注次数
    dailyFocusSessions: 0,  // 当日专注次数
    dailyFocusTime: 0,      // 当日专注时长
    distributionPeriod: 'day', // 专注分布周期：day, week, month, custom
    hasDistributionData: false, // 是否有分布数据
    currentHour: new Date().getHours(), // 当前小时，用于标记图表
    today: '',
    disableCharts: true, // 临时禁用图表功能
    chartErrorCount: 0,
    chartsNeedUpdate: true,  // 标记图表需要更新
    timeDistribution: [],
    timeChartOpts: {},
    heatmapOpts: {}, // 热力图配置
    updateRetryCount: 0,
    // 添加以下两个属性以跟踪当前选中的周期
    timeDistributionPeriod: 'day', // 时间分布图的周期：day, week
    heatmapPeriod: 'week', // 热力图的周期：week, month
  },
  
  onLoad: function (options) {
    // 更新节假日信息
    this.updateLunarInfo();
    
    // 初始化日期相关数据
    this.initCurrentDate();
    
    // 生成日历数据
    this.generateCalendarDays();
    
    // 设置统计周期
    const tab = options.tab || 'daily';
    this.setData({
      activeTab: tab
    });
    
    // 获取用户ID
    const app = getApp();
    this.setData({
      userId: app.globalData.userId || wx.getStorageSync('userId') || ''
    });
    
    // 获取统计数据
    this.fetchStatisticsData();
    
    // 初始化图表
    this.initDailyTimeDistributionChart(); // 默认显示日视图
    this.initWeeklyHeatmapChart(); // 默认显示周视图的热力图
  },
  
  // 初始化日期范围
  initDateRange() {
    // 根据当前选择的tab设置合适的日期范围
    const today = new Date();
    let start = new Date(today);
    let end = new Date(today);
    
    if (this.data.activeTab === 'daily') {
      // 日统计，默认显示今天
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);
    } else if (this.data.activeTab === 'weekly') {
      // 周统计，默认显示本周
      const dayOfWeek = today.getDay() || 7;
      start.setDate(today.getDate() - dayOfWeek + 1);
      start.setHours(0, 0, 0, 0);
      end.setDate(start.getDate() + 6);
      end.setHours(23, 59, 59, 999);
    } else if (this.data.activeTab === 'monthly') {
      // 月统计，默认显示本月
      start.setDate(1);
      start.setHours(0, 0, 0, 0);
      end.setMonth(today.getMonth() + 1, 0);
      end.setHours(23, 59, 59, 999);
    }
    
    this.setData({
      dateRange: {
        start: this.formatDate(start),
        end: this.formatDate(end)
      },
      canGoForward: false // 当前日期不能往后
    });
  },
  
  // 格式化日期为YYYY-MM-DD
  formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },
  
  /**
   * 获取统计数据并强化图表同步
   */
  fetchStatisticsData: function(forceRefresh = false) {
    console.log('开始获取统计数据...强制刷新:', forceRefresh);
    wx.showLoading({ title: '加载数据中...' });
    
    try {
      // 设置日期范围
      const dateRange = this.getDateRangeByPeriod(this.data.activeTab);
      const { start, end } = dateRange;
      const startDate = new Date(start);
      const endDate = new Date(end);
      
      console.log('处理日期范围:', startDate.toISOString(), '至', endDate.toISOString());
      
      // ---------- 读取专注数据 ----------
      let pomodoroRecords = wx.getStorageSync('pomodoroRecords') || {};
      let totalFocusTime = 0;
      let focusTaskCount = 0;
      let timeDistribution = Array(24).fill(0);
      let heatmapData = [];
      
      // 处理专注记录
      Object.keys(pomodoroRecords).forEach(dateKey => {
        try {
          const recordDate = new Date(dateKey);
          const isInRange = recordDate >= startDate && recordDate <= endDate;
          
          if (isInRange) {
            const dayData = pomodoroRecords[dateKey];
            if (!dayData) return;
            
            // 累加专注时间
            const dayMinutes = dayData.minutes || 0;
            totalFocusTime += dayMinutes;
            
            // 从专注记录中获取任务数
            if (dayData.tasks && Array.isArray(dayData.tasks)) {
              focusTaskCount += dayData.tasks.length;
            }
            
            // 累加时间分布
            if (dayData.records && Array.isArray(dayData.records)) {
              dayData.records.forEach(record => {
                if (record && record.timestamp) {
                  const hour = new Date(record.timestamp).getHours();
                  timeDistribution[hour] += (record.minutes || 0);
                }
              });
            }
            
            // 添加热力图数据
            heatmapData.push({
              date: dateKey,
              focusTime: dayMinutes
            });
          }
        } catch (e) {
          console.error('处理专注记录错误:', e);
        }
      });
      
      // ---------- 读取完成任务数据 ----------
      let completedTasks = wx.getStorageSync('completedTasks') || {};
      let regularTaskCount = 0;
      
      // 处理任务完成记录
      Object.keys(completedTasks).forEach(dateKey => {
        try {
          const recordDate = new Date(dateKey);
          const isInRange = recordDate >= startDate && recordDate <= endDate;
          
          if (isInRange && completedTasks[dateKey] && Array.isArray(completedTasks[dateKey])) {
            // 计算普通完成的任务数
            regularTaskCount += completedTasks[dateKey].length;
            console.log('日期', dateKey, '常规完成任务数:', completedTasks[dateKey].length);
          }
        } catch (e) {
          console.error('处理任务完成记录错误:', e);
        }
      });
      
      // 合并两种任务完成来源的数据
      const totalCompletedTasks = focusTaskCount + regularTaskCount;
      console.log('任务完成统计 - 专注任务:', focusTaskCount, '常规任务:', regularTaskCount, '总计:', totalCompletedTasks);
      
      // 计算平均专注时间
      const dayCount = Math.max(1, this.getDayCount(startDate, endDate));
      const averageFocusTime = Math.round(totalFocusTime / dayCount);
      
      // 更新UI数据
      this.setData({
        totalFocusTime: this.formatFocusTime(totalFocusTime),
        totalFocusTimeRaw: totalFocusTime,
        totalCompletedTasks,
        averageFocusTime: this.formatFocusTime(averageFocusTime),
        averageFocusTimeRaw: averageFocusTime,
        totalTasks: totalCompletedTasks,
        timeDistributionData: timeDistribution,
        heatmapData: heatmapData,
        dateRange: dateRange,
        chartsNeedUpdate: true, // 标记图表需要更新
        hasDistributionData: timeDistribution.some(v => v > 0)
      }, () => {
        // 数据更新后，尝试初始化或更新图表
        this.updateCharts();
      });
      
      console.log('统计数据更新完成，完成任务数:', totalCompletedTasks);
      wx.hideLoading();
    } catch (err) {
      console.error('加载统计数据失败:', err);
      wx.hideLoading();
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },
  
  // 使用默认模拟数据
  useDefaultData() {
    // 生成一些默认数据以便展示
    const defaultTimeDistribution = [
      { timeSlot: '凌晨', hours: [0, 1, 2, 3, 4, 5], duration: 25 },
      { timeSlot: '上午', hours: [6, 7, 8, 9, 10, 11], duration: 75 },
      { timeSlot: '下午', hours: [12, 13, 14, 15, 16, 17], duration: 60 },
      { timeSlot: '晚上', hours: [18, 19, 20, 21, 22, 23], duration: 40 }
    ];
    
    const defaultHeatmapData = this.generateDefaultHeatmapData();
    
    this.setData({
      totalFocusTime: 200,
      totalCompletedTasks: 8,
      averageFocusTime: 30,
      timeDistributionData: defaultTimeDistribution,
      totalTasks: 12,
      heatmapData: this.formatHeatmapData(defaultHeatmapData),
      isOfflineMode: true
    });
    
    // 更新图表
    this.updateCharts(defaultTimeDistribution, defaultHeatmapData);
  },
  
  // 生成默认热力图数据
  generateDefaultHeatmapData() {
    const data = [];
    const today = new Date();
    
    // 生成过去14天的数据
    for (let i = 13; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      data.push({
        date: this.formatDate(date),
        duration: Math.floor(Math.random() * 120)
      });
    }
    
    return data;
  },
  
  // 格式化热力图数据
  formatHeatmapData(data) {
    return data.map(item => {
      return {
        date: item.date,
        value: item.duration
      };
    });
  },
  
  // 切换统计周期
  changeTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({
      activeTab: tab
    });
    this.fetchStatisticsData();
  },
  
  // 初始化时段统计柱状图
  initBarChart(data) {
    this.barComponent = this.selectComponent('#bar-chart');
    
    if (!this.barComponent) {
      console.error('找不到柱状图组件，请检查组件ID是否正确');
      return;
    }
    
    this.barComponent.init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          },
          formatter: '{b}: {c} 分钟'
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: data.map(item => item.timeSlot),
          axisLabel: {
            interval: 0,
            rotate: 30
          }
        },
        yAxis: {
          type: 'value',
          name: '专注时长（分钟）'
        },
        series: [{
          name: '专注时长',
          type: 'bar',
          data: data.map(item => item.duration),
          itemStyle: {
            color: '#FF6B6B'
          },
          emphasis: {
            itemStyle: {
              color: '#FF9E9E'
            }
          }
        }]
      };
      
      chart.setOption(option);
      return chart;
    });
  },
  
  // 初始化热力图 - 全新设计
  initHeatmapChart: function() {
    // 准备数据 - 简化为一周的数据
    const days = 7; // 显示一周数据
    const periods = 4; // 每天分为4个时段：凌晨、上午、下午、晚上
    const data = [];
    const periodNames = ['凌晨', '上午', '下午', '晚上'];
    const periodHours = ['0-6时', '6-12时', '12-18时', '18-24时'];
    
    // 生成一周的随机数据
    const weekdayNames = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    
    // 周一到周日的数据
    for (let i = 0; i < days; i++) {
      for (let j = 0; j < periods; j++) {
        // 随机生成专注时长（0-120分钟）
        const focusMinutes = Math.floor(Math.random() * 120);
        // 为每个时段生成一条数据
        data.push({
          value: [i, j, focusMinutes],
          itemStyle: {
            // 圆角矩形
            borderRadius: 4
          }
        });
      }
    }
    
    const heatmapOpts = {
      animation: true,
      animationDuration: 800,
      animationEasing: 'cubicOut',
      tooltip: {
        position: 'top',
        formatter: function(params) {
          const dayIndex = params.data.value[0];
          const periodIndex = params.data.value[1];
          const minutes = params.data.value[2];
          return `${weekdayNames[dayIndex]} ${periodNames[periodIndex]}<br/>专注时长：${minutes} 分钟`;
        },
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#FFE0E0',
        borderWidth: 1,
        padding: [8, 12],
        textStyle: {
          color: '#333',
          fontSize: 12
        },
        extraCssText: 'box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); border-radius: 4px;'
      },
      grid: {
        top: '50',
        left: '3%',
        right: '6%',
        bottom: '60',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: weekdayNames,
        splitArea: {
          show: true,
          areaStyle: {
            color: ['rgba(255,255,255,0.5)', 'rgba(255,250,250,0.5)']
          }
        },
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 16
        }
      },
      yAxis: {
        type: 'category',
        data: periodNames,
        splitArea: {
          show: true,
          areaStyle: {
            color: ['rgba(255,255,255,0.5)', 'rgba(255,250,250,0.5)']
          }
        },
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 16
        }
      },
      visualMap: {
        min: 0,
        max: 120,
        calculable: false,
        orient: 'horizontal',
        left: 'center',
        bottom: '10',
        itemWidth: 12,
        itemHeight: 70,
        text: ['高', '低'],
        textGap: 8,
        textStyle: {
          color: '#666666'
        },
        inRange: {
          color: ['#FFFAFA', '#FFE0E0', '#FFBDBD', '#FF9E9E', '#FF6B6B']
        },
        show: true
      },
      series: [{
        name: '专注时长',
        type: 'heatmap',
        data: data,
        label: {
          show: false
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(255, 107, 107, 0.5)'
          }
        },
        itemStyle: {
          borderWidth: 1,
          borderColor: 'rgba(255, 255, 255, 0.8)'
        }
      }]
    };
    
    this.setData({
      heatmapOpts: heatmapOpts
    });
    
    // 使用echarts组件初始化热力图
    this.selectComponent('#heatmapChart').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(heatmapOpts);
      return chart;
    });
  },
  
  /**
   * 更新图表 - 修复组件ID不匹配问题
   */
  updateCharts: function() {
    if (!this.data.chartsNeedUpdate) return;
    
    console.log('更新图表数据');
    try {
      // 修正组件ID，与WXML中保持一致
      const timeDistribution = this.selectComponent('#timeDistributionChart');
      const focusHeatmap = this.selectComponent('#heatmapChart');
      
      if (timeDistribution && focusHeatmap) {
        // 初始化时间分布图表
        this.initTimeDistributionChart();
        
        // 初始化热力图
        this.initHeatmapChart();
        
        // 重置更新标志
        this.setData({ chartsNeedUpdate: false });
        
        console.log('图表更新成功');
      } else {
        // 添加重试计数，避免无限重试
        if (!this.updateRetryCount) {
          this.updateRetryCount = 0;
        }
        
        this.updateRetryCount++;
        
        // 最多重试5次
        if (this.updateRetryCount <= 5) {
          console.log(`组件未准备好，第${this.updateRetryCount}次重试，延迟200ms`);
          setTimeout(() => {
            this.updateCharts();
          }, 200);
        } else {
          console.error('组件初始化超时，请检查组件ID是否正确');
          this.setData({ disableCharts: true });
        }
      }
    } catch (e) {
      console.error('更新图表失败:', e);
      // 错误计数
      this.setData({ 
        chartErrorCount: (this.data.chartErrorCount || 0) + 1 
      });
    }
  },
  
  // 初始化日历
  initCalendar() {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1;
    const currentYearMonth = `${currentYear}年${currentMonth}月`;
    
    this.setData({
      currentYear,
      currentMonth,
      currentYearMonth,
      weekdays: ['一', '二', '三', '四', '五', '六', '日'],
      selectedDate: this.formatDate(today)
    });
    
    this.generateCalendarDays();
  },
  
  // 修改生成日历数据函数，限制只显示一行下个月日期
  generateCalendarDays: function() {
    try {
      const year = this.data.currentYear;
      const month = this.data.currentMonth;
      const today = this.data.today;
      const selectedDate = this.data.selectedDate;
      
      // 更新顶部日期显示
      this.setData({
        currentYearMonth: `${year}年${month}月`
      });
      
      // 计算当月第一天是星期几
      const firstDay = new Date(year, month - 1, 1).getDay() || 7; // 如果是0(周日)转为7
      
      // 计算当月天数
      const daysInMonth = new Date(year, month, 0).getDate();
      
      // 计算上个月天数
      const daysInPrevMonth = new Date(year, month - 1, 0).getDate();
      
      // 生成日历数据
      let days = [];
      
      // 添加上个月的日期
      for (let i = 1; i < firstDay; i++) {
        const day = daysInPrevMonth - firstDay + i + 1;
        const date = this.formatDate(new Date(year, month - 2, day));
        days.push({
          date: date,
          day: day,
          isCurrentMonth: false,
          isToday: false,
          isSelected: date === selectedDate,
          lunar: this.getLunarDay(year, month - 1, day),
          heatColor: 'transparent'
        });
      }
      
      // 添加当月的日期
      for (let i = 1; i <= daysInMonth; i++) {
        const date = this.formatDate(new Date(year, month - 1, i));
        days.push({
          date: date,
          day: i,
          isCurrentMonth: true,
          isToday: date === today,
          isSelected: date === selectedDate,
          lunar: this.getLunarDay(year, month, i),
          heatColor: this.getHeatColor ? this.getHeatColor(date) : 'transparent'
        });
      }
      
      // 计算需要添加的下月日期，确保只显示一行
      const totalCurrentDays = firstDay - 1 + daysInMonth;
      const daysInLastRow = totalCurrentDays % 7;
      
      // 如果当前月份天数刚好填满整行，则不添加下个月日期
      const nextMonthDays = daysInLastRow === 0 ? 0 : 7 - daysInLastRow;
      
      // 添加下个月的日期(最多一行)
      for (let i = 1; i <= nextMonthDays; i++) {
        const date = this.formatDate(new Date(year, month, i));
        days.push({
          date: date,
          day: i,
          isCurrentMonth: false,
          isToday: false,
          isSelected: date === selectedDate,
          lunar: this.getLunarDay(year, month + 1, i),
          heatColor: 'transparent'
        });
      }
      
      this.setData({
        calendarDays: days
      });
      
      console.log('生成日历数据完成, 共', days.length, '天', this.data.currentYearMonth);
    } catch (e) {
      console.error('生成日历数据错误:', e);
      // 设置一个空数组，确保不影响其他功能
      this.setData({
        calendarDays: []
      });
    }
  },
  
  // 数字转中文
  convertToChinese(num) {
    const chineseNumbers = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
    if (num <= 10) return chineseNumbers[num-1];
    else if (num < 20) return '十' + (num-10 > 0 ? chineseNumbers[num-11] : '');
    else return chineseNumbers[Math.floor(num/10)-1] + '十' + (num%10 > 0 ? chineseNumbers[num%10-1] : '');
  },
  
  // 选择日期
  selectDate(e) {
    const dateString = e.currentTarget.dataset.date;
    if (!dateString) return;
    
    // 更新选中的日期
    this.setData({
      selectedDate: dateString,
      dateRange: {
        start: dateString,
        end: dateString
      }
    });
    
    // 重新生成日历以更新选中状态
    this.generateCalendarDays();
    
    // 获取所选日期的统计数据
    this.fetchStatisticsData();
  },
  
  // 选择当前周
  selectCurrentWeek() {
    const today = new Date();
    const dayOfWeek = today.getDay() || 7;
    
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - dayOfWeek + 1);
    startOfWeek.setHours(0, 0, 0, 0);
    
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(endOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);
    
    this.setData({
      dateRange: {
        start: this.formatDate(startOfWeek),
        end: this.formatDate(endOfWeek)
      },
      currentYear: today.getFullYear(),
      currentMonth: today.getMonth() + 1
    });
    
    this.generateCalendarDays();
    this.fetchStatisticsData();
  },
  
  // 选择当前月
  selectCurrentMonth() {
    const today = new Date();
    
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    endOfMonth.setHours(23, 59, 59, 999);
    
    this.setData({
      dateRange: {
        start: this.formatDate(startOfMonth),
        end: this.formatDate(endOfMonth)
      },
      currentYear: today.getFullYear(),
      currentMonth: today.getMonth() + 1
    });
    
    this.generateCalendarDays();
    this.fetchStatisticsData();
  },
  
  // 上个月
  prevMonth() {
    let { currentYear, currentMonth } = this.data;
    
    // 向前移动一个月
    currentMonth--;
    if (currentMonth < 1) {
      currentMonth = 12;
      currentYear--;
    }
    
    this.setData({
      currentYear,
      currentMonth,
      currentYearMonth: `${currentYear}年${currentMonth}月`
    });
    
    console.log('切换到上个月:', this.data.currentYearMonth);
    
    // 重新生成日历
    this.generateCalendarDays();
  },
  
  // 下个月
  nextMonth() {
    let { currentYear, currentMonth } = this.data;
    
    // 向后移动一个月
    currentMonth++;
    if (currentMonth > 12) {
      currentMonth = 1;
      currentYear++;
    }
    
    this.setData({
      currentYear,
      currentMonth,
      currentYearMonth: `${currentYear}年${currentMonth}月`
    });
    
    console.log('切换到下个月:', this.data.currentYearMonth);
    
    // 重新生成日历
    this.generateCalendarDays();
  },
  
  // 跳转到今天
  goToToday() {
    const today = new Date();
    
    this.setData({
      currentYear: today.getFullYear(),
      currentMonth: today.getMonth() + 1,
      selectedDate: this.formatDate(today),
      dateRange: {
        start: this.formatDate(today),
        end: this.formatDate(today)
      }
    });
    
    this.generateCalendarDays();
    this.fetchStatisticsData();
  },
  
  // 更新热力图颜色
  updateHeatMapColors(dailyFocus) {
    // 找出最大专注时间，用于计算颜色深度
    let maxFocusTime = 0;
    dailyFocus.forEach(item => {
      if (item.duration > maxFocusTime) {
        maxFocusTime = item.duration;
      }
    });
    
    // 更新日历中的热力图颜色
    const { calendarDays } = this.data;
    const updatedCalendarDays = calendarDays.map(day => {
      const focusData = dailyFocus.find(item => item.date === day.date);
      if (focusData && focusData.duration > 0) {
        // 根据专注时间设置颜色深度
        const intensity = Math.min(focusData.duration / (maxFocusTime || 1), 1);
        // 从浅粉到深红的渐变
        day.heatColor = `rgba(255, ${Math.floor(107 - intensity * 60)}, ${Math.floor(107 - intensity * 80)}, ${0.2 + intensity * 0.8})`;
      }
      return day;
    });
    
    this.setData({ calendarDays: updatedCalendarDays });
  },
  
  // 新增：获取未来计划任务
  fetchFuturePlannedTasks() {
    // 检查是否在浏览未来月份
    const now = new Date();
    const currentMonth = this.data.currentMonth;
    const currentYear = this.data.currentYear;
    
    if (currentYear > now.getFullYear() || 
        (currentYear === now.getFullYear() && currentMonth > now.getMonth() + 1)) {
      
      // 获取当前月份的起始和结束日期
      const startOfMonth = new Date(currentYear, currentMonth - 1, 1);
      const endOfMonth = new Date(currentYear, currentMonth, 0);
      
      // 调用API获取未来计划的任务
      // 这里需要后端支持
      wx.cloud.callFunction({
        name: 'getPlannedTasks',
        data: {
          userId: this.data.userId,
          startDate: this.formatDate(startOfMonth),
          endDate: this.formatDate(endOfMonth)
        }
      })
      .then(res => {
        if (res.result && res.result.success) {
          // 处理获取的未来任务数据
          this.markPlannedTasksOnCalendar(res.result.plannedTasks);
        }
      })
      .catch(err => {
        console.error('获取计划任务失败:', err);
      });
    }
  },
  
  // 在日历上标记计划任务
  markPlannedTasksOnCalendar(plannedTasks) {
    if (!plannedTasks || plannedTasks.length === 0) return;
    
    const { calendarDays } = this.data;
    
    // 更新日历上的任务标记
    const updatedCalendarDays = calendarDays.map(day => {
      const taskForDay = plannedTasks.find(task => task.date === day.date);
      if (taskForDay) {
        // 给有任务的日期添加标记
        day.hasTask = true;
        day.taskCount = taskForDay.count || 1;
      }
      return day;
    });
    
    this.setData({ calendarDays: updatedCalendarDays });
  },
  
  // 获取专注分布数据
  fetchDistributionData() {
    const period = this.data.distributionPeriod;
    const { start, end } = this.data.dateRange;
    
    wx.showLoading({
      title: '加载中',
    });
    
    statisticsAPI.getFocusDistribution({
      userId: this.data.userId,
      startDate: start,
      endDate: end,
      period: period
    })
    .then(data => {
      console.log('获取专注分布数据:', data);
      
      if (data && data.distribution && data.distribution.length > 0) {
        this.setData({
          hasDistributionData: true
        });
        
        // 初始化图表
        this.initDistributionChart(data.distribution);
      } else {
        this.setData({
          hasDistributionData: false
        });
      }
    })
    .catch(err => {
      console.error('获取专注分布数据失败:', err);
      this.setData({
        hasDistributionData: false
      });
    })
    .finally(() => {
      wx.hideLoading();
    });
  },
  
  // 初始化分布图表
  initDistributionChart(distributionData) {
    // 这里根据distributionPeriod的不同值，绘制不同的图表
    // 实现代码略，需要使用echart
  },
  
  // 切换分布周期
  switchDistributionPeriod(e) {
    const period = e.currentTarget.dataset.period;
    
    if (period !== this.data.distributionPeriod) {
      this.setData({
        distributionPeriod: period
      });
      
      // 获取新周期的分布数据
      this.fetchDistributionData();
    }
  },
  
  // 上一个分布日期
  prevDistributionDate() {
    // 根据当前选择的分布周期，计算上一个日期范围
    const { distributionPeriod } = this.data;
    // 实现代码略
    
    this.fetchDistributionData();
  },
  
  // 下一个分布日期
  nextDistributionDate() {
    // 根据当前选择的分布周期，计算下一个日期范围
    const { distributionPeriod } = this.data;
    // 实现代码略
    
    this.fetchDistributionData();
  },
  
  // 查看专注记录
  viewFocusRecords() {
    wx.navigateTo({
      url: '/pages/focus-records/focus-records'
    });
  },
  
  // 更新时间分布数据
  initTimeDistribution(data) {
    // 处理时间分布数据
    const timeDistribution = Array(24).fill(0);
    
    if (data && data.hourlyDistribution) {
      // 使用API返回的时间分布数据
      data.hourlyDistribution.forEach(item => {
        const hour = parseInt(item.hour);
        if (hour >= 0 && hour < 24) {
          timeDistribution[hour] = item.duration;
        }
      });
    }
    
    this.setData({
      timeDistributionData: timeDistribution,
      currentHour: new Date().getHours()
    });
    
    // 初始化图表
    if (this.data.canvasReady) {
      this.initBarChart();
    }
  },
  
  // 添加初始化当前日期的方法
  initCurrentDate: function() {
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      const date = now.getDate();
      
      this.setData({
        currentYear: year,
        currentMonth: month,
        selectedDate: `${year}-${month < 10 ? '0' + month : month}-${date < 10 ? '0' + date : date}`,
        today: `${year}-${month < 10 ? '0' + month : month}-${date < 10 ? '0' + date : date}`
      });
      
      console.log('当前日期初始化完成:', this.data.selectedDate);
    } catch (e) {
      console.error('初始化当前日期失败:', e);
    }
  },
  
  // 添加设置默认日期范围的方法
  setDefaultDateRange: function() {
    const today = new Date();
    
    let start = new Date(today);
    let end = new Date(today);
    
    if (this.data.activeTab === 'daily') {
      // 日统计，默认显示今天
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);
    } else if (this.data.activeTab === 'weekly') {
      // 周统计，默认显示本周
      const dayOfWeek = today.getDay() || 7; // 周日是0，转为7
      start.setDate(today.getDate() - dayOfWeek + 1); // 本周一
      start.setHours(0, 0, 0, 0);
      end.setDate(start.getDate() + 6); // 本周日
      end.setHours(23, 59, 59, 999);
    } else if (this.data.activeTab === 'monthly') {
      // 月统计，默认显示本月
      start.setDate(1); // 本月1号
      start.setHours(0, 0, 0, 0);
      end.setMonth(today.getMonth() + 1, 0); // 本月最后一天
      end.setHours(23, 59, 59, 999);
    }
    
    this.setData({
      dateRange: {
        start: this.formatDate(start),
        end: this.formatDate(end)
      }
    });
  },
  
  // 根据周期类型获取日期范围
  getDateRangeByPeriod: function(period) {
    const today = new Date();
    let startDate = new Date(today);
    let endDate = new Date(today);
    
    if (period === 'daily') {
      // 日统计，返回今天
      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(23, 59, 59, 999);
    } else if (period === 'weekly') {
      // 周统计，返回本周一到周日
      const dayOfWeek = today.getDay() || 7; // 将周日的0转为7
      startDate.setDate(today.getDate() - dayOfWeek + 1); // 设置为本周一
      startDate.setHours(0, 0, 0, 0);
      endDate.setDate(startDate.getDate() + 6); // 周日
      endDate.setHours(23, 59, 59, 999);
    } else if (period === 'monthly') {
      // 月统计，返回本月1号到月末
      startDate.setDate(1); // 本月1号
      startDate.setHours(0, 0, 0, 0);
      endDate.setMonth(today.getMonth() + 1, 0); // 本月最后一天
      endDate.setHours(23, 59, 59, 999);
    }
    
    return {
      start: this.formatDate(startDate),
      end: this.formatDate(endDate)
    };
  },
  
  /**
   * 初始化统计图表 - 增强版
   */
  initCharts: function() {
    console.log('准备初始化图表...');
    
    if (this.data.disableCharts) {
      console.log('图表功能已禁用，跳过初始化');
      return;
    }
    
    // 检查组件是否存在
    if (!this.checkComponentReady()) {
      console.error('图表组件未准备好，无法初始化');
      return;
    }
    
    try {
      // 初始化时间分布图表
      this.initTimeDistributionChart();
      
      // 初始化热力图
      this.initHeatmapChart();
      
      // 重置更新标志
      this.setData({ chartsNeedUpdate: false });
      
      console.log('图表初始化完成');
    } catch (e) {
      console.error('图表初始化失败:', e);
      
      // 增加错误计数，超过一定次数则禁用图表
      this.setData({ 
        chartErrorCount: this.data.chartErrorCount + 1 
      });
      
      if (this.data.chartErrorCount > 3) {
        console.log('图表错误次数过多，禁用图表功能');
        this.setData({ disableCharts: true });
      }
    }
  },
  
  /**
   * 初始化时间分布图表 - 全新设计
   */
  initTimeDistributionChart: function() {
    // 假设我们有24小时的数据，简化为6个时段
    const hours = ['0时', '4时', '8时', '12时', '16时', '20时'];
    const minutes = [30, 45, 60, 90, 75, 15]; // 示例数据
    
    // 查找最大值的索引，用于突出显示
    const maxIndex = minutes.indexOf(Math.max(...minutes));
    
    // 为每个柱子准备不同的样式，突出显示最高值
    const itemStyles = minutes.map((value, index) => {
      if (index === maxIndex) {
        // 突出显示最高值的柱子
        return {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#FF7D7D' },
            { offset: 1, color: '#FF5252' }
          ]),
          borderRadius: [6, 6, 0, 0],
          shadowColor: 'rgba(255, 82, 82, 0.3)',
          shadowBlur: 10
        };
      } else {
        // 普通柱子样式
        return {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#FFB7B7' },
            { offset: 1, color: '#FF9E9E' }
          ]),
          borderRadius: [4, 4, 0, 0]
        };
      }
    });
    
    const timeChartOpts = {
      animation: true,
      animationDuration: 1000,
      animationEasing: 'elasticOut',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function(params) {
          return `${params[0].name}: ${params[0].value} 分钟`;
        },
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#FFE0E0',
        borderWidth: 1,
        padding: [8, 12],
        textStyle: {
          color: '#333',
          fontSize: 12
        },
        extraCssText: 'box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); border-radius: 4px;'
      },
      grid: {
        top: '50',
        left: '3%',
        right: '3%',
        bottom: '15%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: hours,
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 14
        }
      },
      yAxis: {
        type: 'value',
        name: '专注分钟',
        nameTextStyle: {
          color: '#999999',
          fontSize: 12,
          padding: [0, 0, 8, 0]
        },
        min: 0,
        max: function(value) {
          return Math.ceil(value.max * 1.2 / 10) * 10; // 向上取整到10的倍数，并增加20%空间
        },
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12
        },
        splitLine: {
          lineStyle: {
            color: '#F5F5F5',
            type: 'dashed'
          }
        }
      },
      series: [{
        name: '专注时长',
        type: 'bar',
        data: minutes,
        barWidth: '40%',
        itemStyle: {
          borderRadius: [4, 4, 0, 0]
        },
        // 使用自定义函数为每个柱子设置样式
        renderItem: function(params, api) {
          const index = params.dataIndex;
          return itemStyles[index];
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 15,
            shadowColor: 'rgba(255, 107, 107, 0.5)'
          }
        },
        label: {
          show: true,
          position: 'top',
          fontSize: 12,
          color: '#666666',
          formatter: function(params) {
            // 为最高值添加标记
            if (params.dataIndex === maxIndex) {
              return params.value + ' ↑';
            }
            return params.value;
          }
        }
      }]
    };
    
    this.setData({
      timeDistribution: minutes,
      timeChartOpts: timeChartOpts
    });
    
    // 使用微信小程序的Canvas绘制柱状图
    this.selectComponent('#timeDistributionChart').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(timeChartOpts);
      return chart;
    });
  },
  
  /**
   * 检查组件是否已经准备好
   */
  checkComponentReady: function() {
    try {
      // 修正组件ID，与WXML中保持一致
      const timeDistribution = this.selectComponent('#timeDistributionChart');
      const focusHeatmap = this.selectComponent('#heatmapChart');
      
      console.log('组件检查结果:', {
        timeDistribution: !!timeDistribution,
        focusHeatmap: !!focusHeatmap
      });
      
      // 强制忽略组件检查，始终返回true以尝试继续初始化
      return true;
    } catch (e) {
      console.error('组件检查失败:', e);
      return false;
    }
  },
  
  // 安全的图表初始化函数
  safeInitCharts: function() {
    try {
      if (this.data.chartErrorCount > 3) {
        console.log('图表初始化失败次数过多，禁用图表功能');
        this.setData({ disableCharts: true });
        return;
      }
      
      this.initCharts();
    } catch (e) {
      console.error('安全初始化图表失败:', e);
      this.setData({ 
        chartErrorCount: this.data.chartErrorCount + 1 
      });
    }
  },
  
  // 修改getLunarDay函数，仅显示特殊节日
  getLunarDay: function(year, month, day) {
    try {
      // 简化的农历信息处理
      if (this.data.lunarInfo && Array.isArray(this.data.lunarInfo)) {
        const found = this.data.lunarInfo.find(info => 
          info.month === month && info.day === day
        );
        if (found) {
          return found.name;
        }
      }
      return ''; // 普通日不显示任何文字
    } catch (e) {
      console.error('获取农历信息失败:', e);
      return '';
    }
  },
  
  // 添加缺失的getDayCount函数
  getDayCount: function(startDate, endDate) {
    try {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const timeDiff = Math.abs(end.getTime() - start.getTime());
      const dayCount = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // +1包含起始日
      return dayCount;
    } catch (e) {
      console.error('计算天数差异失败:', e);
      return 1; // 默认返回1天
    }
  },
  
  // 增强节假日信息数据
  updateLunarInfo: function() {
    // 扩展更多节假日数据
    const holidays = [
      { month: 1, day: 1, name: '元旦' },
      { month: 2, day: 14, name: '情人节' },
      { month: 3, day: 8, name: '妇女节' },
      { month: 3, day: 12, name: '植树节' },
      { month: 4, day: 1, name: '愚人节' },
      { month: 4, day: 5, name: '清明' },
      { month: 5, day: 1, name: '劳动节' },
      { month: 5, day: 4, name: '青年节' },
      { month: 6, day: 1, name: '儿童节' },
      { month: 9, day: 10, name: '教师节' },
      { month: 10, day: 1, name: '国庆节' },
      { month: 12, day: 25, name: '圣诞节' }
    ];
    
    this.setData({
      lunarInfo: holidays
    });
  },
  
  // 添加缺失的格式化专注时间函数
  formatFocusTime: function(minutes) {
    if (!minutes || minutes <= 0) return '0分钟';
    
    if (minutes < 60) {
      return minutes + '分钟';
    } else {
      const hours = Math.floor(minutes / 60);
      const remainMinutes = minutes % 60;
      if (remainMinutes === 0) {
        return hours + '小时';
      } else {
        return hours + '小时' + remainMinutes + '分钟';
      }
    }
  },
  
  // 切换时间分布周期
  switchTimeDistributionPeriod: function(e) {
    const period = e.currentTarget.dataset.period;
    if (period === this.data.timeDistributionPeriod) return; // 已是当前选中项，无需切换
    
    this.setData({
      timeDistributionPeriod: period
    });
    
    // 根据选中的周期更新图表数据
    if (period === 'day') {
      this.initDailyTimeDistributionChart();
    } else {
      this.initWeeklyTimeDistributionChart();
    }
  },
  
  // 切换热力图周期
  switchHeatmapPeriod: function(e) {
    const period = e.currentTarget.dataset.period;
    if (period === this.data.heatmapPeriod) return; // 已是当前选中项，无需切换
    
    this.setData({
      heatmapPeriod: period
    });
    
    // 根据选中的周期更新热力图
    if (period === 'week') {
      this.initWeeklyHeatmapChart();
    } else {
      this.initMonthlyHeatmapChart();
    }
  },
  
  // 日周期时间分布图表初始化
  initDailyTimeDistributionChart: function() {
    // 原有的时间分布图初始化逻辑
    const hours = ['0时', '4时', '8时', '12时', '16时', '20时'];
    const minutes = [30, 45, 60, 90, 75, 15]; // 示例数据
    
    // 查找最大值的索引，用于突出显示
    const maxIndex = minutes.indexOf(Math.max(...minutes));
    
    // 添加日周期特定的视觉调整
    const timeChartOpts = this.getTimeDistributionChartOptions(hours, minutes, maxIndex);
    
    this.updateTimeDistributionChart(timeChartOpts);
  },
  
  // 周周期时间分布图表初始化
  initWeeklyTimeDistributionChart: function() {
    // 生成周数据
    const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    // 生成每天的平均专注分钟数
    const minutes = [45, 60, 35, 80, 70, 30, 50]; // 示例数据
    
    // 查找最大值的索引，用于突出显示
    const maxIndex = minutes.indexOf(Math.max(...minutes));
    
    // 配置周视图的图表选项
    const timeChartOpts = this.getTimeDistributionChartOptions(days, minutes, maxIndex);
    
    // 更新图表
    this.updateTimeDistributionChart(timeChartOpts);
  },
  
  // 获取时间分布图表配置
  getTimeDistributionChartOptions: function(categories, values, maxIndex) {
    // 为每个柱子准备不同的样式，突出显示最高值
    const itemStyles = values.map((value, index) => {
      if (index === maxIndex) {
        // 突出显示最高值的柱子
        return {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#FF7D7D' },
            { offset: 1, color: '#FF5252' }
          ]),
          borderRadius: [6, 6, 0, 0],
          shadowColor: 'rgba(255, 82, 82, 0.3)',
          shadowBlur: 10
        };
      } else {
        // 普通柱子样式
        return {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#FFB7B7' },
            { offset: 1, color: '#FF9E9E' }
          ]),
          borderRadius: [4, 4, 0, 0]
        };
      }
    });
    
    return {
      animation: true,
      animationDuration: 1000,
      animationEasing: 'elasticOut',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function(params) {
          return `${params[0].name}: ${params[0].value} 分钟`;
        },
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#FFE0E0',
        borderWidth: 1,
        padding: [8, 12],
        textStyle: {
          color: '#333',
          fontSize: 12
        },
        extraCssText: 'box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); border-radius: 4px;'
      },
      grid: {
        top: '50',
        left: '3%',
        right: '3%',
        bottom: '15%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: categories,
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 14
        }
      },
      yAxis: {
        type: 'value',
        name: '专注分钟',
        nameTextStyle: {
          color: '#999999',
          fontSize: 12,
          padding: [0, 0, 8, 0]
        },
        min: 0,
        max: function(value) {
          return Math.ceil(value.max * 1.2 / 10) * 10; // 向上取整到10的倍数，并增加20%空间
        },
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12
        },
        splitLine: {
          lineStyle: {
            color: '#F5F5F5',
            type: 'dashed'
          }
        }
      },
      series: [{
        name: '专注时长',
        type: 'bar',
        data: values,
        barWidth: '40%',
        itemStyle: {
          borderRadius: [4, 4, 0, 0]
        },
        // 使用自定义函数为每个柱子设置样式
        renderItem: function(params, api) {
          const index = params.dataIndex;
          return itemStyles[index];
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 15,
            shadowColor: 'rgba(255, 107, 107, 0.5)'
          }
        },
        label: {
          show: true,
          position: 'top',
          fontSize: 12,
          color: '#666666',
          formatter: function(params) {
            // 为最高值添加标记
            if (params.dataIndex === maxIndex) {
              return params.value + ' ↑';
            }
            return params.value;
          }
        }
      }]
    };
  },
  
  // 更新时间分布图表
  updateTimeDistributionChart: function(options) {
    this.setData({
      timeChartOpts: options
    });
    
    // 使用微信小程序的Canvas绘制柱状图
    this.selectComponent('#timeDistributionChart').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(options);
      return chart;
    });
  },
  
  // 周热力图初始化 - 优化版
  initWeeklyHeatmapChart: function() {
    // 准备周热力图的数据
    const weekDays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    const periods = 4; // 一天分为4个时段：凌晨、上午、下午、晚上
    const periodNames = ['凌晨', '上午', '下午', '晚上'];
    const data = [];
    
    // 生成一周的热力图数据（确保只有7天）
    for (let i = 0; i < 7; i++) { // 只取一周7天
      for (let j = 0; j < periods; j++) {
        // 随机生成专注时长（0-120分钟）
        const focusMinutes = Math.floor(Math.random() * 120);
        // 为每个时段生成一条数据
        data.push({
          value: [i, j, focusMinutes],
          itemStyle: {
            // 圆角矩形
            borderRadius: 4
          }
        });
      }
    }
    
    // 周视图热力图配置
    const heatmapOpts = {
      animation: true,
      animationDuration: 800,
      animationEasing: 'cubicOut',
      tooltip: {
        position: 'top',
        formatter: function(params) {
          const dayIndex = params.data.value[0];
          const periodIndex = params.data.value[1];
          const minutes = params.data.value[2];
          return `${weekDays[dayIndex]} ${periodNames[periodIndex]}<br/>专注时长：${minutes} 分钟`;
        },
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#FFE0E0',
        borderWidth: 1,
        padding: [8, 12],
        textStyle: {
          color: '#333',
          fontSize: 12
        },
        extraCssText: 'box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); border-radius: 4px;'
      },
      grid: {
        top: '50',
        left: '5%',
        right: '5%',
        bottom: '60',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: weekDays,
        splitArea: {
          show: true,
          areaStyle: {
            color: ['rgba(255,255,255,0.5)', 'rgba(255,250,250,0.5)']
          }
        },
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 14
        }
      },
      yAxis: {
        type: 'category',
        data: periodNames,
        splitArea: {
          show: true,
          areaStyle: {
            color: ['rgba(255,255,255,0.5)', 'rgba(255,250,250,0.5)']
          }
        },
        axisLine: {
          lineStyle: {
            color: '#EEEEEE'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#666666',
          fontSize: 12,
          margin: 14
        }
      },
      visualMap: {
        min: 0,
        max: 120,
        calculable: false,
        orient: 'horizontal',
        left: 'center',
        bottom: '10',
        itemWidth: 12,
        itemHeight: 70,
        text: ['高', '低'],
        textGap: 8,
        textStyle: {
          color: '#666666'
        },
        inRange: {
          color: ['#FFFAFA', '#FFE0E0', '#FFBDBD', '#FF9E9E', '#FF6B6B']
        },
        show: true
      },
      series: [{
        name: '专注时长',
        type: 'heatmap',
        data: data,
        label: {
          show: false
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(255, 107, 107, 0.5)'
          }
        },
        itemStyle: {
          borderWidth: 1,
          borderColor: 'rgba(255, 255, 255, 0.8)'
        }
      }]
    };
    
    // 更新热力图
    this.setData({
      heatmapOpts: heatmapOpts
    });
    
    this.selectComponent('#heatmapChart').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(heatmapOpts);
      return chart;
    });
  },
  
  // 月热力图初始化
  initMonthlyHeatmapChart: function() {
    // 准备数据 - 一个月的热力图
    const days = 30; // 一个月平均30天
    const periods = 4; // 每天分为4个时段
    const data = [];
    const periodNames = ['凌晨', '上午', '下午', '晚上'];
    
    // 生成一个月的随机数据
    // 日期标签：1日到30日
    const dateLabels = [];
    for (let i = 1; i <= days; i++) {
      dateLabels.push(`${i}日`);
    }
    
    // 生成每天的热力图数据
    for (let i = 0; i < days; i++) {
      for (let j = 0; j < periods; j++) {
        // 随机生成专注时长
        const focusMinutes = Math.floor(Math.random() * 120);
        data.push({
          value: [i, j, focusMinutes],
          itemStyle: {
            borderRadius: 4
          }
        });
      }
    }
    
    // 月视图热力图配置
    const heatmapOpts = {
      animation: true,
      animationDuration: 800,
      tooltip: {
        position: 'top',
        formatter: function(params) {
          const dayIndex = params.data.value[0];
          const periodIndex = params.data.value[1];
          const minutes = params.data.value[2];
          return `${dateLabels[dayIndex]} ${periodNames[periodIndex]}<br/>专注时长：${minutes} 分钟`;
        },
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#FFE0E0',
        borderWidth: 1,
        padding: [8, 12],
        textStyle: {
          color: '#333',
          fontSize: 12
        }
      },
      grid: {
        top: '50',
        left: '3%',
        right: '6%',
        bottom: '60',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: dateLabels,
        axisLabel: {
          interval: 4, // 每5天显示一个标签
          fontSize: 12
        }
      },
      yAxis: {
        type: 'category',
        data: periodNames
      },
      visualMap: {
        min: 0,
        max: 120,
        calculable: false,
        orient: 'horizontal',
        left: 'center',
        bottom: '10',
        text: ['高', '低'],
        inRange: {
          color: ['#FFFAFA', '#FFE0E0', '#FFBDBD', '#FF9E9E', '#FF6B6B']
        }
      },
      series: [{
        name: '专注时长',
        type: 'heatmap',
        data: data,
        label: {
          show: false
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(255, 107, 107, 0.5)'
          }
        },
        itemStyle: {
          borderWidth: 1,
          borderColor: 'rgba(255, 255, 255, 0.8)'
        }
      }]
    };
    
    // 更新热力图
    this.setData({
      heatmapOpts: heatmapOpts
    });
    
    this.selectComponent('#heatmapChart').init((canvas, width, height, dpr) => {
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height,
        devicePixelRatio: dpr
      });
      chart.setOption(heatmapOpts);
      return chart;
    });
  }
}); 