// 设置页面
Page({
  data: {
    // 主题颜色选项
    themeColors: [
      { name: '蓝色', value: '#3498db', selected: true },
      { name: '绿色', value: '#2ecc71', selected: false },
      { name: '紫色', value: '#9b59b6', selected: false },
      { name: '橙色', value: '#e67e22', selected: false },
      { name: '红色', value: '#e74c3c', selected: false }
    ],
    
    // 背景图选项 - 使用纯色背景代替图片
    backgroundImages: [
      { id: 'bg1', color: '#87CEEB', selected: true },  // 天蓝色
      { id: 'bg2', color: '#90EE90', selected: false }, // 淡绿色
      { id: 'bg3', color: '#FFA07A', selected: false }, // 浅鲑鱼色
      { id: 'bg4', color: '#DDA0DD', selected: false }, // 梅红色
    ],
    
    // 励志格言
    motto: '坚持每一天，成就更好的自己',
    
    // 当前设置
    currentTheme: '#3498db',
    currentBackground: '#87CEEB'  // 默认背景色
  },
  
  onLoad() {
    // 从本地存储加载用户设置
    try {
      const userSettings = wx.getStorageSync('userSettings');
      if (userSettings) {
        // 更新主题颜色选中状态
        let themeColors = this.data.themeColors.map(color => {
          color.selected = (color.value === userSettings.theme);
          return color;
        });
        
        // 更新背景图选中状态
        let backgroundImages = this.data.backgroundImages.map(bg => {
          bg.selected = (bg.color === userSettings.background);
          return bg;
        });
        
        this.setData({
          themeColors,
          backgroundImages,
          motto: userSettings.motto || this.data.motto,
          currentTheme: userSettings.theme || this.data.currentTheme,
          currentBackground: userSettings.background || this.data.currentBackground
        });
      }
    } catch (e) {
      console.error('加载设置时出错：', e);
    }
  },
  
  // 选择主题颜色
  selectThemeColor(e) {
    const index = e.currentTarget.dataset.index;
    let themeColors = this.data.themeColors;
    
    // 更新选中状态
    themeColors.forEach((item, i) => {
      item.selected = (i === index);
    });
    
    this.setData({
      themeColors,
      currentTheme: themeColors[index].value
    });
    
    // 保存设置
    this.saveSettings();
  },
  
  // 选择背景图
  selectBackground(e) {
    const index = e.currentTarget.dataset.index;
    let backgroundImages = this.data.backgroundImages;
    
    // 更新选中状态
    backgroundImages.forEach((item, i) => {
      item.selected = (i === index);
    });
    
    this.setData({
      backgroundImages,
      currentBackground: backgroundImages[index].color
    });
    
    // 保存设置
    this.saveSettings();
  },
  
  // 更新励志格言
  updateMotto(e) {
    this.setData({
      motto: e.detail.value
    });
  },
  
  // 保存励志格言
  saveMotto() {
    this.saveSettings();
    wx.showToast({
      title: '保存成功',
      icon: 'success'
    });
  },
  
  // 保存所有设置到本地存储
  saveSettings() {
    try {
      wx.setStorageSync('userSettings', {
        theme: this.data.currentTheme,
        background: this.data.currentBackground,
        motto: this.data.motto
      });
      
      // 发布事件通知其他页面设置已更改
      try {
        const app = getApp();
        if (app && app.globalData) {
          app.globalData.themeChanged = true;
        }
      } catch (err) {
        console.log('无法更新全局主题状态：', err);
        // 非关键错误，可以继续执行
      }
    } catch (e) {
      console.error('保存设置时出错：', e);
      wx.showToast({
        title: '保存失败',
        icon: 'none'
      });
    }
  }
}); 