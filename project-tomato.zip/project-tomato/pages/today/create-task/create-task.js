// 页面对象
Page({
  data: {
    taskName: '',
    taskDate: '',
    today: '',
    taskDescription: '',
    // 可能的其他数据
  },
  
  onLoad() {
    // 设置今日日期
    const today = new Date();
    const formattedToday = this.formatDate(today);
    this.setData({
      taskDate: formattedToday,
      today: formattedToday
    });
  },
  
  // 输入任务名称
  inputTaskName(e) {
    this.setData({
      taskName: e.detail.value
    });
  },
  
  // 日期格式化函数
  formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },
  
  // 创建任务 - 直接数据库版本
  createTask() {
    // 验证表单
    if (!this.data.taskName) {
      wx.showToast({
        title: '请输入任务名称',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '创建中...'
    });
    
    // 修改任务数据结构，确保包含必要字段
    const taskData = {
      name: this.data.taskName,
      date: this.data.taskDate,
      description: this.data.taskDescription || '',
      completed: false,
      createTime: new Date().getTime(),
      userId: getApp().globalData.userId, // 添加用户ID
      priority: {
        important: false,
        urgent: false
      },
      tags: [],
      subtasks: []
    };
    
    // 直接使用数据库创建
    const db = wx.cloud.database();
    db.collection('tasks').add({
      data: taskData,
      success: res => {
        // 添加ID到taskData以便本地更新
        taskData._id = res._id;
        taskData.id = res._id; // 同时设置id字段以确保兼容性
        
        wx.hideLoading();
        wx.showToast({
          title: '创建成功',
          icon: 'success'
        });
        
        // 使用app.notifyTaskUpdate()方法通知应用更新
        const app = getApp();
        app.notifyTaskUpdate();
        app.globalData.needRefreshTaskList = true;
        
        // 把新任务添加到app.globalData中，确保数据同步
        if (!app.globalData.tasks) {
          app.globalData.tasks = [];
        }
        app.globalData.tasks.unshift(taskData);
        
        // 尝试直接更新today页面
        const pages = getCurrentPages();
        const todayPage = pages.find(p => p.route === 'pages/today/today');
        if (todayPage && todayPage.data && todayPage.data.todayTasks) {
          // 直接更新today页面的任务数据，而不是调用fetchTodayTasks
          const newTasks = [taskData, ...todayPage.data.todayTasks];
          todayPage.setData({
            todayTasks: newTasks,
            'todayFocus.completedTasks': todayPage.getCompletedTasksCount ? 
              todayPage.getCompletedTasksCount() + (taskData.completed ? 1 : 0) : 
              todayPage.data.todayFocus.completedTasks
          });
          console.log('直接更新today页面任务数据，新增任务:', taskData.name);
        }
        
        // 设置标志，防止返回页面后再次刷新
        app.globalData.justCreatedTask = true;
        
        // 返回上一页
        setTimeout(() => {
          wx.navigateBack();
        }, 500);
      },
      fail: err => {
        console.error('创建任务失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '创建失败',
          icon: 'none'
        });
      }
    });
  },
  
  // 日期选择器变更
  onDateChange(e) {
    this.setData({
      taskDate: e.detail.value
    });
  },
  
  // 输入描述
  inputDescription(e) {
    this.setData({
      taskDescription: e.detail.value
    });
  },
  
  // 取消操作
  cancel() {
    wx.navigateBack();
  }
}); 