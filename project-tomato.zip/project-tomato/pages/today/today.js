// 今日页面逻辑
const { taskAPI, statisticsAPI, goalAPI, achievementAPI } = require('../../utils/api.js');

Page({
  data: {
    currentDate: '',
    weekday: '',
    weather: null,
    todayTasks: [],
    todayFocus: {
      sessions: 0,
      duration: 0,
      completedTasks: 0
    },
    // 新增数据字段
    goals: {
      daily: { target: 180, current: 0 }, // 默认3小时(180分钟)
      weekly: { target: 1200, current: 0 }, // 默认20小时
      monthly: { target: 5400, current: 0 }  // 默认90小时
    },
    achievements: {
      totalHours: 0,
      percentage: 0  // 一万小时的完成百分比
    },
    showGoalSetting: false,
    activeGoalType: 'daily',
    todayCheckin: false,
    // 界面控制
    editingGoal: false,
    showTaskDialog: false,
    newTaskInput: '',
    // 临时存储编辑中的目标值
    tempSettings: {
      daily: 180,
      weekly: 1200,
      monthly: 5400
    }
  },
  
  onLoad() {
    this.initDateInfo();
    this.fetchGoals();
    this.fetchAchievements();
  },
  
  onShow() {
    console.log('today页面显示');
    
    const app = getApp();
    
    // 如果刚刚创建了任务，跳过刷新以防覆盖
    if (app.globalData.justCreatedTask) {
      console.log('检测到刚创建任务，跳过刷新');
      app.globalData.justCreatedTask = false;
      app.globalData.needRefreshTaskList = false;
      
      // 仅刷新其他数据
      this.fetchTodayFocus();
      this.checkTodayGoalStatus();
      return; // 提前返回，不执行任务刷新
    }
    
    // 正常刷新逻辑
    if (app.globalData.needRefreshTaskList) {
      console.log('检测到需要刷新任务列表');
      this.fetchTodayTasks();
      app.globalData.needRefreshTaskList = false;
    } else {
      console.log('无需刷新任务列表');
    }
    
    // 其他数据照常刷新
    this.fetchTodayFocus();
    this.checkTodayGoalStatus();
    this.forceUpdateAchievements();
  },
  
  // 初始化日期信息
  initDateInfo() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;
    const day = today.getDate();
    
    const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    const weekday = weekdays[today.getDay()];
    
    this.setData({
      currentDate: `${year}年${month}月${day}日`,
      weekday: weekday
    });
  },
  
  // 获取今日任务
  fetchTodayTasks() {
    console.log('开始获取今日任务');
    
    // 获取用户ID
    const userId = getApp().globalData.userId || wx.getStorageSync('userId');
    
    // 从缓存中获取最近使用的日期，如果没有则使用当前日期
    let queryDate = wx.getStorageSync('lastUsedDate') || this.formatDate(new Date());
    console.log('查询日期:', queryDate);
    
    wx.showLoading({ title: '加载中' });
    
    // 直接查询数据库，但不限制日期，而是获取所有用户的任务
    const db = wx.cloud.database();
    db.collection('tasks')
      .where({
        userId: userId,
        // 移除date条件，获取所有日期的任务
      })
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        console.log('获取所有任务成功:', res.data);
        
        // 获取已删除任务ID列表
        const app = getApp();
        const deletedIds = app.globalData.deletedTaskIds || [];
        
        // 过滤已删除的任务
        let allTasks = res.data.filter(task => 
          !deletedIds.includes(task._id) && !deletedIds.includes(task.id)
        );
        
        // 找到这些任务使用的日期
        const taskDates = [...new Set(allTasks.map(task => task.date))];
        console.log('发现的任务日期:', taskDates);
        
        // 如果有任务日期，使用第一个作为当前显示日期
        if (taskDates.length > 0) {
          queryDate = taskDates[0];
          // 保存到本地存储以便后续使用
          wx.setStorageSync('lastUsedDate', queryDate);
        }
        
        // 过滤得到当前日期的任务
        const todayTasks = allTasks.filter(task => task.date === queryDate);
        
        // 更新列表
        this.setData({
          todayTasks: todayTasks,
          'todayFocus.completedTasks': this.getCompletedTasksCount()
        });
        
        wx.hideLoading();
        console.log('今日任务列表已更新，查询日期:', queryDate, '任务数:', todayTasks.length);
      })
      .catch(err => {
        console.error('获取任务失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '获取任务失败',
          icon: 'none'
        });
      });
  },
  
  // 获取今日专注统计 - 优化版
  fetchTodayFocus() {
    const today = new Date();
    const dateString = this.formatDate(today);
    
    // 首先尝试从本地存储获取最新数据
    try {
      const pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
      const todayRecord = pomodoroRecord[dateString] || { count: 0, minutes: 0 };
      const completedTasks = this.getCompletedTasksCount();
      
      // 先用本地数据快速更新UI
      this.setData({
        todayFocus: {
          sessions: todayRecord.count || 0,
          duration: todayRecord.minutes || 0,
          completedTasks: completedTasks
        }
      });
      
      // 更新目标进度
      this.updateGoalProgress('daily', todayRecord.minutes || 0);
      
      console.log('从本地获取的今日专注数据:', todayRecord, '完成任务数:', completedTasks);
    } catch (e) {
      console.error('读取本地专注记录失败:', e);
    }
    
    // 然后从服务器获取最新数据（如果API可用）
    if (statisticsAPI && typeof statisticsAPI.getStatistics === 'function') {
    statisticsAPI.getStatistics({
      userId: getApp().globalData.userId || wx.getStorageSync('userId'),
      startDate: dateString,
      endDate: dateString,
      period: 'daily'
    })
    .then(data => {
      if (data && data.dailyFocus && data.dailyFocus.length > 0) {
        const todayData = data.dailyFocus[0];
        const duration = todayData.duration || 0;
        
        this.setData({
          todayFocus: {
            sessions: todayData.sessions || 0,
            duration: duration
          }
        });
        
        // 更新目标进度
        this.updateGoalProgress('daily', duration);
      }
    })
    .catch(err => {
      console.error('获取今日专注统计失败:', err);
        // 错误处理已在尝试本地数据时完成，此处不需额外处理
      });
    }
  },
  
  // 新增方法：获取今日已完成的任务数量
  getCompletedTasksCount() {
    try {
      // 从本地获取今日已完成的任务
      const completedTasks = this.data.todayTasks.filter(task => task.completed).length;
      return completedTasks;
    } catch (e) {
      console.error('获取已完成任务数量失败:', e);
      return 0;
    }
  },
  
  // 日期格式化
  formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },
  
  // 切换任务完成状态
  toggleTaskStatus: function(e) {
    const taskId = e.currentTarget.dataset.id;
    const taskIndex = this.data.todayTasks.findIndex(task => task._id === taskId);
    
    if (taskIndex === -1) return;
    
    // 获取任务信息
    const task = this.data.todayTasks[taskIndex];
    const newStatus = !task.completed;
    
    // 更新数据库
    wx.cloud.database().collection('tasks').doc(taskId).update({
      data: {
        completed: newStatus,
        completedAt: newStatus ? new Date() : null
      },
      success: () => {
        // 更新本地数据
        const updatedTasks = [...this.data.todayTasks];
        updatedTasks[taskIndex].completed = newStatus;
        updatedTasks[taskIndex].completedAt = newStatus ? new Date() : null;
        
        this.setData({
          todayTasks: updatedTasks
        });
        
        // 记录任务完成状态到统计系统
        if (newStatus) {
          this.recordTaskCompletion(task);
        } else {
          this.removeTaskCompletion(task);
        }
        
        // 通知统计页面刷新
        getApp().globalData.statisticsNeedRefresh = true;
      }
    });
  },
  
  // 添加记录任务完成方法
  recordTaskCompletion: function(task) {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // 读取完成任务记录
      let completedTasks = wx.getStorageSync('completedTasks') || {};
      if (!completedTasks[today]) {
        completedTasks[today] = [];
      }
      
      // 检查任务是否已记录
      const taskExists = completedTasks[today].some(t => t.taskId === task._id);
      
      if (!taskExists) {
        // 添加到记录
        completedTasks[today].push({
          taskId: task._id,
          taskTitle: task.name || task.title,
          completedAt: new Date().toISOString(),
          tags: task.tags || []
        });
        
        wx.setStorageSync('completedTasks', completedTasks);
        console.log('任务完成已记录到统计系统:', task.name || task.title);
      }
    } catch (e) {
      console.error('记录任务完成失败:', e);
    }
  },
  
  // 移除任务完成记录
  removeTaskCompletion: function(task) {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // 读取完成任务记录
      let completedTasks = wx.getStorageSync('completedTasks') || {};
      if (!completedTasks[today]) return;
      
      // 从记录中移除
      completedTasks[today] = completedTasks[today].filter(t => t.taskId !== task._id);
      
      wx.setStorageSync('completedTasks', completedTasks);
      console.log('任务完成记录已移除:', task.name || task.title);
    } catch (e) {
      console.error('移除任务完成记录失败:', e);
    }
  },
  
  // 开始专注
  startFocus(e) {
    const taskId = e.currentTarget.dataset.id;
    const task = this.data.todayTasks.find(t => t.id === taskId);
    
    if (task) {
      // 修复：确保使用title或fallback到name属性
      const taskTitle = task.title || task.name || '专注';
      
      wx.navigateTo({
        url: `/pages/pomodoro/pomodoro?taskId=${taskId}&taskTitle=${encodeURIComponent(taskTitle)}`
      });
    } else {
      console.error('未找到对应的任务:', taskId);
      wx.showToast({
        title: '任务不存在',
        icon: 'none'
      });
    }
  },
  
  // 创建新任务
  createTask() {
    wx.navigateTo({
      url: '/pages/today/create-task/create-task'
    });
  },
  
  // 获取目标数据的优化版本
  fetchGoals() {
    const userId = getApp().globalData.userId || wx.getStorageSync('userId');
    
    // 先尝试从本地存储获取目标数据
    try {
      const localGoals = wx.getStorageSync('userGoals');
      if (localGoals) {
        // 更新目标设置
      this.setData({
          'goals.daily.target': localGoals.daily || 180,
          'goals.weekly.target': localGoals.weekly || 1200,
          'goals.monthly.target': localGoals.monthly || 5400
        });
        
        // 获取当前专注记录，计算进度
        const today = new Date();
        const dateString = this.formatDate(today);
        const pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
        const todayRecord = pomodoroRecord[dateString] || { minutes: 0 };
        
        // 更新今日目标进度
        this.updateGoalProgress('daily', todayRecord.minutes || 0);
        
        // 计算本周专注分钟
        let weeklyMinutes = 0;
        const dates = this.getCurrentWeekDates();
        dates.forEach(date => {
          const dateStr = this.formatDate(date);
          if (pomodoroRecord[dateStr]) {
            weeklyMinutes += pomodoroRecord[dateStr].minutes || 0;
          }
        });
        
        // 更新本周目标进度
        this.updateGoalProgress('weekly', weeklyMinutes);
        
        // 计算本月专注分钟
        let monthlyMinutes = 0;
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        
        Object.keys(pomodoroRecord).forEach(dateStr => {
          const recordDate = new Date(dateStr);
          if (recordDate.getMonth() === currentMonth && 
              recordDate.getFullYear() === currentYear) {
            monthlyMinutes += pomodoroRecord[dateStr].minutes || 0;
          }
        });
        
        // 更新本月目标进度
        this.updateGoalProgress('monthly', monthlyMinutes);
      }
    } catch (e) {
      console.error('读取本地目标数据失败:', e);
    }
    
    // 如果API可用，从服务器获取最新数据
    if (goalAPI && typeof goalAPI.getGoals === 'function') {
    goalAPI.getGoals({ userId })
        .then(data => {
          if (data) {
          // 更新目标设置
          this.setData({
              'goals.daily.target': data.daily || 180,
              'goals.weekly.target': data.weekly || 1200, 
              'goals.monthly.target': data.monthly || 5400
            });
            
            // 检查目标达成状态
            this.checkTodayGoalStatus();
        }
      })
      .catch(err => {
          console.error('获取目标数据失败:', err);
        });
    }
  },
  
  // 获取当前周的日期数组
  getCurrentWeekDates() {
    const today = new Date();
    const day = today.getDay() || 7; // 如果是周日，getDay()返回0，我们当作7
    const dates = [];
    
    // 获取本周一到今天(或周日)的日期
    for (let i = 1; i <= 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() - day + i);
      dates.push(date);
    }
    
    return dates;
  },
  
  // 获取成就数据的优化版本
  fetchAchievements() {
    // 先初始化为0，确保没有数据时显示0
      this.setData({
        achievements: {
          totalHours: 0,
          percentage: 0
        }
      });
    
    const userId = getApp().globalData.userId || wx.getStorageSync('userId');
    
    // 先计算本地数据
    this.calculateAchievements();
    
    // 如果API可用，从服务器获取最新数据
    if (achievementAPI && typeof achievementAPI.getAchievements === 'function') {
    achievementAPI.getAchievements({ userId })
        .then(data => {
          if (data) {
            const totalHours = data.totalHours || 0;
            const percentage = (totalHours / 10000 * 100).toFixed(2);
          
          this.setData({
            achievements: {
                totalHours: totalHours,
                percentage: parseFloat(percentage)
              }
            });
            
            // 更新本地存储
            wx.setStorageSync('userAchievements', {
              userId,
              totalHours,
              percentage: parseFloat(percentage)
            });
        }
      })
      .catch(err => {
          console.error('获取成就数据失败:', err);
        });
    }
  },
  
  // 新增方法：更新目标进度
  updateGoalProgress(type, minutes) {
    if (!type || minutes === undefined) return;
    
    // 设置当前进度
    this.setData({
      [`goals.${type}.current`]: minutes
    });
    
    // 检查是否达成目标
    const isCompleted = minutes >= this.data.goals[type].target;
    
    // 可以添加达成目标时的特殊处理
    if (isCompleted) {
      console.log(`${type}目标已达成!`);
      // 这里可以添加目标达成的动画或通知
    }
  },
  
  // 新增方法：检查目标完成情况
  checkGoalCompletion(type) {
    const { goals, todayCheckin } = this.data;
    
    if (goals[type].current >= goals[type].target && !todayCheckin) {
      // 目标达成，触发打卡
      this.doCheckin(type);
    }
  },
  
  // 新增方法：执行打卡
  doCheckin(type) {
    const userId = getApp().globalData.userId || wx.getStorageSync('userId');
    
    goalAPI.checkin({
      userId,
      goalType: type,
      date: this.formatDate(new Date())
    })
    .then(() => {
      this.setData({ todayCheckin: true });
      
      // 显示打卡成功动画
      wx.showToast({
        title: '今日目标已达成，打卡成功！',
        icon: 'success',
        duration: 2000
      });
      
      // 更新成就进度
      this.updateAchievement(this.data.todayFocus.duration);
    })
    .catch(err => {
      console.error('打卡失败:', err);
    });
  },
  
  // 新增方法：更新长期成就
  updateAchievement(minutes) {
    const hoursToAdd = minutes / 60;
    const totalHours = this.data.achievements.totalHours + hoursToAdd;
    const percentage = (totalHours / 10000 * 100).toFixed(2);
    
    this.setData({
      achievements: {
        totalHours,
        percentage: parseFloat(percentage)
      }
    });
    
    // 更新到服务器
    achievementAPI.updateAchievement({
      userId: getApp().globalData.userId || wx.getStorageSync('userId'),
      hoursToAdd
    }).catch(err => {
      console.error('更新成就进度失败:', err);
    });
  },
  
  // 新增方法：检查今日目标状态
  checkTodayGoalStatus() {
    // 获取今日专注记录
    try {
      const today = new Date();
      const dateString = this.formatDate(today);
      const pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
      
      // 计算今日进度
      const todayRecord = pomodoroRecord[dateString] || { minutes: 0 };
      this.updateGoalProgress('daily', todayRecord.minutes || 0);
      
      // 计算本周进度
      const weeklyMinutes = this.calculateWeeklyMinutes(pomodoroRecord);
      this.updateGoalProgress('weekly', weeklyMinutes);
      
      // 计算本月进度
      const monthlyMinutes = this.calculateMonthlyMinutes(pomodoroRecord);
      this.updateGoalProgress('monthly', monthlyMinutes);
      
      console.log(`目标进度更新: 今日=${todayRecord.minutes}分钟, 本周=${weeklyMinutes}分钟, 本月=${monthlyMinutes}分钟`);
    } catch (e) {
      console.error('检查目标状态失败:', e);
    }
  },
  
  // 计算本周专注分钟总数
  calculateWeeklyMinutes(records) {
    try {
      if (!records) return 0;
      
      const today = new Date();
      // 获取本周日期范围
      const weekDates = this.getCurrentWeekDates();
      const weekDateStrings = weekDates.map(date => this.formatDate(date));
      
      // 累计本周所有日期的专注分钟
      let totalMinutes = 0;
      weekDateStrings.forEach(dateStr => {
        if (records[dateStr] && records[dateStr].minutes) {
          totalMinutes += records[dateStr].minutes;
        }
      });
      
      return totalMinutes;
    } catch (e) {
      console.error('计算本周专注分钟失败:', e);
      return 0;
    }
  },
  
  // 计算本月专注分钟总数
  calculateMonthlyMinutes(records) {
    try {
      if (!records) return 0;
      
      const today = new Date();
      const currentYear = today.getFullYear();
      const currentMonth = today.getMonth();
      
      // 累计本月所有日期的专注分钟
      let totalMinutes = 0;
      Object.keys(records).forEach(dateStr => {
        try {
          // 解析日期字符串 (格式：YYYY-MM-DD)
          const dateParts = dateStr.split('-');
          if (dateParts.length !== 3) return;
          
          const year = parseInt(dateParts[0]);
          const month = parseInt(dateParts[1]) - 1; // 月份从0开始
          
          // 检查是否是当前年月
          if (year === currentYear && month === currentMonth) {
            totalMinutes += records[dateStr].minutes || 0;
          }
        } catch (err) {
          console.error('解析日期失败:', dateStr, err);
        }
      });
      
      return totalMinutes;
    } catch (e) {
      console.error('计算本月专注分钟失败:', e);
      return 0;
    }
  },
  
  // 新增方法：显示目标设置面板
  showGoalSetting() {
    // 从当前goals初始化临时设置
    this.setData({
      showGoalSetting: true,
      tempSettings: {
        daily: this.data.goals.daily.target,
        weekly: this.data.goals.weekly.target,
        monthly: this.data.goals.monthly.target
      }
    });
  },
  
  // 新增方法：关闭目标设置面板
  hideGoalSetting() {
    this.setData({
      showGoalSetting: false,
      editingGoal: false
    });
  },
  
  // 新增方法：选择目标类型
  selectGoalType(e) {
    this.setData({
      activeGoalType: e.currentTarget.dataset.type
    });
  },
  
  // 新增方法：更新目标值（添加这个处理函数）
  updateGoalValue(e) {
    const value = e.detail.value;
    const numValue = parseInt(value) || 0;
    
    // 构建对象来更新特定属性
    let updatedTemp = {};
    updatedTemp[`tempSettings.${this.data.activeGoalType}`] = numValue;
    
    this.setData(updatedTemp);
  },
  
  // 新增方法：保存目标设置
  saveGoalSetting() {
    const { activeGoalType, tempSettings } = this.data;
    const value = tempSettings[activeGoalType];
    
    // 基本验证：确保是正数
    if (value <= 0) {
        wx.showToast({
        title: '请输入大于0的分钟数',
        icon: 'none'
        });
        return;
      }
      
    // 克隆当前goals对象
    const newGoals = JSON.parse(JSON.stringify(this.data.goals));
    
    // 只更新目标值
    newGoals[activeGoalType].target = value;
    
    // 更新数据
    this.setData({
      goals: newGoals,
      showGoalSetting: false
    });
    
    // 保存到storage或云端
    this.saveGoalsToStorage();
  },
  
  // 如果需要天气功能，可以添加以下方法
  getWeatherInfo() {
    // 简单返回模拟天气数据
    this.setData({
      weather: {
        temperature: 22,
        condition: '晴朗'
      }
    });
    
    // 实际项目中可以调用天气API
    /*
    wx.request({
      url: '天气API地址',
      success: (res) => {
        this.setData({
          weather: res.data
        });
      }
    });
    */
  },
  
  // 添加关闭弹窗方法
  closeTaskDialog() {
    this.setData({
      showTaskDialog: false
    });
  },
  
  // 创建任务方法简化版
  saveNewTask() {
    const taskName = this.data.newTaskInput.trim();
    if (!taskName) {
      wx.showToast({
        title: '任务名称不能为空',
        icon: 'none'
      });
      return;
    }

    // 显示加载中
    wx.showLoading({
      title: '创建中...',
      mask: true
    });

    // A构建任务对象
    const task = {
      title: taskName,
      completed: false,
      date: this.formatDate(new Date()),
      userId: getApp().globalData.userId || wx.getStorageSync('userId')
    };

    // 调用创建任务API
    taskAPI.createTask(task)
      .then(res => {
        // 提示成功
        wx.showToast({
          title: '创建成功',
          icon: 'success'
        });
        
        // 关闭对话框并清空输入
        this.setData({
          showTaskDialog: false,
          newTaskInput: ''
        });
        
        // 将新任务添加到本地列表
        if (res.task) {
          console.log('成功创建新任务:', res.task);
          const newTasks = [...this.data.todayTasks];
          
          // 创建完整的新任务对象
          const newTask = {
            id: res.taskId || res.task.id,
            title: task.title,
            completed: false,
            date: task.date
          };
          
          newTasks.push(newTask);
          
          // 更新界面显示
          this.setData({
            todayTasks: newTasks
          });
          
          // 更新本地缓存
          wx.setStorageSync('todayTasks', newTasks);
          console.log('本地任务列表已更新:', newTasks);
          
          // 通知应用进行任务更新
          const app = getApp();
          if (app.notifyTaskUpdate) {
            app.notifyTaskUpdate();
          }
        }
      })
      .catch(err => {
        console.error('创建任务失败:', err);
        wx.showToast({
          title: '创建失败',
          icon: 'none'
        });
      })
      .finally(() => {
        // 确保始终关闭loading
        wx.hideLoading();
      });
  },
  
  // 输入任务名称
  inputNewTask(e) {
    this.setData({
      newTaskInput: e.detail.value
    });
  },
  
  // 防止点击弹窗内容时关闭弹窗
  preventClose() {
    // 阻止事件冒泡
    return;
  },
  
  // 删除任务方法
  deleteTask: function(e) {
    const taskId = e.currentTarget.dataset.id;
    
    wx.showModal({
        title: '确认删除',
        content: '确定要删除此任务吗？',
        success: (res) => {
            if (res.confirm) {
                wx.showLoading({
                    title: '删除中...'
                });
                
                // 先检查任务是否存在
                const taskExists = this.data.todayTasks.some(task => 
                    task._id === taskId || task.id === taskId
                );
                
                if (!taskExists) {
                    wx.hideLoading();
                    wx.showToast({
                        title: '任务不存在',
                        icon: 'none'
                    });
                    return;
                }
                
                // 先在本地删除，提高响应速度
                const updatedTasks = this.data.todayTasks.filter(task => 
                    task._id !== taskId && task.id !== taskId
                );
                
                this.setData({
                    todayTasks: updatedTasks
                });
                
                // 然后在数据库中删除
                const db = wx.cloud.database();
                db.collection('tasks').doc(taskId).remove()
                    .then(res => {
                        console.log('任务删除成功', res);
                        wx.hideLoading();
                        wx.showToast({
                            title: '删除成功'
                        });
                    })
                    .catch(err => {
                        console.error('删除任务失败:', err);
                        // 恢复本地数据
                        this.fetchTodayTasks();
                        wx.hideLoading();
                        wx.showToast({
                            title: '删除失败',
                            icon: 'none'
                        });
                    });
            }
        }
    });
  },
  
  // 保存目标到本地存储
  saveGoalsToStorage() {
    const userId = getApp().globalData.userId || wx.getStorageSync('userId');
    const goalsData = {
      userId: userId,
      daily: this.data.goals.daily.target,
      weekly: this.data.goals.weekly.target,
      monthly: this.data.goals.monthly.target
    };
    
    // 保存到本地存储
    wx.setStorageSync('userGoals', goalsData);
    
    // 如果API可用，也同步到云端
    if (goalAPI && typeof goalAPI.saveGoals === 'function') {
      goalAPI.saveGoals(goalsData)
        .then(() => {
          console.log('目标已同步到云端');
        })
        .catch(err => {
          console.error('同步目标失败:', err);
        });
    }
    
    wx.showToast({
      title: '设置已保存',
      icon: 'success'
    });
  },
  
  // 完成任务
  completeTask(e) {
    const taskId = e.currentTarget.dataset.id;
    if (!taskId) return;
    
    // 查找当前任务
    const tasks = [...this.data.todayTasks];
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) return;
    
    // 设置任务为已完成
    const task = tasks[taskIndex];
    
    // 先更新本地UI状态，提供即时反馈
    tasks[taskIndex].completed = true;
    this.setData({
      todayTasks: tasks
    });
    
    // 调用API更新远程状态
    taskAPI.updateTask({
      taskId,
      completed: true
    })
    .then(() => {
      wx.showToast({
        title: '任务已完成',
        icon: 'success'
      });
      
      // 更新完成次数显示
      const completedCount = this.getCompletedTasksCount();
      this.setData({
        'todayFocus.completedTasks': completedCount
      });
      
      // 刷新统计数据
      this.fetchTodayFocus();
    })
    .catch(err => {
      console.error('更新任务状态失败:', err);
      // 恢复原状态
      tasks[taskIndex].completed = task.completed;
      this.setData({
        todayTasks: tasks
      });
      
      wx.showToast({
        title: '状态更新失败',
        icon: 'none'
      });
    });
  },
  
  // 优化成就数据计算方法
  calculateAchievements() {
    try {
      // 获取所有番茄钟记录
      const pomodoroRecords = wx.getStorageSync('pomodoroRecord') || {};
      let totalMinutes = 0;
      
      // 累计所有记录的分钟数
      Object.keys(pomodoroRecords).forEach(dateStr => {
        if (pomodoroRecords[dateStr] && typeof pomodoroRecords[dateStr].minutes === 'number') {
          totalMinutes += pomodoroRecords[dateStr].minutes;
        }
      });
      
      // 将分钟转为小时并保留一位小数
      const totalHours = (totalMinutes / 60).toFixed(1);
      // 计算完成百分比，保留两位小数，进度上限为100%
      const percentage = Math.min(100, (totalHours / 10000 * 100)).toFixed(2);
      
      console.log(`成就计算: 总分钟=${totalMinutes}, 总小时=${totalHours}, 百分比=${percentage}%`);
      
      // 更新数据
      this.setData({
        achievements: {
          totalHours: totalHours,
          percentage: percentage
        }
      });
      
      // 保存到本地存储
      const userId = getApp().globalData.userId || wx.getStorageSync('userId');
      wx.setStorageSync('userAchievements', {
        userId,
        totalHours,
        percentage
      });
      
      return { totalHours, percentage };
    } catch (e) {
      console.error('计算成就数据失败:', e);
      return { totalHours: 0, percentage: 0 };
    }
  },
  
  // 强制更新成就显示
  forceUpdateAchievements() {
    try {
      // 获取所有番茄钟记录
      const pomodoroRecords = wx.getStorageSync('pomodoroRecord') || {};
      let totalMinutes = 0;
      
      // 累计所有记录的分钟数
      Object.keys(pomodoroRecords).forEach(dateStr => {
        if (pomodoroRecords[dateStr] && typeof pomodoroRecords[dateStr].minutes === 'number') {
          totalMinutes += pomodoroRecords[dateStr].minutes;
        }
      });
      
      console.log('总专注分钟数:', totalMinutes);
      
      // 将分钟转为小时并保留一位小数
      const totalHours = (totalMinutes / 60).toFixed(1);
      // 计算完成百分比，保留两位小数
      const percentage = (totalHours / 10000 * 100).toFixed(2);
      
      console.log(`成就数据：${totalHours}小时，完成${percentage}%`);
      
      // 直接更新UI显示
      this.setData({
        achievements: {
          totalHours: totalHours,
          percentage: percentage
        }
      });
      
      // 保存到本地存储
      const userId = getApp().globalData.userId || wx.getStorageSync('userId');
      wx.setStorageSync('userAchievements', {
        userId,
        totalHours,
        percentage
      });
      
      return { totalHours, percentage };
    } catch (e) {
      console.error('强制更新成就数据失败:', e);
      return { totalHours: 0, percentage: 0 };
    }
  },
  
  // 在today.js中添加loadTasks方法作为fetchTodayTasks的别名
  loadTasks: function() {
    console.log('加载任务列表');
    // 调用已有的任务获取方法
    this.fetchTodayTasks();
  }
}); 