// pages/pomodoro/pomodoro.js
const { callCloudFunction } = require('../../utils/api.js');

// 时间戳记录和计时器变量
let timerInterval = null;
let startTimestamp = 0;      // 开始时间戳
let lastTickTimestamp = 0;   // 最后一次更新时间戳
let pausedAt = 0;            // 暂停时间戳
let totalPausedTime = 0;     // 累计暂停时间(毫秒)
let pausedElapsedTime = 0;   // 暂停时已经过的时间(秒)
let phaseJustCompleted = false; // 新增：标记刚完成阶段，防止连续触发

Page({

    /**
     * 页面的初始数据
     */
    data: {
        // 计时器状态
        isRunning: false,         // 是否正在计时
        isBreak: false,           // 是否处于休息状态
        timeRemaining: 0,         // 剩余时间（秒）
        displayTime: '25:00',     // 显示时间
        progressDegree: 0,        // 进度条角度
        
        // 番茄钟设置
        workDuration: 25,         // 工作时长（分钟）
        breakDuration: 5,         // 休息时长（分钟）
        currentCycle: 1,          // 当前周期
        totalCycles: 4,           // 总周期数
        
        // 自动化设置
        autoStartBreak: true,     // 自动开始休息
        autoStartWork: false,     // 自动开始下一个工作周期
        
        // 绑定任务
        bindTaskId: '',           // 绑定的任务ID
        bindTask: null,           // 绑定的任务对象
        
        // 界面控制
        showResetButton: false,   // 显示重置按钮
        
        // 主题颜色
        workColor: '#FF6B6B',     // 工作状态颜色
        breakColor: '#4DABF7',    // 休息状态颜色
        workBgColor: '#FFF3F3',   // 工作状态背景色
        breakBgColor: '#EBF8FF',  // 休息状态背景色
        
        // 统计数据
        todayStats: {
            completedPomodoros: 0,  // 今日完成的番茄钟数
            focusMinutes: 0         // 今日专注分钟数
        },
        
        // 新增数据
        elapsedTime: 0,
        currentMode: 'focus', // 'focus' or 'break'
        timerType: 'countdown', // 'countdown' or 'countup'
        
        // 新增设置
        focusDuration: 25 * 60, // 25分钟，单位：秒
        completedCycles: 0,
        currentCycleIndex: 0,
        autoStartNextPhase: true,
        
        // 新增任务
        currentTask: null,
        
        // 新增设置面板
        showSettingsModal: false,
        
        // 新增临时设置值（编辑中）
        tempSettings: {
            focusDuration: 25 * 60,
            breakDuration: 5 * 60,
            totalCycles: 4,
            autoStartNextPhase: true
        }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // 初始化页面
        this.initTimer();
        this.loadSettings();
        this.fetchTodayStats();
        
        // 检查是否从任务页面跳转过来
        if (options.source === 'task') {
            // 从全局变量获取任务信息
            const app = getApp();
            if (app.globalData.currentFocusTask) {
                const task = app.globalData.currentFocusTask;
                
                this.setData({
                    bindTaskId: task.id,
                    currentTask: {
                        id: task.id,
                        title: task.name
                    }
                });
                
                console.log('已绑定任务(来自全局变量):', this.data.currentTask);
            }
        }
        // 保留原有代码处理直接传参的情况
        else if (options.taskId) {
            this.setData({
                bindTaskId: options.taskId,
                currentTask: {
                    id: options.taskId,
                    title: options.taskName ? decodeURIComponent(options.taskName) : '专注'
                }
            });
            console.log('已绑定任务(来自URL参数):', this.data.currentTask);
        }
        
        // 从缓存加载用户设置
        this.loadUserSettings();
        
        // 初始化显示时间
        this.updateDisplayTime();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        console.log('专注页面显示');
        
        // 从缓存获取任务信息
        try {
            const focusTask = wx.getStorageSync('currentFocusTask');
            if (focusTask && focusTask.id) {
                this.setData({
                    bindTaskId: focusTask.id,
                    currentTask: {
                        id: focusTask.id,
                        title: focusTask.name
                    }
                });
                
                console.log('已加载专注任务:', focusTask.name);
                
                // 使用后清除缓存，避免下次进入仍使用同一任务
                wx.removeStorageSync('currentFocusTask');
            }
        } catch (e) {
            console.error('获取专注任务信息失败:', e);
        }
        
        // 以下是原有代码
        // 如果计时器在运行，重新开始计时
        if (this.data.isRunning && !timerInterval) {
            this.startTimer();
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
        // 页面隐藏时清除计时器但保持状态
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
            
            // 记录暂停时间
            if (this.data.isRunning) {
                pausedAt = Date.now();
                console.log('页面隐藏，记录暂停时间', pausedAt);
            }
        }
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
        console.log('页面卸载，清理计时器');
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },

    // 开始/暂停计时器
    toggleTimer() {
        if (this.data.isRunning) {
            this.pauseTimer();
        } else {
            this.startTimer();
        }
    },
    
    // 开始计时
    startTimer() {
        console.log('开始计时', this.data.currentMode, this.data.timerType);
        
        // 避免重复启动
        if (this.data.isRunning || timerInterval) {
            console.log('计时器已在运行中');
            return;
        }
        
        const now = Date.now();
        
        // 处理从暂停状态恢复的情况
        if (pausedAt > 0) {
            console.log('从暂停状态恢复，已暂停时间：', pausedElapsedTime);
            
            // 重置所有计算变量，使用新方法计算
            startTimestamp = now - (pausedElapsedTime * 1000);
            totalPausedTime = 0; // 重置累计暂停时间
            
            // 重置暂停标记
            pausedAt = 0;
        } else {
            console.log('新的计时开始');
            // 全新开始计时
            startTimestamp = now;
            totalPausedTime = 0;
            pausedElapsedTime = 0;
        }
        
        lastTickTimestamp = now;
        
        this.setData({
            isRunning: true,
            showResetButton: true
        });
        
        // 只在新开始且是专注模式时创建记录
        if (this.data.elapsedTime === 0 && this.data.currentMode === 'focus') {
            this.createPomodoroRecord(this.data.currentTask);
        }
        
        // 启动计时器，使用更简洁的逻辑
        timerInterval = setInterval(() => {
            this.updateTimerSimple();
        }, 200);
    },
    
    // 暂停计时
    pauseTimer() {
        console.log('暂停计时');
        
        // 避免重复暂停
        if (!this.data.isRunning) {
            console.log('计时器未运行');
            return;
        }
        
        // 清除计时器
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        
        // 存储暂停时已经过的时间（确保为正值）
        // 直接使用当前显示的elapsedTime，避免重新计算
        pausedElapsedTime = Math.max(0, this.data.elapsedTime);
        pausedAt = Date.now();
        
        console.log(`暂停时间: ${new Date(pausedAt).toISOString()}, 已经过时间: ${pausedElapsedTime}秒`);
        
        this.setData({
            isRunning: false
        });
    },
    
    // 重置计时器
    resetTimer() {
        console.log('重置计时器');
        
        // 清除所有计时器相关状态
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        
        // 重置所有时间变量
        startTimestamp = 0;
        lastTickTimestamp = 0;
        pausedAt = 0;
        totalPausedTime = 0;
        pausedElapsedTime = 0;
        
        // 重置状态
        const { currentMode, timerType, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        
        this.setData({
            isRunning: false,
            elapsedTime: 0,
            displayTime: timerType === 'countdown' ? this.formatTime(totalSeconds) : '00:00',
            progressDegree: 0,
            showResetButton: false
        });
        
        // 提示用户
        wx.showToast({
            title: '计时器已重置',
            icon: 'none',
            duration: 1500
        });
    },
    
    // 跳过当前阶段
    skipPhase() {
        wx.showModal({
            title: '确认跳过',
            content: `确定要跳过当前${this.data.currentMode === 'focus' ? '专注' : '休息'}阶段吗？`,
            success: (res) => {
                if (res.confirm) {
                    // 如果正在计时，先暂停
                    if (this.data.isRunning) {
                        this.pauseTimer();
                    }
                    
                    // 完成当前阶段
                    this.completeCurrentPhase();
                }
            }
        });
    },
    
    // 计时器完成时的处理
    handleTimerComplete() {
        // 清除计时器
        clearInterval(timerInterval);
        timerInterval = null;
        
        // 播放提示音
        this.playNotificationSound();
        
        // 显示通知
        this.showNotification();
        
        // 更新番茄钟记录为已完成
        this.updatePomodoroRecord(true);
        this.currentRecordId = '';
        
        // 处理下一步
        if (this.data.isBreak) {
            // 如果当前是休息时间结束
            if (this.data.autoStartWork) {
                // 自动开始下一个周期
                this.startNextCycle();
            } else {
                // 停止计时，等待手动开始
                this.setData({
                    isRunning: false,
                    showResetButton: true
                });
            }
        } else {
            // 如果当前是工作时间结束
            if (this.data.autoStartBreak) {
                // 自动开始休息
                this.startBreak();
            } else {
                // 停止计时，等待手动开始
                this.setData({
                    isRunning: false,
                    showResetButton: true
                });
            }
        }
        
        // 刷新今日统计
        this.fetchTodayStats();
        
        // 确保强制刷新所有统计数据
        try {
            const pages = getCurrentPages();
            const todayPage = pages.find(p => p.route === 'pages/today/today');
            if (todayPage) {
                console.log('番茄钟完成，通知今日页面更新数据');
                
                // 使用延迟确保数据已保存
                setTimeout(() => {
                    // 关键：首先调用强制更新成就的方法
                    todayPage.forceUpdateAchievements();
                    
                    // 然后更新其他数据
                    todayPage.fetchTodayFocus();
                    todayPage.checkTodayGoalStatus();
                }, 200);  // 稍微延长延迟时间
            }
        } catch (e) {
            console.error('通知今日页面更新失败:', e);
        }
    },
    
    // 开始休息
    startBreak() {
        const { breakDuration } = this.data;
        const timeRemaining = breakDuration * 60;
        
        this.setData({
            isBreak: true,
            timeRemaining,
            displayTime: this.formatTime(timeRemaining),
            progressDegree: 0,
            isRunning: false,
            showResetButton: true
        });
        
        // 如果设置了自动开始休息，立即开始计时
        if (this.data.autoStartBreak) {
            this.startTimer();
        }
    },
    
    // 开始下一个番茄钟周期
    startNextCycle() {
        const { currentCycle, totalCycles, workDuration } = this.data;
        let nextCycle = currentCycle;
        
        // 如果当前不是休息状态，不应该直接进入下一个周期
        if (!this.data.isBreak) {
            console.error('Attempted to start next cycle while not in break mode');
            return;
        }
        
        // 更新周期计数
        if (currentCycle < totalCycles) {
            nextCycle = currentCycle + 1;
        } else {
            // 完成所有周期，重置为第一个周期
            nextCycle = 1;
            
            // 可以在这里添加完成所有周期的奖励或通知
            wx.showToast({
                title: '恭喜完成所有番茄钟周期！',
                icon: 'success',
                duration: 2000
            });
        }
        
        // 设置为工作状态
        const timeRemaining = workDuration * 60;
        this.setData({
            isBreak: false,
            currentCycle: nextCycle,
            timeRemaining,
            displayTime: this.formatTime(timeRemaining),
            progressDegree: 0,
            isRunning: false,
            showResetButton: true
        });
        
        // 如果设置了自动开始下一个番茄钟，立即开始计时
        if (this.data.autoStartWork) {
            this.startTimer();
        }
    },
    
    // 播放提示音
    playNotificationSound() {
        try {
            const innerAudioContext = wx.createInnerAudioContext();
            // 检查声音文件是否存在
            wx.getFileSystemManager().access({
                path: '/assets/sounds/notification.mp3',
                success: () => {
                    innerAudioContext.src = '/assets/sounds/notification.mp3';
                    innerAudioContext.play();
                },
                fail: () => {
                    console.log('通知声音文件不存在，使用系统通知');
                    // 使用系统通知作为备选
                    wx.vibrateLong({
                        success: () => {
                            console.log('震动提醒成功');
                        }
                    });
                }
            });
        } catch (e) {
            console.error('播放通知声音失败:', e);
        }
    },
    
    // 显示通知
    showNotification() {
        const message = this.data.isBreak ? 
                        '休息时间结束，准备开始新的番茄钟！' : 
                        '工作时间结束，休息一下吧！';
        
        wx.showModal({
            title: '番茄钟提醒',
            content: message,
            showCancel: false,
            success: (res) => {
                // 点击确定后的操作
            }
        });
    },
    
    // 获取今日统计数据
    fetchTodayStats() {
        console.log('获取今日统计');
        try {
            const today = new Date();
            const dateStr = this.formatDate(today);
            
            // 从本地获取统计数据
            let pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
            let todayRecord = pomodoroRecord[dateStr] || { count: 0, minutes: 0, tasks: [] };
            
            this.setData({
                'todayStats.completedPomodoros': todayRecord.count,
                'todayStats.focusMinutes': todayRecord.minutes
            });
            
            console.log('今日统计:', todayRecord);
        } catch (e) {
            console.error('获取今日统计失败:', e);
        }
    },
    
    // 格式化日期为 YYYY-MM-DD
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}-${month}-${day}`;
    },
    
    // 获取绑定的任务
    fetchBindTask() {
        console.log('获取绑定任务');
        try {
            const bindTask = wx.getStorageSync('bindPomodoroTask');
            if (bindTask) {
                this.setData({
                    bindTaskId: bindTask.id,
                    bindTask: bindTask
                });
                console.log('绑定任务:', bindTask);
            }
        } catch (e) {
            console.error('获取绑定任务失败:', e);
        }
    },
    
    // 选择任务
    selectTask() {
        wx.navigateTo({
            url: '/pages/tasks/select-task/select-task?mode=bind'
        });
    },
    
    // 查看任务详情
    viewTaskDetail() {
        if (this.data.bindTaskId) {
            wx.navigateTo({
                url: `/pages/tasks/task-detail/task-detail?id=${this.data.bindTaskId}`
            });
        }
    },
    
    // 创建番茄钟记录
    createPomodoroRecord(task, focusMinutes) {
        // 总是先在本地保存记录
        try {
            const today = new Date();
            const dateStr = this.formatDate(today);
            
            let pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
            if (!pomodoroRecord[dateStr]) {
                pomodoroRecord[dateStr] = {
                    count: 0,
                    minutes: 0,
                    tasks: []
                };
            }
            
            // 更新记录
            pomodoroRecord[dateStr].count += 1;
            pomodoroRecord[dateStr].minutes += focusMinutes || this.data.focusDuration / 60;
            
            // 如果有关联任务，记录任务信息
            if (task) {
                pomodoroRecord[dateStr].tasks.push({
                    taskId: task.id,
                    taskTitle: task.title,
                    focusMinutes: focusMinutes || this.data.focusDuration / 60,
                    completedAt: new Date().toISOString()
                });
            }
            
            // 保存本地记录
            wx.setStorageSync('pomodoroRecord', pomodoroRecord);
            console.log('番茄钟记录已保存到本地');
            
            // 限制同步频率：只在番茄钟完成时同步到云端
            if (this.data.isCompleted) {
                this.syncToCloud(dateStr, pomodoroRecord[dateStr]).catch(err => {
                    console.error('创建番茄钟记录失败', err);
                    // 设置一个标志，表示有未同步的数据
                    wx.setStorageSync('hasPendingSyncData', true);
                });
            }
            
            // 新增代码：通知今日页面更新统计数据
            // 如果今日页面在栈中，刷新其数据
            const pages = getCurrentPages();
            const todayPage = pages.find(p => p.route === 'pages/today/today');
            if (todayPage) {
                todayPage.fetchTodayFocus();
            }
            
            return Promise.resolve(pomodoroRecord[dateStr]);
        } catch (e) {
            console.error('保存番茄钟记录失败:', e);
            return Promise.reject(e);
        }
    },
    
    // 分离云同步逻辑
    syncToCloud(dateStr, record) {
        return new Promise((resolve, reject) => {
            try {
                // 检查网络状态
                wx.getNetworkType({
                    success: (res) => {
                        if (res.networkType !== 'none') {
                            // 有网络，尝试同步
                            if (typeof callCloudFunction === 'function') {
                                // 云函数可用时调用
                                callCloudFunction('pomodoro', {
                                    action: 'saveRecord',
                                    date: dateStr,
                                    record: record,
                                    userId: getApp().globalData.userId || wx.getStorageSync('userId')
                                }).then(resolve).catch(err => {
                                    console.error('云端同步失败:', err);
                                    resolve({
                                        success: true,
                                        localOnly: true,
                                        message: '数据已保存在本地，但云端同步失败'
                                    });
                                });
                            } else {
                                // 云函数不可用时，只使用本地存储
                                console.log('云函数不可用，仅使用本地存储');
                                resolve({
                                    success: true,
                                    localOnly: true,
                                    message: '数据已保存在本地'
                                });
                            }
                        } else {
                            // 无网络，标记为待同步
                            console.log('无网络连接，稍后同步');
                            resolve({
                                success: true,
                                localOnly: true,
                                message: '无网络连接，数据已保存在本地'
                            });
                        }
                    },
                    fail: (err) => {
                        console.error('获取网络状态失败:', err);
                        resolve({
                            success: true,
                            localOnly: true,
                            message: '获取网络状态失败，数据已保存在本地'
                        });
                    }
                });
            } catch (err) {
                console.error('同步过程发生错误:', err);
                resolve({
                    success: true,
                    localOnly: true,
                    message: '同步过程发生错误，数据已保存在本地'
                });
            }
        });
    },
    
    // 更新番茄钟记录
    updatePomodoroRecord(completed = false) {
        if (!this.currentRecordId) return;
        
        const app = getApp();
        const userId = app && app.globalData ? app.globalData.userId : '';
        
        if (!userId) {
            console.log('未获取到用户ID，无法更新记录');
            return;
        }
        
        // 计算实际专注时间（秒）
        let actualDuration = 0;
        if (startTimestamp > 0) {
            const totalDuration = this.data.isBreak ? this.data.breakDuration * 60 : this.data.workDuration * 60;
            const elapsed = Math.floor((Date.now() - startTimestamp) / 1000);
            actualDuration = Math.min(elapsed, totalDuration);
        }
        
        wx.cloud.callFunction({
            name: 'pomodoroTimer',
            data: {
                action: 'updateRecord',
                recordId: this.currentRecordId,
                userId: userId,
                endTime: new Date().toISOString(),
                completed: completed,
                actualDuration: actualDuration
            }
        }).catch(err => {
            console.error('更新番茄钟记录失败', err);
        });
    },
    
    // 导航到统计页面
    navigateToStats() {
        wx.switchTab({
            url: '/pages/statistics/statistics'
        });
    },
    
    // 增加工作时长
    increaseWorkTime() {
        if (this.data.isRunning) return;
        
        let { workDuration } = this.data;
        if (workDuration < 60) {
            workDuration += 5;
            this.setData({ workDuration });
            
            if (!this.data.isBreak) {
                this.initTimer();
            }
            
            this.saveSettings();
        }
    },
    
    // 减少工作时长
    decreaseWorkTime() {
        if (this.data.isRunning) return;
        
        let { workDuration } = this.data;
        if (workDuration > 5) {
            workDuration -= 5;
            this.setData({ workDuration });
            
            if (!this.data.isBreak) {
                this.initTimer();
            }
            
            this.saveSettings();
        }
    },
    
    // 增加休息时长
    increaseBreakTime() {
        if (this.data.isRunning) return;
        
        let { breakDuration } = this.data;
        if (breakDuration < 30) {
            breakDuration += 1;
            this.setData({ breakDuration });
            
            if (this.data.isBreak) {
                this.initTimer();
            }
            
            this.saveSettings();
        }
    },
    
    // 减少休息时长
    decreaseBreakTime() {
        if (this.data.isRunning) return;
        
        let { breakDuration } = this.data;
        if (breakDuration > 1) {
            breakDuration -= 1;
            this.setData({ breakDuration });
            
            if (this.data.isBreak) {
                this.initTimer();
            }
            
            this.saveSettings();
        }
    },
    
    // 增加循环次数
    increaseCycles() {
        if (this.data.isRunning) return;
        
        let { totalCycles } = this.data;
        if (totalCycles < 10) {
            totalCycles += 1;
            this.setData({ totalCycles });
            this.saveSettings();
        }
    },
    
    // 减少循环次数
    decreaseCycles() {
        if (this.data.isRunning) return;
        
        let { totalCycles } = this.data;
        if (totalCycles > 1) {
            totalCycles -= 1;
            this.setData({ totalCycles });
            this.saveSettings();
        }
    },
    
    // 切换自动开始休息
    toggleAutoStartBreak(e) {
        this.setData({
            autoStartBreak: e.detail.value
        });
        this.saveSettings();
    },
    
    // 切换自动开始工作
    toggleAutoStartWork(e) {
        this.setData({
            autoStartWork: e.detail.value
        });
        this.saveSettings();
    },
    
    // 保存设置
    saveSettings() {
        console.log('保存设置', this.data.tempSettings);
        
        try {
            // 应用设置到当前数据
            this.setData({
                focusDuration: this.data.tempSettings.focusDuration,
                breakDuration: this.data.tempSettings.breakDuration,
                totalCycles: this.data.tempSettings.totalCycles,
                autoStartNextPhase: this.data.tempSettings.autoStartNextPhase,
                showSettingsModal: false
            });
            
            // 保存到本地存储，不调用云函数
            wx.setStorageSync('pomodoroSettings', {
                focusDuration: this.data.tempSettings.focusDuration,
                breakDuration: this.data.tempSettings.breakDuration,
                totalCycles: this.data.tempSettings.totalCycles,
                autoStartNextPhase: this.data.tempSettings.autoStartNextPhase,
                timerType: this.data.timerType
            });
            
            // 重置计时器并更新显示
            this.resetTimer();
            
            // 提示
            wx.showToast({
                title: '设置已保存',
                icon: 'success',
                duration: 1500
            });
        } catch (e) {
            console.error('保存设置失败:', e);
            wx.showToast({
                title: '保存设置失败',
                icon: 'none',
                duration: 1500
            });
        }
    },
    
    // 获取优先级颜色
    getPriorityColor(priority) {
        const colors = {
            1: '#63E6BE', // 低
            2: '#FFD43B', // 中
            3: '#FF6B6B'  // 高
        };
        return colors[priority] || colors[2];
    },

    // 加载用户设置
    loadUserSettings() {
        console.log('加载用户设置');
        try {
            const userSettings = wx.getStorageSync('userSettings') || {};
            
            // 设置主题颜色
            if (userSettings.themeColors) {
                this.setData({
                    workColor: userSettings.themeColors.workColor || '#FF6B6B',
                    breakColor: userSettings.themeColors.breakColor || '#4DABF7',
                    workBgColor: userSettings.themeColors.workBgColor || '#FFF3F3',
                    breakBgColor: userSettings.themeColors.breakBgColor || '#EBF8FF'
                });
            }
            
            console.log('加载用户设置成功');
        } catch (e) {
            console.error('加载用户设置失败:', e);
        }
    },

    // 保存用户设置
    saveUserSettings() {
        try {
            const settings = {
                pomodoroSettings: {
                    focusDuration: this.data.focusDuration,
                    breakDuration: this.data.breakDuration,
                    totalCycles: this.data.totalCycles,
                    autoStartNextPhase: this.data.autoStartNextPhase,
                    timerType: this.data.timerType
                }
            };
            
            // 只保存到本地，不同步到云端
            wx.setStorageSync('userSettings', settings);
            console.log('用户设置已保存到本地');
        } catch (e) {
            console.error('保存用户设置失败:', e);
        }
    },

    // 切换计时器类型（倒计时/正计时）
    switchTimerType(e) {
        const type = e.currentTarget.dataset.type;
        
        // 如果已经是当前类型，不做操作
        if (type === this.data.timerType) {
            return;
        }
        
        console.log('切换计时器类型:', type);
        
        // 如果正在计时，先停止
        if (this.data.isRunning) {
            this.pauseTimer();
        }
        
        // 完全重置计时器状态
        startTimestamp = 0;
        lastTickTimestamp = 0;
        pausedAt = 0;
        
        // 根据类型设置初始显示时间
        const { currentMode, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        const initialDisplay = type === 'countdown' ? this.formatTime(totalSeconds) : '00:00';
        
        // 更新界面
        this.setData({
            timerType: type,
            elapsedTime: 0,
            displayTime: initialDisplay,
            showResetButton: false
        });
    },

    // 显示设置弹窗
    showSettings() {
        console.log('显示设置面板');
        // 复制当前设置到临时设置中
        this.setData({
            'tempSettings.focusDuration': this.data.focusDuration,
            'tempSettings.breakDuration': this.data.breakDuration,
            'tempSettings.totalCycles': this.data.totalCycles,
            'tempSettings.autoStartNextPhase': this.data.autoStartNextPhase,
            showSettingsModal: true
        });
    },

    // 隐藏设置面板
    hideSettings() {
        this.setData({
            showSettingsModal: false
        });
    },

    // 添加数字输入处理方法
    changeFocusDuration(e) {
        // 获取输入的分钟数
        const minutes = parseInt(e.detail.value);
        if (isNaN(minutes) || minutes < 1) {
            wx.showToast({
                title: '请输入有效的分钟数',
                icon: 'none'
            });
            return;
        }
        
        console.log(`修改专注时长: ${minutes}分钟`);
        this.setData({
            'tempSettings.focusDuration': minutes * 60
        });
    },

    // 修改休息时长
    changeBreakDuration(e) {
        const minutes = parseInt(e.detail.value);
        if (isNaN(minutes) || minutes < 1) {
            wx.showToast({
                title: '请输入有效的分钟数',
                icon: 'none'
            });
            return;
        }
        
        console.log(`修改休息时长: ${minutes}分钟`);
        this.setData({
            'tempSettings.breakDuration': minutes * 60
        });
    },

    // 修改循环次数
    changeTotalCycles(e) {
        const cycles = parseInt(e.detail.value);
        if (isNaN(cycles) || cycles < 1) {
            wx.showToast({
                title: '请输入有效的循环次数',
                icon: 'none'
            });
            return;
        }
        
        console.log(`修改循环次数: ${cycles}`);
        this.setData({
            'tempSettings.totalCycles': cycles
        });
    },

    // 切换是否自动开始下一阶段
    toggleAutoStartNextPhase(e) {
        const value = e.detail.value;
        console.log(`自动开始下一阶段: ${value}`);
        this.setData({
            'tempSettings.autoStartNextPhase': value
        });
    },

    // 重置为默认设置
    resetToDefaults() {
        console.log('恢复默认设置');
        this.setData({
            'tempSettings.focusDuration': 25 * 60, // 25分钟
            'tempSettings.breakDuration': 5 * 60,  // 5分钟
            'tempSettings.totalCycles': 4,
            'tempSettings.autoStartNextPhase': true
        });
        
        wx.showToast({
            title: '已恢复默认设置',
            icon: 'success',
            duration: 1500
        });
    },

    // 处理设置滑块变化
    handleSliderChange(e) {
        const { field } = e.currentTarget.dataset;
        const value = e.detail.value;
        
        console.log(`设置变更: ${field} = ${value}`);
        
        // 更新临时设置
        if (field === 'focusDuration') {
            // 转换为秒
            this.setData({
                'tempSettings.focusDuration': value * 60
            });
        } else if (field === 'breakDuration') {
            this.setData({
                'tempSettings.breakDuration': value * 60
            });
        } else if (field === 'totalCycles') {
            this.setData({
                'tempSettings.totalCycles': value
            });
        }
    },

    // 处理自动开始下一阶段开关变化
    handleSwitchChange(e) {
        const value = e.detail.value;
        console.log(`自动开始设置变更: ${value}`);
        
        this.setData({
            'tempSettings.autoStartNextPhase': value
        });
    },

    // 切换计时器类型（倒计时/正计时）
    toggleTimerType() {
        const newType = this.data.timerType === 'countdown' ? 'countup' : 'countdown';
        console.log(`切换计时器类型: ${newType}`);
        
        // 如果计时器正在运行，先停止
        if (this.data.isRunning) {
            this.pauseTimer();
        }
        
        this.setData({
            timerType: newType,
            elapsedTime: 0
        }, () => {
            // 更新显示时间
            this.updateDisplayTime();
            
            // 保存设置
            const settings = wx.getStorageSync('pomodoroSettings') || {};
            settings.timerType = newType;
            wx.setStorageSync('pomodoroSettings', settings);
            
            wx.showToast({
                title: newType === 'countdown' ? '已切换为倒计时' : '已切换为正计时',
                icon: 'none',
                duration: 1500
            });
        });
    },

    // 更新显示时间
    updateDisplayTime() {
        const { currentMode, timerType, elapsedTime, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        
        let displayTime;
        let progressPercentage = 0;
        
        if (timerType === 'countdown') {
            // 倒计时模式：显示剩余时间（确保非负）
            const remainingSeconds = Math.max(0, totalSeconds - elapsedTime);
            displayTime = this.formatTime(remainingSeconds);
            progressPercentage = Math.min(100, Math.max(0, (elapsedTime / totalSeconds) * 100));
        } else {
            // 正计时模式：显示已用时间
            displayTime = this.formatTime(elapsedTime);
            progressPercentage = Math.min(100, Math.max(0, (elapsedTime / totalSeconds) * 100));
        }
        
        // 计算进度条角度 (基于百分比)
        const progressDegree = Math.min(360, Math.max(0, 3.6 * progressPercentage));
        
        console.log(`更新显示时间: ${displayTime}, 进度: ${progressPercentage.toFixed(1)}%, 角度: ${progressDegree.toFixed(1)}`);
        
        this.setData({ 
            displayTime, 
            progressDegree 
        });
    },

    // 检查当前阶段是否完成
    checkPhaseCompletion() {
        // 如果刚刚完成了阶段，跳过检查
        if (phaseJustCompleted) {
            console.log('刚完成阶段，跳过完成检查');
            return;
        }
        
        const { currentMode, timerType, elapsedTime, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        
        console.log(`检查阶段完成: ${currentMode}, 已用时间: ${elapsedTime}秒, 总时间: ${totalSeconds}秒, 类型: ${timerType}`);
        
        if (timerType === 'countdown' && elapsedTime >= totalSeconds) {
            console.log('倒计时模式下阶段完成');
            this.completeCurrentPhase();
        }
    },

    // 完成当前阶段
    completeCurrentPhase() {
        console.log('完成当前阶段', this.data.currentMode);
        
        // 标记刚完成阶段，防止重复触发
        phaseJustCompleted = true;
        
        // 停止计时器
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        
        // 完全重置所有计时相关变量
        startTimestamp = 0;
        lastTickTimestamp = 0;
        pausedAt = 0;
        totalPausedTime = 0;
        pausedElapsedTime = 0;
        
        // 播放提示音
        this.playNotificationSound();
        
        const { currentMode, autoStartNextPhase, completedCycles, totalCycles } = this.data;
        
        // 处理不同阶段的完成情况
        if (currentMode === 'focus') {
            // 完成专注阶段，切换到休息阶段
            this.setData({
                currentMode: 'break',
                elapsedTime: 0
            }, () => {
                // 确保先更新时间显示，再设置运行状态
                this.updateDisplayTime();
                
                this.setData({
                    isRunning: autoStartNextPhase
                });
                
                wx.showToast({
                    title: '专注完成，开始休息',
                    icon: 'success',
                    duration: 2000
                });
                
                // 延迟启动下一阶段，确保状态更新完成
                if (autoStartNextPhase) {
                    setTimeout(() => {
                        phaseJustCompleted = false;
                        this.startTimer();
                    }, 500);
                } else {
                    setTimeout(() => {
                        phaseJustCompleted = false;
                    }, 500);
                }
            });
            
            // 如果是专注阶段完成，记录数据
            const elapsedMinutes = Math.floor(this.data.elapsedTime / 60);
            const taskId = this.data.currentTask ? this.data.currentTask.id : '';
            const taskName = this.data.currentTask ? this.data.currentTask.title : '专注';
            
            // 记录专注数据
            this.recordFocusComplete({
                taskId: taskId,
                taskName: taskName,
                minutes: elapsedMinutes,
                timestamp: new Date().getTime()
            });
            
            // 通知统计页面更新数据
            const app = getApp();
            app.globalData.statisticsNeedRefresh = true;
            
            console.log(`专注记录已保存: ${elapsedMinutes}分钟, 任务: ${taskName}`);
        } else {
            // 完成休息阶段
            const newCompletedCycles = completedCycles + 1;
            const isAllCyclesCompleted = newCompletedCycles >= totalCycles;
            
            if (isAllCyclesCompleted) {
                // 所有循环完成
                this.setData({
                    completedCycles: newCompletedCycles,
                    isRunning: false,
                    elapsedTime: 0
                }, () => {
                    this.updateDisplayTime();
                    
                    wx.showToast({
                        title: '所有番茄钟循环已完成！',
                        icon: 'success',
                        duration: 2000
                    });
                    
                    // 记录完成的番茄钟
                    this.recordCompletedPomodoro();
                    
                    setTimeout(() => {
                        phaseJustCompleted = false;
                    }, 500);
                });
            } else {
                // 进入下一个循环的专注阶段
                this.setData({
                    currentMode: 'focus',
                    elapsedTime: 0,
                    completedCycles: newCompletedCycles,
                    currentCycleIndex: newCompletedCycles
                }, () => {
                    this.updateDisplayTime();
                    
                    this.setData({
                        isRunning: autoStartNextPhase
                    });
                    
                    wx.showToast({
                        title: `休息完成，开始第${newCompletedCycles + 1}个专注`,
                        icon: 'success',
                        duration: 2000
                    });
                    
                    if (autoStartNextPhase) {
                        setTimeout(() => {
                            phaseJustCompleted = false;
                            this.startTimer();
                        }, 500);
                    } else {
                        setTimeout(() => {
                            phaseJustCompleted = false;
                        }, 500);
                    }
                });
            }
        }
    },

    // 播放提示音
    playNotificationSound() {
        try {
            const innerAudioContext = wx.createInnerAudioContext();
            // 检查声音文件是否存在
            wx.getFileSystemManager().access({
                path: '/assets/sounds/notification.mp3',
                success: () => {
                    innerAudioContext.src = '/assets/sounds/notification.mp3';
                    innerAudioContext.play();
                },
                fail: () => {
                    console.log('通知声音文件不存在，使用系统通知');
                    // 使用系统通知作为备选
                    wx.vibrateLong({
                        success: () => {
                            console.log('震动提醒成功');
                        }
                    });
                }
            });
        } catch (e) {
            console.error('播放通知声音失败:', e);
        }
    },

    // 记录完成的番茄钟（用于统计）
    recordCompletedPomodoro() {
        const { focusDuration, totalCycles, currentTask } = this.data;
        const totalFocusMinutes = Math.round((focusDuration * totalCycles) / 60);
        
        try {
            // 获取今日完成的番茄钟记录
            const today = new Date();
            const dateStr = this.formatDate(today);
            
            let pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
            if (!pomodoroRecord[dateStr]) {
                pomodoroRecord[dateStr] = {
                    count: 0,
                    minutes: 0,
                    tasks: []
                };
            }
            
            // 更新记录
            pomodoroRecord[dateStr].count += 1;
            pomodoroRecord[dateStr].minutes += totalFocusMinutes;
            
            // 如果有关联任务，记录任务信息
            if (currentTask) {
                pomodoroRecord[dateStr].tasks.push({
                    taskId: currentTask.id,
                    taskTitle: currentTask.title,
                    focusMinutes: totalFocusMinutes,
                    completedAt: new Date().toISOString()
                });
            }
            
            // 保存本地记录
            wx.setStorageSync('pomodoroRecord', pomodoroRecord);
            
            // 新增代码：通知今日页面更新所有统计数据
            const pages = getCurrentPages();
            const todayPage = pages.find(p => p.route === 'pages/today/today');
            if (todayPage) {
                console.log('番茄钟完成，通知今日页面更新数据');
                
                // 使用延迟确保数据已保存
                setTimeout(() => {
                    // 关键：首先调用强制更新成就的方法
                    todayPage.forceUpdateAchievements();
                    
                    // 然后更新其他数据
                    todayPage.fetchTodayFocus();
                    todayPage.checkTodayGoalStatus();
                }, 200);  // 稍微延长延迟时间
            }
            
        } catch (e) {
            console.error('记录番茄钟失败:', e);
        }
    },

    // 添加跳过阶段的方法
    skipPhase() {
        // 确认是否跳过
        wx.showModal({
            title: '确认跳过',
            content: `确定要跳过当前${this.data.currentMode === 'focus' ? '专注' : '休息'}阶段吗？`,
            success: (res) => {
                if (res.confirm) {
                    // 如果正在计时，先暂停
                    if (this.data.isRunning) {
                        this.pauseTimer();
                    }
                    
                    // 完成当前阶段
                    this.completeCurrentPhase();
                }
            }
        });
    },

    // 添加缺失的initTimer方法
    initTimer() {
        console.log('初始化计时器');
        
        // 重置所有计时器相关变量
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        
        startTimestamp = 0;
        lastTickTimestamp = 0;
        pausedAt = 0;
        
        // 根据当前模式和类型设置初始显示时间
        const { currentMode, timerType, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        
        this.setData({
            isRunning: false,
            elapsedTime: 0,
            displayTime: timerType === 'countdown' ? this.formatTime(totalSeconds) : '00:00',
            progressDegree: 0,
            showResetButton: false
        });
    },

    // 添加formatTime方法
    formatTime(seconds) {
        seconds = Math.floor(seconds);
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
    },

    // 使用更简单的时间更新方法避免负值
    updateTimerSimple() {
        const now = Date.now();
        const elapsedMs = now - startTimestamp;
        const newElapsedSeconds = Math.max(0, Math.floor(elapsedMs / 1000));
        
        // 只在时间确实变化时更新
        if (newElapsedSeconds !== this.data.elapsedTime) {
            console.log(`更新时间: ${newElapsedSeconds}秒`);
            
            this.setData({
                elapsedTime: newElapsedSeconds
            });
            
            this.updateDisplayTime();
            this.checkPhaseCompletion();
        }
    },

    // 检查阶段是否完成
    checkPhaseCompletion() {
        // 如果刚刚完成了阶段，跳过检查
        if (phaseJustCompleted) {
            console.log('刚完成阶段，跳过完成检查');
            return;
        }
        
        const { currentMode, timerType, elapsedTime, focusDuration, breakDuration } = this.data;
        const totalSeconds = currentMode === 'focus' ? focusDuration : breakDuration;
        
        console.log(`检查阶段完成: ${currentMode}, 已用时间: ${elapsedTime}秒, 总时间: ${totalSeconds}秒, 类型: ${timerType}`);
        
        // 仅在倒计时模式检查是否完成
        if (timerType === 'countdown' && elapsedTime >= totalSeconds) {
            console.log('倒计时模式下阶段完成');
            this.completeCurrentPhase();
        }
    },

    // 添加缺失的loadSettings方法
    loadSettings() {
        console.log('加载设置');
        try {
            const settings = wx.getStorageSync('pomodoroSettings');
            if (settings) {
                // 确保数值类型正确
                const focusDuration = parseInt(settings.focusDuration || 25 * 60);
                const breakDuration = parseInt(settings.breakDuration || 5 * 60);
                const totalCycles = parseInt(settings.totalCycles || 4);
                
                this.setData({
                    focusDuration: focusDuration,
                    breakDuration: breakDuration,
                    totalCycles: totalCycles,
                    autoStartNextPhase: settings.autoStartNextPhase !== false,
                    timerType: settings.timerType || 'countdown'
                });
                
                console.log('加载设置成功', this.data.focusDuration, this.data.breakDuration);
            }
        } catch (e) {
            console.error('加载设置失败:', e);
        }
    },

    // 添加记录专注数据的方法
    saveFocusRecord(focusData) {
        try {
            // 尝试获取已有记录
            const records = wx.getStorageSync('pomodoroRecords') || {};
            
            // 格式化今天的日期作为key
            const today = new Date().toISOString().split('T')[0];
            
            // 确保今天的记录存在
            if (!records[today]) {
                records[today] = {
                    date: today,
                    minutes: 0,
                    count: 0,
                    records: []
                };
            }
            
            // 添加新记录
            records[today].records.push(focusData);
            records[today].minutes += focusData.minutes;
            records[today].count += 1;
            
            // 保存回本地
            wx.setStorageSync('pomodoroRecords', records);
            
            // 设置全局标记，通知统计页面需要刷新
            getApp().globalData.statisticsNeedRefresh = true;
            
            // 同时尝试上传到云端（如果可用）
            this.uploadFocusRecord(focusData);
        } catch (error) {
            console.error('保存专注记录失败:', error);
        }
    },

    // 添加上传专注记录到云端的方法
    uploadFocusRecord(focusData) {
        // 实现上传逻辑
        // 这里需要根据实际的云端同步逻辑来实现
        console.log('上传专注记录到云端:', focusData);
    },

    // 修改recordFocusComplete函数，确保数据正确保存
    recordFocusComplete: function() {
        console.log('记录专注完成...');
        
        try {
            // 获取当天日期字符串和任务信息
            const today = new Date().toISOString().split('T')[0];
            const totalFocusMinutes = Math.floor(this.data.focusDuration / 60);
            const taskId = this.data.currentTask ? this.data.currentTask.id : null;
            const taskName = this.data.currentTask ? this.data.currentTask.title : '未命名任务';
            
            console.log('准备保存专注记录:', today, totalFocusMinutes + '分钟', '任务:', taskName);
            
            // 获取并更新新格式记录
            let pomodoroRecords = wx.getStorageSync('pomodoroRecords') || {};
            
            // 确保当天记录初始化正确
            if (!pomodoroRecords[today]) {
                pomodoroRecords[today] = {
                    date: today,
                    count: 0,
                    minutes: 0,
                    records: [],
                    tasks: [] // 确保tasks数组存在
                };
            } else if (!pomodoroRecords[today].tasks) {
                // 确保已有记录中也有tasks数组
                pomodoroRecords[today].tasks = [];
            }
            
            // 累加记录
            pomodoroRecords[today].count += 1;
            pomodoroRecords[today].minutes += totalFocusMinutes;
            
            // 确保records数组存在
            if (!pomodoroRecords[today].records) {
                pomodoroRecords[today].records = [];
            }
            
            // 添加当前时间戳和任务信息，用于时间分布统计
            pomodoroRecords[today].records.push({
                timestamp: new Date().toISOString(),
                minutes: totalFocusMinutes,
                taskId: taskId,
                taskName: taskName
            });
            
            // 如果有关联任务，添加到任务列表中
            if (taskId) {
                // 添加任务记录
                pomodoroRecords[today].tasks.push({
                    taskId: taskId,
                    taskTitle: taskName,
                    minutes: totalFocusMinutes,
                    completedAt: new Date().toISOString()
                });
                
                console.log('已添加任务记录:', taskName);
            }
            
            // 安全访问tasks.length
            const tasksLength = pomodoroRecords[today].tasks ? pomodoroRecords[today].tasks.length : 0;
            
            // 保存到本地存储
            wx.setStorageSync('pomodoroRecords', pomodoroRecords);
            console.log('新格式数据已保存，包含', tasksLength, '个任务');
            
            // 同时保存到旧格式，确保兼容性
            let pomodoroRecord = wx.getStorageSync('pomodoroRecord') || {};
            if (!pomodoroRecord[today]) {
                pomodoroRecord[today] = { 
                    count: 0, 
                    minutes: 0,
                    tasks: [] 
                };
            } else if (!pomodoroRecord[today].tasks) {
                // 确保已有记录中也有tasks数组
                pomodoroRecord[today].tasks = [];
            }
            
            pomodoroRecord[today].count += 1;
            pomodoroRecord[today].minutes += totalFocusMinutes;
            
            // 同样添加任务记录到旧格式
            if (taskId) {
                pomodoroRecord[today].tasks.push({
                    taskId: taskId,
                    taskTitle: taskName,
                    minutes: totalFocusMinutes,
                    completedAt: new Date().toISOString()
                });
            }
            
            // 安全访问tasks.length
            const oldTasksLength = pomodoroRecord[today].tasks ? pomodoroRecord[today].tasks.length : 0;
            
            wx.setStorageSync('pomodoroRecord', pomodoroRecord);
            console.log('旧格式数据已保存，包含', oldTasksLength, '个任务');
            
            // 设置全局标志，表示需要刷新统计页面
            const app = getApp();
            app.globalData.statisticsNeedRefresh = true;
            console.log('已设置统计页面刷新标记');
            
            console.log('番茄钟完成，记录已保存:', today, totalFocusMinutes + '分钟', taskId ? ('任务: ' + taskName) : '无任务');
        } catch (e) {
            console.error('记录番茄钟失败:', e);
            // 尝试更简单的记录方式，确保至少基本数据被保存
            try {
                const today = new Date().toISOString().split('T')[0];
                const totalFocusMinutes = Math.floor(this.data.focusDuration / 60);
                
                // 使用最简单的数据结构
                let simpleRecord = wx.getStorageSync('simplePomodoro') || {};
                if (!simpleRecord[today]) {
                    simpleRecord[today] = { minutes: 0, count: 0 };
                }
                
                simpleRecord[today].minutes += totalFocusMinutes;
                simpleRecord[today].count += 1;
                
                wx.setStorageSync('simplePomodoro', simpleRecord);
                console.log('使用简化格式保存了基本记录');
                
                // 通知需要刷新
                const app = getApp();
                if (app && app.globalData) {
                    app.globalData.statisticsNeedRefresh = true;
                }
            } catch (fallbackError) {
                console.error('备用记录方式也失败:', fallbackError);
            }
        }
    },
})