const cloud = require('wx-server-sdk');
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const tasksCollection = db.collection('tasks');
const _ = db.command;

// 任务管理云函数
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext();
  const { action, taskId, task, query, status } = event;
  
  // 确保userId正确
  const userId = event.userId || OPENID;
  
  switch (action) {
    case 'getTasks':
      return await getTasks(userId, query);
    case 'getTaskById':
      return await getTaskById(taskId, userId);
    case 'createTask':
      return await createTask(task, userId);
    case 'updateTask':
      return await updateTask(taskId, task, userId);
    case 'updateTaskStatus':
      return await updateTaskStatus(taskId, status, userId);
    case 'deleteTask':
      return await deleteTask(taskId, userId);
    case 'getTaskSets':
      return await getTaskSets(userId);
    default:
      return {
        success: false,
        error: '未知的操作类型'
      };
  }
};

// 获取任务列表
async function getTasks(userId, query = {}) {
  try {
    // 合并查询条件，确保只查询当前用户的任务
    const finalQuery = {
      ...query,
      userId: userId
    };
    
    const result = await tasksCollection.where(finalQuery).get();
    
    return {
      success: true,
      data: result.data
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 获取单个任务
async function getTaskById(taskId, userId) {
  try {
    const result = await tasksCollection.doc(taskId).get();
    
    // 验证任务所有权
    if (result.data.userId !== userId) {
      return {
        success: false,
        error: '无权限访问此任务'
      };
    }
    
    return {
      success: true,
      data: result.data
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 创建任务
async function createTask(task, userId) {
  try {
    const now = new Date();
    
    const newTask = {
      ...task,
      userId: userId,
      status: 'pending',
      createdAt: now,
      updatedAt: now
    };
    
    const result = await tasksCollection.add({
      data: newTask
    });
    
    return {
      success: true,
      taskId: result._id
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 更新任务
async function updateTask(taskId, task, userId) {
  try {
    // 首先验证任务所有权
    const taskCheck = await tasksCollection.doc(taskId).get();
    
    if (taskCheck.data.userId !== userId) {
      return {
        success: false,
        error: '无权限修改此任务'
      };
    }
    
    const updateData = {
      ...task,
      updatedAt: new Date()
    };
    
    // 移除不允许修改的字段
    delete updateData._id;
    delete updateData.userId;
    delete updateData.createdAt;
    
    await tasksCollection.doc(taskId).update({
      data: updateData
    });
    
    return {
      success: true
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 更新任务状态
async function updateTaskStatus(taskId, status, userId) {
  try {
    // 首先验证任务所有权
    const taskCheck = await tasksCollection.doc(taskId).get();
    
    if (taskCheck.data.userId !== userId) {
      return {
        success: false,
        error: '无权限修改此任务'
      };
    }
    
    await tasksCollection.doc(taskId).update({
      data: {
        status: status,
        updatedAt: new Date()
      }
    });
    
    return {
      success: true
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 删除任务（软删除）
async function deleteTask(taskId, userId) {
  try {
    // 首先验证任务所有权
    const taskCheck = await tasksCollection.doc(taskId).get();
    
    if (taskCheck.data.userId !== userId) {
      return {
        success: false,
        error: '无权限删除此任务'
      };
    }
    
    await tasksCollection.doc(taskId).update({
      data: {
        status: 'deleted',
        updatedAt: new Date()
      }
    });
    
    return {
      success: true
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 获取任务集列表
async function getTaskSets(userId) {
  try {
    const result = await db.collection('task_sets').where({
      userId: userId
    }).get();
    
    return {
      success: true,
      data: result.data
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
} 