// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境
const db = cloud.database()
const settingsCollection = db.collection('userSettings')

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const { action, userId, settings } = event
  
  try {
    switch (action) {
      case 'getSettings':
        return await getSettings(userId || wxContext.OPENID)
      case 'updateSettings':
        return await updateSettings(userId || wxContext.OPENID, settings)
      case 'initSettings':
        return await initSettings(userId || wxContext.OPENID, settings)
      default:
        return {
          success: false,
          errMsg: '未知的操作类型'
        }
    }
  } catch (err) {
    console.error(err)
    return {
      success: false,
      errMsg: err.message
    }
  }
}

// 获取用户设置
async function getSettings(userId) {
  const settingsData = await settingsCollection.where({
    userId: userId
  }).get()
  
  if (settingsData.data.length > 0) {
    return {
      success: true,
      settings: settingsData.data[0].settings
    }
  }
  
  return {
    success: false,
    errMsg: '未找到用户设置'
  }
}

// 更新用户设置
async function updateSettings(userId, newSettings) {
  const settingsData = await settingsCollection.where({
    userId: userId
  }).get()
  
  if (settingsData.data.length > 0) {
    // 更新现有设置
    await settingsCollection.doc(settingsData.data[0]._id).update({
      data: {
        settings: newSettings,
        updatedAt: db.serverDate()
      }
    })
  } else {
    // 创建新设置
    await settingsCollection.add({
      data: {
        userId: userId,
        settings: newSettings,
        createdAt: db.serverDate(),
        updatedAt: db.serverDate()
      }
    })
  }
  
  return {
    success: true
  }
}

// 初始化默认设置
async function initSettings(userId, defaultSettings) {
  // 检查是否已存在设置
  const settingsData = await settingsCollection.where({
    userId: userId
  }).get()
  
  if (settingsData.data.length > 0) {
    // 已存在设置，不做操作
    return {
      success: true,
      message: '用户设置已存在'
    }
  }
  
  // 创建默认设置
  await settingsCollection.add({
    data: {
      userId: userId,
      settings: defaultSettings,
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })
  
  return {
    success: true,
    message: '默认设置已初始化'
  }
} 