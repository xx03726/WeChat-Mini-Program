// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境
const db = cloud.database()
const userCollection = db.collection('users')

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  
  try {
    switch (event.action) {
      case 'createAnonymousUser':
        return await createAnonymousUser(wxContext)
      case 'getUserInfo':
        return await getUserInfo(openid)
      case 'updateUserInfo':
        return await updateUserInfo(openid, event.userInfo)
      case 'getGoals':
        return getGoals(openid)
      case 'saveGoals':
        return saveGoals(openid, event.goals)
      case 'getTodayProgress':
        return getTodayProgress(openid)
      case 'recordFocus':
        return recordFocus(openid, event.focusData)
      case 'getProgressStats':
        return getProgressStats(openid)
      case 'checkin':
        return checkin(openid, event.date)
      default:
        return {
          success: false,
          errMsg: '未知的操作类型'
        }
    }
  } catch (err) {
    console.error(err)
    return {
      success: false,
      errMsg: err.message
    }
  }
}

// 创建匿名用户
async function createAnonymousUser(wxContext) {
  const openId = wxContext.OPENID
  
  // 检查用户是否已存在
  const existUser = await userCollection.where({
    openId: openId
  }).get()
  
  if (existUser.data.length > 0) {
    // 用户已存在，直接返回
    return {
      success: true,
      userId: existUser.data[0]._id
    }
  }
  
  // 创建新用户
  const result = await userCollection.add({
    data: {
      openId: openId,
      nickName: '用户' + openId.substring(openId.length - 4),
      avatarUrl: '',
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })
  
  return {
    success: true,
    userId: result._id
  }
}

// 获取用户信息
async function getUserInfo(userId) {
  // 先尝试用ID查询
  let userQuery = userCollection.doc(userId)
  
  try {
    const userInfo = await userQuery.get()
    if (userInfo.data) {
      return {
        success: true,
        userInfo: userInfo.data
      }
    }
  } catch (err) {
    // 如果ID查询失败，尝试用openId查询
    const users = await userCollection.where({
      openId: userId
    }).get()
    
    if (users.data.length > 0) {
      return {
        success: true,
        userInfo: users.data[0]
      }
    }
    
    return {
      success: false,
      errMsg: '未找到用户信息'
    }
  }
}

// 更新用户信息
async function updateUserInfo(userId, userInfo) {
  await userCollection.doc(userId).update({
    data: {
      ...userInfo,
      updatedAt: db.serverDate()
    }
  })
  
  return {
    success: true
  }
}

// 获取用户目标设置
async function getGoals(openid) {
  try {
    const userData = await db.collection('users')
      .where({
        _openid: openid
      })
      .get();
    
    if (userData.data.length === 0) {
      return {
        success: true,
        data: {}
      };
    }
    
    const user = userData.data[0];
    
    // 计算累计专注小时数
    const focusRecords = await db.collection('focusRecords')
      .where({
        _openid: openid
      })
      .get();
    
    let totalMinutes = 0;
    focusRecords.data.forEach(record => {
      totalMinutes += record.minutes || 0;
    });
    
    const totalHours = totalMinutes / 60;
    const goalProgress = Math.min(100, (totalHours / 10000) * 100);
    
    return {
      success: true,
      data: user.goals || {},
      totalHours: totalHours.toFixed(1),
      goalProgress: goalProgress.toFixed(1)
    };
  } catch (err) {
    return {
      success: false,
      error: err
    };
  }
}

// 保存用户目标设置
async function saveGoals(openid, goals) {
  try {
    const user = await db.collection('users').where({
      _openid: openid
    }).get()
    
    if (user.data.length === 0) {
      // 创建新用户
      await db.collection('users').add({
        data: {
          _openid: openid,
          goals: goals,
          focusRecords: [],
          createTime: db.serverDate()
        }
      })
    } else {
      // 更新现有用户
      await db.collection('users').doc(user.data[0]._id).update({
        data: {
          goals: goals
        }
      })
    }
    
    return {
      success: true
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
}

// 获取今日专注进度
async function getTodayProgress(openid) {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const user = await db.collection('users').where({
      _openid: openid
    }).get()
    
    if (user.data.length === 0) {
      return {
        success: true,
        data: {
          focusCount: 0,
          focusMinutes: 0,
          completedTasks: 0
        }
      }
    }
    
    // 计算今日专注数据
    let focusCount = 0
    let focusMinutes = 0
    
    if (user.data[0].focusRecords) {
      user.data[0].focusRecords.forEach(record => {
        const recordDate = new Date(record.date)
        if (recordDate >= today) {
          focusCount++
          focusMinutes += record.minutes || 0
        }
      })
    }
    
    // 获取今日完成的任务数
    const tasks = await db.collection('tasks').where({
      _openid: openid,
      date: today.toISOString().split('T')[0],
      completed: true
    }).count()
    
    return {
      success: true,
      data: {
        focusCount,
        focusMinutes,
        completedTasks: tasks.total
      }
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
}

// 记录专注数据
async function recordFocus(openid, focusData) {
  try {
    const user = await db.collection('users').where({
      _openid: openid
    }).get()
    
    if (user.data.length === 0) {
      // 创建新用户
      await db.collection('users').add({
        data: {
          _openid: openid,
          goals: {},
          focusRecords: [focusData],
          createTime: db.serverDate()
        }
      })
    } else {
      // 更新现有用户
      await db.collection('users').doc(user.data[0]._id).update({
        data: {
          focusRecords: db.command.push(focusData)
        }
      })
    }
    
    // 如果有关联任务，检查是否需要自动打卡
    if (focusData.taskId) {
      const task = await db.collection('tasks').doc(focusData.taskId).get()
      
      if (!task.data.completed) {
        await db.collection('tasks').doc(focusData.taskId).update({
          data: {
            completed: true
          }
        })
      }
    }
    
    return {
      success: true
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
}

// 获取进度统计
async function getProgressStats(openid) {
  try {
    // 获取今天的日期，仅日期部分
    const today = new Date().toISOString().split('T')[0];
    
    // 计算本周开始日期（周一为开始）
    const now = new Date();
    const dayOfWeek = now.getDay() || 7; // 如果是0（周日）则为7
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - dayOfWeek + 1);
    const weekStartStr = weekStart.toISOString().split('T')[0];
    
    // 计算本月开始日期
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthStartStr = monthStart.toISOString().split('T')[0];
    
    // 查询用户的所有专注记录
    const focusRecords = await db.collection('focusRecords')
      .where({
        _openid: openid
      })
      .get();
    
    // 初始化统计数据
    const stats = {
      today: {
        focusCount: 0,
        focusMinutes: 0,
        completedTasks: 0,
        checkedIn: false
      },
      weekly: {
        focusMinutes: 0
      },
      monthly: {
        focusMinutes: 0
      },
      total: {
        focusMinutes: 0
      }
    };
    
    // 处理专注记录
    focusRecords.data.forEach(record => {
      const recordDate = record.date.split('T')[0];
      
      // 累计总专注时间
      stats.total.focusMinutes += record.minutes || 0;
      
      // 今日专注统计
      if (recordDate === today) {
        stats.today.focusCount++;
        stats.today.focusMinutes += record.minutes || 0;
      }
      
      // 本周专注统计
      if (recordDate >= weekStartStr) {
        stats.weekly.focusMinutes += record.minutes || 0;
      }
      
      // 本月专注统计
      if (recordDate >= monthStartStr) {
        stats.monthly.focusMinutes += record.minutes || 0;
      }
    });
    
    // 查询今日完成的任务数
    const completedTasks = await db.collection('tasks')
      .where({
        _openid: openid,
        date: today,
        completed: true
      })
      .count();
    
    stats.today.completedTasks = completedTasks.total;
    
    // 查询是否已打卡
    const checkInRecord = await db.collection('checkins')
      .where({
        _openid: openid,
        date: today
      })
      .get();
    
    stats.today.checkedIn = checkInRecord.data.length > 0;
    
    return {
      success: true,
      today: stats.today,
      weekly: stats.weekly,
      monthly: stats.monthly,
      totalMinutes: stats.total.focusMinutes
    };
  } catch (err) {
    console.error('获取进度统计失败', err);
    return {
      success: false,
      error: err
    };
  }
}

// 添加打卡记录
async function checkin(openid, date) {
  try {
    // 检查是否已打卡
    const existing = await db.collection('checkins')
      .where({
        _openid: openid,
        date: date
      })
      .get();
    
    if (existing.data.length > 0) {
      return {
        success: true,
        message: '今日已打卡'
      };
    }
    
    // 添加打卡记录
    await db.collection('checkins').add({
      data: {
        _openid: openid,
        date: date,
        createTime: db.serverDate()
      }
    });
    
    return {
      success: true,
      message: '打卡成功'
    };
  } catch (err) {
    console.error('打卡失败', err);
    return {
      success: false,
      error: err
    };
  }
} 