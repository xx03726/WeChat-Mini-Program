// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

// 云函数入口函数
exports.main = async (event, context) => {
  // 根据调用名称和参数返回模拟数据
  const { FUNCTION_NAME } = cloud.getWXContext()
  
  console.log(`模拟云函数 ${FUNCTION_NAME} 被调用，参数:`, event)
  
  // 根据不同的函数名返回不同的模拟数据
  switch(FUNCTION_NAME) {
    case 'statistics':
      return mockStatisticsData(event)
    // 可以添加其他函数的模拟实现
    default:
      return {
        success: true,
        message: '模拟数据返回成功',
        data: {}
      }
  }
}

// 模拟统计数据
function mockStatisticsData(event) {
  return {
    success: true,
    summary: {
      totalFocusTime: 320,
      totalCompletedTasks: 15,
      totalPomodoros: 18,
      averageFocusTime: 45
    },
    timeDistribution: Array(24).fill(0).map((_, i) => 
      i >= 9 && i <= 18 ? Math.floor(Math.random() * 60) : Math.floor(Math.random() * 15)
    ),
    heatmapData: generateMockHeatmapData()
  }
}

// 生成模拟热图数据
function generateMockHeatmapData() {
  const heatmapData = {}
  const today = new Date()
  
  for (let i = 30; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const dateKey = formatDate(date)
    
    // 周末数据少一些
    const isWeekend = date.getDay() === 0 || date.getDay() === 6
    heatmapData[dateKey] = isWeekend ? 
      Math.floor(Math.random() * 40) : 
      Math.floor(Math.random() * 120 + 30)
  }
  
  return heatmapData
}

// 格式化日期
function formatDate(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  
  return `${year}-${month}-${day}`
} 