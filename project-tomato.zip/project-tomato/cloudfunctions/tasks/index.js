// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境
const db = cloud.database()
const tasksCollection = db.collection('tasks')
const _ = db.command
const MAX_LIMIT = 100

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  
  // 根据不同操作类型执行相应函数
  switch (event.action) {
    case 'add':
      return await addTask(event, openid)
    case 'update':
      return await updateTask(event, openid)
    case 'delete':
      return await deleteTask(event, openid)
    case 'get':
      return await getTasks(openid, event.status)
    case 'complete':
      return await completeTask(event, openid)
    case 'batchDelete':
      return await batchDeleteTasks(event, openid)
    default:
      return {
        success: false,
        message: '未知操作类型'
      }
  }
}

// 获取任务列表
async function getTasks(openid, status) {
  try {
    // 构建查询条件
    const condition = { _openid: openid }
    if (status !== undefined) {
      condition.completed = status === 'completed'
    }
    
    // 如果传入日期参数，按日期筛选
    if (event && event.date) {
      condition.date = event.date;
      console.log('按日期筛选任务:', condition);
    }
    
    // 获取总数
    const countResult = await db.collection('tasks').where(condition).count()
    const total = countResult.total
    
    // 分批次获取数据
    const tasks = await db.collection('tasks')
      .where(condition)
      .orderBy('createTime', 'desc')
      .get()
    
    console.log('查询结果:', tasks);
    return {
      success: true,
      tasks: tasks.data
    };
  } catch (err) {
    console.error('获取任务列表失败', err)
    return {
      success: false,
      message: '获取任务列表失败'
    }
  }
}

// 添加任务
async function addTask(event, openid) {
  try {
    const taskData = {
      ...event.task,
      _openid: openid,
      createTime: db.serverDate(),
      completed: false
    }
    
    const result = await db.collection('tasks').add({
      data: taskData
    })
    
    return {
      success: true,
      _id: result._id
    }
  } catch (err) {
    console.error('添加任务失败', err)
    return {
      success: false,
      message: '添加任务失败'
    }
  }
}

// 更新任务
async function updateTask(event, openid) {
  try {
    const { _id, ...updateData } = event.task
    
    const result = await db.collection('tasks')
      .where({
        _id: _id,
        _openid: openid
      })
      .update({
        data: updateData
      })
    
    return {
      success: result.stats.updated > 0,
      updated: result.stats.updated
    }
  } catch (err) {
    console.error('更新任务失败', err)
    return {
      success: false,
      message: '更新任务失败'
    }
  }
}

// 删除任务
async function deleteTask(event, openid) {
  try {
    const result = await db.collection('tasks')
      .where({
        _id: event.taskId,
        _openid: openid
      })
      .remove()
    
    return {
      success: result.stats.removed > 0,
      removed: result.stats.removed
    }
  } catch (err) {
    console.error('删除任务失败', err)
    return {
      success: false,
      message: '删除任务失败'
    }
  }
}

// 完成任务
async function completeTask(event, openid) {
  try {
    const result = await db.collection('tasks')
      .where({
        _id: event.taskId,
        _openid: openid
      })
      .update({
        data: {
          completed: true,
          completeTime: db.serverDate()
        }
      })
    
    return {
      success: result.stats.updated > 0,
      updated: result.stats.updated
    }
  } catch (err) {
    console.error('完成任务失败', err)
    return {
      success: false,
      message: '完成任务失败'
    }
  }
}

// 批量删除任务
async function batchDeleteTasks(event, openid) {
  try {
    const result = await db.collection('tasks')
      .where({
        _id: _.in(event.taskIds),
        _openid: openid
      })
      .remove()
    
    return {
      success: true,
      removed: result.stats.removed
    }
  } catch (err) {
    console.error('批量删除任务失败', err)
    return {
      success: false,
      message: '批量删除任务失败'
    }
  }
} 