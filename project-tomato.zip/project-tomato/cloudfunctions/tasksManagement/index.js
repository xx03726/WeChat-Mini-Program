// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command
const tasksCollection = db.collection('tasks')

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  
  // 创建索引
  try {
    // 尝试创建索引，如果已存在则跳过
    await db.collection('tasks').createIndex({
      createTime: -1  // -1表示降序索引
    }, {
      background: true  // 允许在后台创建索引
    });
    console.log('任务日期索引创建成功或已存在');
  } catch (err) {
    console.error('创建索引失败:', err);
    // 索引创建失败不影响主要功能，继续执行
  }
  
  switch (event.action) {
    case 'getTasks':
      return getTasks(openid, event.date)
    case 'addTask':
      return addTask(openid, event.task)
    case 'updateTask':
      return updateTask(openid, event.taskId, event.data)
    case 'deleteTask':
      return deleteTask(openid, event.taskId)
    default:
      return {
        success: false,
        error: '未知操作'
      }
  }
}

// 获取指定日期的任务
async function getTasks(openid, date) {
  try {
    // 如果没有指定日期，则获取今天的任务
    if (!date) {
      date = new Date().toISOString().split('T')[0]
    }
    
    const result = await tasksCollection
      .where({
        _openid: openid,
        date: date
      })
      .orderBy('createTime', 'asc')
      .get()
    
    return {
      success: true,
      data: result.data
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
}

// 添加新任务
async function addTask(openid, task) {
  try {
    // 确保任务对象包含必要字段
    if (!task || !task.name) {
      return {
        success: false,
        error: '任务名称不能为空'
      };
    }
    
    // 添加创建时间和用户ID
    const taskData = {
      ...task,
      _openid: openid,
      // 如果收到的是时间戳，转换为服务器日期对象
      createTime: task.createTime ? new Date(task.createTime) : db.serverDate()
    };
    
    console.log('准备添加任务:', taskData);
    
    const result = await tasksCollection.add({
      data: taskData
    });
    
    return {
      success: true,
      taskId: result._id
    };
  } catch (err) {
    console.error('添加任务错误:', err);
    return {
      success: false,
      error: err.message || err
    };
  }
}

// 更新任务
async function updateTask(openid, taskId, data) {
  try {
    await tasksCollection.doc(taskId).update({
      data: data
    })
    
    return {
      success: true
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
}

// 删除任务
async function deleteTask(openid, taskId) {
  try {
    await tasksCollection.doc(taskId).remove()
    
    return {
      success: true
    }
  } catch (err) {
    return {
      success: false,
      error: err
    }
  }
} 