// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command
const pomodoros = db.collection('pomodoros')
const tasks = db.collection('tasks')

// 云函数入口函数
exports.main = async (event, context) => {
  const { action, userId, period, startDate, endDate } = event
  const wxContext = cloud.getWXContext()
  
  // 获取访问者OpenID
  const openId = wxContext.OPENID || userId
  
  // 所有函数必须处理空ID情况
  if (!openId) {
    return {
      success: false,
      errMsg: '未提供有效用户ID'
    }
  }
  
  try {
    switch (action) {
      case 'getStatistics':
        return await getStatistics(openId, period, startDate, endDate)
      case 'recordPomodoro':
        return await recordPomodoro(openId, event.pomodoroData)
      default:
        return {
          success: false,
          errMsg: '未知操作类型'
        }
    }
  } catch (error) {
    console.error('云函数执行错误:', error)
    return {
      success: false,
      errMsg: error.message || '云函数执行异常'
    }
  }
}

// 获取统计数据
async function getStatistics(userId, period, startDate, endDate) {
  // 根据周期确定时间范围
  const timeRange = getTimeRange(period, startDate, endDate)
  
  try {
    // 获取指定日期范围内的番茄钟记录
    const pomodoroRecords = await pomodoros.where({
      userId: userId,
      startTime: _.gte(timeRange.start).and(_.lte(timeRange.end)),
      isCompleted: true
    }).get()
    
    // 获取已完成的任务
    const completedTasks = await tasks.where({
      userId: userId,
      completedDate: _.gte(timeRange.start).and(_.lte(timeRange.end)),
      completed: true
    }).get()
    
    // 计算统计数据
    const result = calculateStats(pomodoroRecords.data, completedTasks.data, timeRange)
    
    return {
      success: true,
      ...result
    }
  } catch (error) {
    console.error('获取统计数据错误:', error)
    return {
      success: false,
      errMsg: error.message || '获取统计数据失败'
    }
  }
}

// 记录番茄钟
async function recordPomodoro(userId, pomodoroData) {
  try {
    const result = await pomodoros.add({
      data: {
        userId,
        ...pomodoroData,
        startTime: new Date(pomodoroData.startTime || Date.now()),
        endTime: new Date(pomodoroData.endTime || Date.now()),
        createdAt: new Date()
      }
    })
    
    return {
      success: true,
      id: result._id
    }
  } catch (error) {
    console.error('记录番茄钟错误:', error)
    return {
      success: false,
      errMsg: error.message || '记录番茄钟失败'
    }
  }
}

// 根据周期获取时间范围
function getTimeRange(period, startDate, endDate) {
  // 如果提供了明确的日期范围，直接使用
  if (startDate && endDate) {
    return {
      start: new Date(startDate),
      end: new Date(endDate)
    }
  }
  
  const now = new Date()
  let start = new Date(now)
  
  switch (period) {
    case 'daily':
      // 今天的开始时间
      start.setHours(0, 0, 0, 0)
      break
    case 'weekly':
      // 本周开始时间（周一）
      const day = start.getDay() || 7
      start.setDate(start.getDate() - day + 1)
      start.setHours(0, 0, 0, 0)
      break
    case 'monthly':
      // 本月开始时间
      start.setDate(1)
      start.setHours(0, 0, 0, 0)
      break
    default:
      // 默认过去7天
      start.setDate(start.getDate() - 7)
      start.setHours(0, 0, 0, 0)
  }
  
  return {
    start,
    end: now
  }
}

// 计算统计数据
function calculateStats(pomodoroRecords, completedTasks, timeRange) {
  // 总番茄钟数量（向后兼容）
  const totalPomodoros = pomodoroRecords.filter(record => !record.isBreak).length;
  
  // 总专注时间（分钟）
  const totalFocusTime = pomodoroRecords.reduce((sum, record) => {
    // 如果不是休息时间，则计入专注时间
    if (!record.isBreak) {
      return sum + (record.duration || 0)
    }
    return sum
  }, 0)
  
  // 总完成任务数
  const totalCompletedTasks = completedTasks.length
  
  // 计算天数
  const days = Math.ceil((timeRange.end - timeRange.start) / (1000 * 60 * 60 * 24)) || 1
  
  // 平均每天专注时间
  const averageFocusTime = Math.round(totalFocusTime / days)
  
  // 构建时间分布数据
  const timeDistribution = calculateTimeDistribution(pomodoroRecords)
  
  // 构建热图数据
  const heatmapData = calculateHeatmapData(pomodoroRecords, timeRange)
  
  return {
    summary: {
      totalFocusTime,
      totalCompletedTasks,
      averageFocusTime,
      days,
      totalPomodoros  // 添加向后兼容字段
    },
    timeDistribution,
    heatmapData
  }
}

// 计算时间分布
function calculateTimeDistribution(pomodoroRecords) {
  // 按时间段统计专注时间
  const timeSlots = [
    { timeSlot: '凌晨', hours: [0, 1, 2, 3, 4, 5], duration: 0 },
    { timeSlot: '上午', hours: [6, 7, 8, 9, 10, 11], duration: 0 },
    { timeSlot: '下午', hours: [12, 13, 14, 15, 16, 17], duration: 0 },
    { timeSlot: '晚上', hours: [18, 19, 20, 21, 22, 23], duration: 0 }
  ]
  
  // 统计每个时间段的专注时间
  pomodoroRecords.forEach(record => {
    if (!record.isBreak) {
      const hour = new Date(record.startTime).getHours()
      
      // 找到对应的时间段
      const slot = timeSlots.find(slot => slot.hours.includes(hour))
      if (slot) {
        slot.duration += (record.duration || 0)
      }
    }
  })
  
  return timeSlots
}

// 计算热图数据
function calculateHeatmapData(pomodoroRecords, timeRange) {
  const heatmapData = []
  
  // 生成日期范围内的所有日期
  const start = new Date(timeRange.start)
  const end = new Date(timeRange.end)
  const dateMap = {}
  
  // 初始化每一天的数据
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const dateStr = formatDate(d)
    dateMap[dateStr] = 0
  }
  
  // 统计每天的专注时间
  pomodoroRecords.forEach(record => {
    if (!record.isBreak) {
      const dateStr = formatDate(new Date(record.startTime))
      if (dateMap[dateStr] !== undefined) {
        dateMap[dateStr] += (record.duration || 0)
      }
    }
  })
  
  // 转换为热图数据格式
  for (const [date, duration] of Object.entries(dateMap)) {
    heatmapData.push({
      date,
      duration
    })
  }
  
  return heatmapData
}

// 日期格式化为 YYYY-MM-DD
function formatDate(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  
  return `${year}-${month}-${day}`
}