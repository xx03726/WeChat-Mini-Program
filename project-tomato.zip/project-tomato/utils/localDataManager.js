// 本地数据管理工具

const STORAGE_KEYS = {
  POMODORO_RECORDS: 'pomodoroRecords',
  TASKS: 'tasks',
  USER_SETTINGS: 'userSettings',
  USER_ID: 'userId'
};

// 存储番茄钟记录到本地
function savePomodoro(pomodoroData) {
  try {
    // 获取现有记录
    let records = wx.getStorageSync(STORAGE_KEYS.POMODORO_RECORDS) || [];
    
    // 添加新记录
    records.push({
      ...pomodoroData,
      id: 'local_' + Date.now(),
      createdAt: new Date().toISOString()
    });
    
    // 限制本地存储数量，只保留最近100条
    if (records.length > 100) {
      records = records.slice(-100);
    }
    
    // 保存回本地
    wx.setStorageSync(STORAGE_KEYS.POMODORO_RECORDS, records);
    return true;
  } catch (error) {
    console.error('保存番茄钟记录到本地失败:', error);
    return false;
  }
}

// 从本地获取统计数据
function getLocalStatistics(period, startDate, endDate) {
  try {
    // 获取日期范围
    const start = startDate ? new Date(startDate) : getDefaultStartDate(period);
    const end = endDate ? new Date(endDate) : new Date();
    
    // 获取本地记录
    const records = wx.getStorageSync(STORAGE_KEYS.POMODORO_RECORDS) || [];
    const tasks = wx.getStorageSync(STORAGE_KEYS.TASKS) || [];
    
    // 筛选符合日期范围的记录和任务
    const filteredRecords = filterRecordsByDateRange(records, start, end);
    const completedTasks = filterTasksByDateRange(tasks, start, end);
    
    // 计算统计数据
    return calculateStatistics(filteredRecords, completedTasks, start, end);
  } catch (error) {
    console.error('获取本地统计数据失败:', error);
    return {
      summary: {
        totalFocusTime: 0,
        totalCompletedTasks: 0,
        averageFocusTime: 0
      },
      timeDistribution: getDefaultTimeDistribution(),
      heatmapData: []
    };
  }
}

// 其他辅助函数...

module.exports = {
  savePomodoro,
  getLocalStatistics,
  STORAGE_KEYS
}; 