/**
 * 简易农历日期转换工具
 */

// 定义农历年的数据信息 - 用于确定每年的正月初一在公历的日期
// 这里简化处理，实际农历计算更复杂
const lunarYears = {
  2025: {
    spring: "2025-01-29" // 2025年春节/正月初一
  },
  2024: {
    spring: "2024-02-10" // 2024年春节/正月初一
  }
};

// 农历月份名称
const lunarMonths = [
  '正月', '二月', '三月', '四月', '五月', '六月',
  '七月', '八月', '九月', '十月', '冬月', '腊月'
];

// 农历日期名称
const lunarDays = [
  '初一', '初二', '初三', '初四', '初五', '初六', '初七', '初八', '初九', '初十',
  '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十',
  '廿一', '廿二', '廿三', '廿四', '廿五', '廿六', '廿七', '廿八', '廿九', '三十'
];

// 常见节日(公历)
const festivals = [
  { month: 1, day: 1, name: '元旦' },
  { month: 2, day: 14, name: '情人节' },
  { month: 3, day: 8, name: '妇女节' },
  { month: 3, day: 12, name: '植树节' },
  { month: 4, day: 1, name: '愚人节' },
  { month: 4, day: 5, name: '清明' },
  { month: 5, day: 1, name: '劳动节' },
  { month: 5, day: 4, name: '青年节' },
  { month: 6, day: 1, name: '儿童节' },
  { month: 9, day: 10, name: '教师节' },
  { month: 10, day: 1, name: '国庆节' },
  { month: 12, day: 25, name: '圣诞节' }
];

// 二十四节气(大致日期，实际需要精确计算)
const solarTerms = [
  { month: 2, day: 4, name: '立春' },
  { month: 2, day: 19, name: '雨水' },
  { month: 3, day: 6, name: '惊蛰' },
  { month: 3, day: 21, name: '春分' },
  { month: 4, day: 5, name: '清明' },
  { month: 4, day: 20, name: '谷雨' },
  { month: 5, day: 6, name: '立夏' },
  { month: 5, day: 21, name: '小满' },
  { month: 6, day: 6, name: '芒种' },
  { month: 6, day: 21, name: '夏至' },
  { month: 7, day: 7, name: '小暑' },
  { month: 7, day: 23, name: '大暑' },
  { month: 8, day: 8, name: '立秋' },
  { month: 8, day: 23, name: '处暑' },
  { month: 9, day: 8, name: '白露' },
  { month: 9, day: 23, name: '秋分' },
  { month: 10, day: 8, name: '寒露' },
  { month: 10, day: 24, name: '霜降' },
  { month: 11, day: 8, name: '立冬' },
  { month: 11, day: 22, name: '小雪' },
  { month: 12, day: 7, name: '大雪' },
  { month: 12, day: 22, name: '冬至' },
  { month: 1, day: 6, name: '小寒' },
  { month: 1, day: 20, name: '大寒' }
];

/**
 * 获取某一天的农历信息
 * @param {Date|string} date - 日期对象或日期字符串
 * @returns {string} 农历信息文本
 */
function getLunarDay(date) {
  // 简化实现，这里仅根据日期返回固定的农历日期
  // 实际应用中需要根据公历日期计算农历日期
  
  // 统一转换为Date对象
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const month = dateObj.getMonth() + 1;
  const day = dateObj.getDate();
  
  // 先检查是否是节日或节气
  const festival = festivals.find(f => f.month === month && f.day === day);
  if (festival) return festival.name;
  
  const solarTerm = solarTerms.find(t => t.month === month && t.day === day);
  if (solarTerm) return solarTerm.name;
  
  // 简单返回当前日的农历日子名称(不含月份)
  return lunarDays[(day - 1) % 30];
}

module.exports = {
  getLunarDay
}; 