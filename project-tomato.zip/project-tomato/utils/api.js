// 集中处理API调用的工具文件

// 本地存储键名
const STORAGE_KEYS = {
  POMODORO_RECORDS: 'pomodoroRecords',
  TASKS: 'tasks',
  USER_SETTINGS: 'userSettings',
  USER_ID: 'userId'
};

// 封装云函数调用逻辑，自动处理错误和回退
const callCloudFunction = async (name, data) => {
  return new Promise(async (resolve, reject) => {
    try {
      if (!wx.cloud) {
        console.error('云开发未初始化');
        resolve({
          success: false,
          error: '云开发未初始化',
          localFallback: true
        });
        return;
      }
      
      console.log(`调用云函数 ${name}`, data);
      
      const result = await wx.cloud.callFunction({
        name,
        data
      });
      
      console.log(`云函数 ${name} 调用成功:`, result);
      
      if (result.result) {
        resolve(result.result);
      } else {
        resolve(result);
      }
    } catch (error) {
      console.error(`云函数 ${name} 调用失败:`, error);
      
      // 返回适当的回退数据
      if (name === 'tasks') {
        const fallbackData = getTasksFallbackData(data);
        resolve(fallbackData);
      } else if (name === 'pomodoro') {
        resolve({
          success: true,
          localOnly: true,
          message: '数据已保存在本地'
        });
      } else {
        reject(error);
      }
    }
  });
};

// 获取任务的回退数据
function getTasksFallbackData(data) {
  if (data.action === 'getTasks') {
    return {
      success: true,
      localFallback: true,
      tasks: [
        {
          id: 'task1',
          title: '完成项目计划',
          completed: false,
          date: data.date || new Date().toISOString().split('T')[0]
        },
        {
          id: 'task2',
          title: '学习小程序开发',
          completed: true,
          date: data.date || new Date().toISOString().split('T')[0]
        }
      ]
    };
  } else if (data.action === 'updateTask') {
    return {
      success: true,
      localFallback: true,
      message: '任务已在本地更新'
    };
  }
  
  return {
    success: false,
    localFallback: true,
    message: '不支持的操作'
  };
}

// 统计数据API
const statisticsAPI = {
  // 获取统计数据的方法
  getStatistics: function({ userId, period, startDate, endDate, forceRefresh }) {
    return new Promise((resolve, reject) => {
      // 如果强制刷新或没有本地缓存，则从服务器获取
      const cacheKey = `statistics_${period}_${startDate}_${endDate}`;
      const cachedData = wx.getStorageSync(cacheKey);
      
      if (!forceRefresh && cachedData) {
        console.log('使用缓存的统计数据');
        resolve(cachedData);
        return;
      }
      
      // 从本地存储合成统计数据
      try {
        const pomodoroRecords = wx.getStorageSync('pomodoroRecords') || {};
        const tasks = wx.getStorageSync('tasks') || [];
        
        // 计算日期范围内的统计数据
        const start = startDate ? new Date(startDate) : new Date();
        start.setHours(0, 0, 0, 0);
        
        const end = endDate ? new Date(endDate) : new Date();
        end.setHours(23, 59, 59, 999);
        
        // 计算指标
        const stats = this.calculateStatistics(pomodoroRecords, tasks, start, end);
        
        // 缓存结果
        wx.setStorageSync(cacheKey, stats);
        
        resolve(stats);
      } catch (err) {
        console.error('计算统计数据失败:', err);
        reject(err);
      }
    });
  },
  
  // 记录番茄钟
  recordPomodoro: async (userId, pomodoroData) => {
    // 先存到本地
    let records = wx.getStorageSync(STORAGE_KEYS.POMODORO_RECORDS) || [];
    const newRecord = {
      id: 'local_' + Date.now(),
      userId,
      ...pomodoroData,
      createdAt: new Date().toISOString()
    };
    records.push(newRecord);
    wx.setStorageSync(STORAGE_KEYS.POMODORO_RECORDS, records);
    
    // 然后尝试存到云端
    return callCloudFunction(
      'statistics',
      {
        action: 'recordPomodoro',
        userId,
        pomodoroData
      },
      // 回退时仍返回成功，因为已保存到本地
      () => ({ success: true, id: newRecord.id, localSaved: true })
    );
  },

  // 在statisticsAPI对象中添加calculateStatistics方法
  calculateStatistics: function(pomodoroRecords, tasks, startDate, endDate) {
    // 计算日期范围内的所有统计数据
    let totalFocusTime = 0;
    let totalCompletedTasks = 0;
    let totalDays = 0;
    let timeDistribution = Array(24).fill(0);
    let dailyData = [];
    
    // 获取日期范围内的天数
    const startDay = new Date(startDate);
    const endDay = new Date(endDate);
    const dayDiff = Math.floor((endDay - startDay) / (24 * 60 * 60 * 1000)) + 1;
    totalDays = dayDiff;
    
    // 处理专注记录
    for (const dateKey in pomodoroRecords) {
      const recordDate = new Date(dateKey);
      if (recordDate >= startDay && recordDate <= endDay) {
        const dayRecords = pomodoroRecords[dateKey];
        
        // 累计专注时间
        totalFocusTime += dayRecords.minutes || 0;
        
        // 处理每条记录
        if (dayRecords.records && dayRecords.records.length) {
          dayRecords.records.forEach(record => {
            // 统计时间段分布
            const recordTime = new Date(record.timestamp);
            const hour = recordTime.getHours();
            timeDistribution[hour] += record.minutes || 0;
          });
        }
        
        // 添加到每日数据
        dailyData.push({
          date: dateKey,
          focusTime: dayRecords.minutes || 0,
          count: dayRecords.count || 0
        });
      }
    }
    
    // 处理任务完成情况
    tasks.forEach(task => {
      if (task.completed) {
        const taskDate = new Date(task.completedAt || task.date || task.createTime);
        if (taskDate >= startDay && taskDate <= endDay) {
          totalCompletedTasks++;
        }
      }
    });
    
    // 计算平均专注时间
    const averageFocusTime = totalDays > 0 ? Math.round(totalFocusTime / totalDays) : 0;
    
    // 返回统计结果
    return {
      summary: {
        totalFocusTime,
        totalCompletedTasks,
        averageFocusTime,
        days: totalDays
      },
      timeDistribution: timeDistribution,
      heatmapData: dailyData
    };
  }
};

// 获取默认开始日期
function getDefaultStartDate(period) {
  const now = new Date();
  let startDate = new Date(now);
  
  switch (period) {
    case 'daily':
      startDate.setHours(0, 0, 0, 0);
      break;
    case 'weekly':
      startDate.setDate(now.getDate() - 7);
      break;
    case 'monthly':
      startDate.setMonth(now.getMonth() - 1);
      break;
    default:
      startDate.setDate(now.getDate() - 7);
  }
  
  return startDate;
}

// 格式化日期为 YYYY-MM-DD
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  
  return `${year}-${month}-${day}`;
}

// 生成更逼真的热力图数据
function generateHeatmapData(startDate, endDate) {
  const heatmapData = [];
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const dateStr = formatDate(d);
    // 随机生成一些专注时间数据，偶尔出现0表示没有专注
    const duration = Math.random() > 0.3 ? Math.floor(Math.random() * 120) : 0;
    heatmapData.push({ 
      date: dateStr, 
      duration: duration 
    });
  }
  
  return heatmapData;
}

// 在现有API中添加或确认以下方法
const taskAPI = {
  // 获取任务列表
  getTasks({userId, date} = {}) {
    return new Promise((resolve, reject) => {
      callCloudFunction('tasks', {
        action: 'getTasks',
        userId,
        date
      }).then(res => {
        console.log('云函数getTasks返回原始数据:', res);
        
        // 处理不同的返回结构，确保统一格式
        let formattedResult = { success: true };
        
        // 提取任务数据，考虑各种可能的数据结构
        let tasks = [];
        if (res && res.tasks && Array.isArray(res.tasks)) {
          tasks = res.tasks;
        } else if (res && res.data && Array.isArray(res.data)) {
          tasks = res.data;
        } else if (res && res.result && res.result.tasks && Array.isArray(res.result.tasks)) {
          tasks = res.result.tasks;
        } else if (res && res.result && res.result.data && Array.isArray(res.result.data)) {
          tasks = res.result.data;
        }
        
        // 确保每个任务都有id字段
        tasks = tasks.map(task => {
          if (!task.id && task._id) {
            task.id = task._id;
          }
          return task;
        });
        
        formattedResult.tasks = tasks;
        console.log('格式化后的任务数据:', formattedResult);
        
        resolve(formattedResult);
      }).catch(err => {
        console.error('获取任务失败，使用本地数据', err);
        // 返回模拟数据作为回退方案
        // 现在也包含本地存储的任务
        const localTasks = wx.getStorageSync('localTasks') || [];
        const defaultTasks = [
          {
            id: 'task1',
            title: '完成项目计划',
            completed: false,
            date: date || new Date().toISOString().split('T')[0]
          },
          {
            id: 'task2',
            title: '学习小程序开发',
            completed: true,
            date: date || new Date().toISOString().split('T')[0]
          }
        ];
        
        // 合并默认任务和本地存储的任务
        let tasks = [...defaultTasks];
        if (localTasks && localTasks.length > 0) {
          // 只添加与当前日期匹配的本地任务
          const filteredLocalTasks = localTasks.filter(t => t.date === date);
          tasks = [...tasks, ...filteredLocalTasks];
        }
        
        resolve({
          success: true,
          localFallback: true,
          tasks: tasks
        });
      });
    });
  },
  
  // 更新任务
  updateTask({taskId, title, description, date, completed}) {
    return callCloudFunction('tasks', {
      action: 'updateTask',
      taskId,
      title,
      description,
      date,
      completed
    });
  },
  
  // 添加新方法：创建任务
  createTask(taskData) {
    return new Promise((resolve, reject) => {
      // 尝试调用云函数创建任务
      callCloudFunction('tasks', {
        action: 'createTask',
        task: taskData
      }).then(res => {
        resolve({
          success: true,
          taskId: res.taskId || res._id || 'task_' + Date.now(),
          // 确保返回完整的任务数据，方便直接添加到列表
          task: {
            id: res.taskId || res._id || 'task_' + Date.now(),
            ...taskData
          }
        });
      }).catch(err => {
        console.error('创建任务失败，使用本地存储', err);
        
        // 本地回退：将任务保存到本地存储
        try {
          // 为任务生成本地ID
          const localTaskId = 'local_task_' + Date.now();
          const newTask = {
            id: localTaskId,
            ...taskData,
            createTime: new Date().toISOString(),
            localOnly: true
          };
          
          // 获取现有任务列表
          let tasks = wx.getStorageSync('localTasks') || [];
          tasks.push(newTask);
          wx.setStorageSync('localTasks', tasks);
          
          // 返回成功结果和完整任务数据
          resolve({
            success: true,
            localFallback: true,
            taskId: localTaskId,
            message: '任务已创建（本地存储）',
            task: newTask
          });
        } catch (storeErr) {
          // 如果本地存储也失败了，才真正拒绝承诺
          reject(storeErr);
        }
      });
    });
  },

  // 添加删除任务方法
  deleteTask(taskId) {
    return new Promise((resolve, reject) => {
      if (!taskId) {
        reject(new Error('任务ID不能为空'));
        return;
      }
      
      callCloudFunction('tasks', {
        action: 'deleteTask',
        taskId: taskId
      }).then(res => {
        resolve({
          success: true,
          taskId: taskId
        });
      }).catch(err => {
        console.error('删除任务失败，尝试本地删除', err);
        
        // 本地删除任务
        try {
          // 获取本地存储的任务
          const localTasks = wx.getStorageSync('localTasks') || [];
          // 过滤掉要删除的任务
          const updatedTasks = localTasks.filter(task => task.id !== taskId);
          // 保存回本地存储
          wx.setStorageSync('localTasks', updatedTasks);
          
          resolve({
            success: true,
            localFallback: true,
            taskId: taskId
          });
        } catch (storeErr) {
          reject(storeErr);
        }
      });
    });
  }
};

// 目标管理API
const goalAPI = {
  // 获取用户目标设置
  getGoals({ userId }) {
    console.log('获取用户目标设置', userId);
    
    // 返回模拟数据
    return Promise.resolve({
      daily: 180,    // 默认3小时
      weekly: 1200,  // 默认20小时
      monthly: 5400  // 默认90小时
    });
  },
  
  // 更新目标设置
  updateGoal({ userId, type, target }) {
    console.log('更新目标设置', userId, type, target);
    return Promise.resolve({ success: true });
  },
  
  // 获取打卡状态
  getCheckinStatus({ userId, date }) {
    console.log('获取打卡状态', userId, date);
    // 模拟数据，随机返回打卡状态
    return Promise.resolve({
      checkedIn: Math.random() > 0.5
    });
  },
  
  // 执行打卡
  checkIn({ userId, date, goalId }) {
    console.log('执行打卡', userId, date, goalId);
    return Promise.resolve({ success: true });
  }
};

// 成就追踪API
const achievementAPI = {
  // 获取成就数据
  getAchievements({ userId }) {
    console.log('获取成就数据', userId);
    // 返回模拟数据
    return Promise.resolve({
      achievements: {
        totalHours: Math.floor(Math.random() * 500), // 0-500小时随机数
        categories: {
          study: Math.floor(Math.random() * 300),
          work: Math.floor(Math.random() * 200)
        }
      }
    });
  },
  
  // 更新成就进度
  updateAchievement({ userId, hoursToAdd }) {
    console.log('更新成就进度', userId, hoursToAdd);
    return Promise.resolve({ success: true });
  }
};

module.exports = {
  statisticsAPI,
  taskAPI,
  callCloudFunction,
  STORAGE_KEYS,
  goalAPI,
  achievementAPI
}; 