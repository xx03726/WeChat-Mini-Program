async function getTasks(query = {}) {
  try {
    const result = await wx.cloud.callFunction({
      name: 'tasksManagement',
      data: {
        action: 'getTasks',
        query: query
      }
    });
    return result.result;
  } catch (error) {
    console.error('获取任务列表失败', error);
    throw error;
  }
} 